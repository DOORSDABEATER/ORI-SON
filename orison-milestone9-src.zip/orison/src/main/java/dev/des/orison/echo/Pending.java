package dev.des.orison.echo;

import org.bukkit.Location;

/** A recent, claimable defeat. Lives only in memory and expires. */
public final class Pending {
    public String identity, displayName, entityType, mythicId, modelId;
    public double maxHealth, attackDamage, moveSpeed;
    public Location location;
    public long expiresAt;
    public int attempts;
    public boolean marked;       // had a HUNT MARK when it fell
    public boolean irregular;
    public String irregularReason;
}
