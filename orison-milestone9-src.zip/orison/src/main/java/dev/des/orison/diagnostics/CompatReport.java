package dev.des.orison.diagnostics;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

import java.util.ArrayList;
import java.util.List;

/** Live compatibility report: what is actually present on THIS server right now. */
public record CompatReport(List<String> lines) {

    private static final String[][] OPTIONAL = {
            {"MythicMobs", "Echo profiles, hunt eligibility"},
            {"ModelEngine", "Echo models/animations, presence visuals"},
            {"ProtocolLib", "Packet-based presence effects"},
            {"PlasmoVoice", "Optional audio integration"},
            {"WorldGuard", "Region/protection checks"},
    };

    public static CompatReport scan(Plugin self) {
        List<String> out = new ArrayList<>();
        out.add("Server: " + Bukkit.getName() + " " + Bukkit.getVersion());
        out.add("Minecraft: " + Bukkit.getMinecraftVersion());
        out.add("Java: " + System.getProperty("java.version"));
        PluginManager pm = Bukkit.getPluginManager();
        for (String[] dep : OPTIONAL) {
            Plugin p = pm.getPlugin(dep[0]);
            if (p == null) out.add(dep[0] + ": NOT INSTALLED (core unaffected) - " + dep[1]);
            else out.add(dep[0] + ": " + p.getPluginMeta().getVersion() + (p.isEnabled() ? "" : " (DISABLED)") + " - " + dep[1]);
        }
        out.add("Installed plugins: " + pm.getPlugins().length);
        return new CompatReport(out);
    }
}
