package dev.des.orison.persistence;

import java.sql.Connection;
import java.sql.SQLException;

/** Tiny transaction helper: commit on success, roll back on any failure. */
public final class Tx {
    private Tx() { }

    @FunctionalInterface
    public interface Work { void run() throws SQLException; }

    public static void run(Connection c, Work work) throws SQLException {
        c.setAutoCommit(false);
        try {
            work.run();
            c.commit();
        } catch (SQLException | RuntimeException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }
}
