package dev.des.orison.persistence;

import org.bukkit.plugin.Plugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

/**
 * SQLite storage. One connection, owned by one single-thread executor, so database work never
 * runs on the main thread and never races. Schema changes are versioned migrations; a backup of
 * the file is taken on every start.
 */
public final class Database implements AutoCloseable {

    /** Index i == schema version i+1. Append only; never edit a shipped migration. */
    private static final List<String> MIGRATIONS = List.of(
            "CREATE TABLE owner (id INTEGER PRIMARY KEY CHECK (id = 1), uuid TEXT NOT NULL, bound_at INTEGER NOT NULL)",
            "CREATE TABLE progress (id INTEGER PRIMARY KEY CHECK (id = 1), stage INTEGER NOT NULL DEFAULT 1, updated_at INTEGER NOT NULL)",
            "CREATE TABLE audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL)",
            "ALTER TABLE progress ADD COLUMN paradox REAL NOT NULL DEFAULT 0",
            "CREATE TABLE ability_unlock (ability_id TEXT PRIMARY KEY, unlocked_at INTEGER NOT NULL, source TEXT NOT NULL)",
            "CREATE TABLE hunt_record (identity TEXT PRIMARY KEY, display_name TEXT NOT NULL, entity_type TEXT NOT NULL, mythic_id TEXT, model_id TEXT, max_health REAL NOT NULL, attack_damage REAL NOT NULL, move_speed REAL NOT NULL, kills INTEGER NOT NULL, first_defeat INTEGER NOT NULL, last_defeat INTEGER NOT NULL)",
            "CREATE TABLE echo_record (id TEXT PRIMARY KEY, identity TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL, nickname TEXT, entity_type TEXT NOT NULL, mythic_id TEXT, model_id TEXT, max_health REAL NOT NULL, attack_damage REAL NOT NULL, move_speed REAL NOT NULL, integrity INTEGER NOT NULL, xp INTEGER NOT NULL, personality TEXT NOT NULL, role TEXT, favourite INTEGER NOT NULL DEFAULT 0, grp INTEGER NOT NULL DEFAULT 0, reinforcements INTEGER NOT NULL DEFAULT 0, claimed_at INTEGER NOT NULL, downed_until INTEGER NOT NULL DEFAULT 0)",
            "CREATE TABLE legion_state (id INTEGER PRIMARY KEY CHECK (id = 1), formation TEXT NOT NULL)",
            "INSERT INTO legion_state (id, formation) VALUES (1, 'VEIL')",
            "CREATE TABLE quest_progress (quest_id TEXT PRIMARY KEY, complete INTEGER NOT NULL DEFAULT 0, counters TEXT NOT NULL, updated_at INTEGER NOT NULL)",
            "CREATE TABLE story_flag (flag TEXT PRIMARY KEY, set_at INTEGER NOT NULL)",
            "CREATE TABLE owner_title (id TEXT PRIMARY KEY, unlocked_at INTEGER NOT NULL, selected INTEGER NOT NULL DEFAULT 0)",
            "CREATE TABLE mastery (ability_id TEXT PRIMARY KEY, uses INTEGER NOT NULL)",
            "CREATE TABLE combo_unlock (combo_id TEXT PRIMARY KEY, unlocked_at INTEGER NOT NULL)"
    );

    private final Plugin plugin;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "orison-db");
        t.setDaemon(true);
        return t;
    });
    private Connection connection;
    private Path file;

    public Database(Plugin plugin) { this.plugin = plugin; }

    public void open(int backupKeep) throws SQLException {
        try {
            Files.createDirectories(plugin.getDataFolder().toPath());
            file = plugin.getDataFolder().toPath().resolve("orison.db");
            backup(backupKeep);
        } catch (IOException e) {
            throw new SQLException("Could not prepare data folder/backup", e);
        }
        callBlocking(c -> { migrate(c); return null; });
    }

    private void backup(int keep) throws IOException {
        if (!Files.exists(file) || Files.size(file) == 0) return;
        Path dir = plugin.getDataFolder().toPath().resolve("backups");
        Files.createDirectories(dir);
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        Files.copy(file, dir.resolve("orison-" + stamp + ".db"), StandardCopyOption.REPLACE_EXISTING);
        try (Stream<Path> s = Files.list(dir)) {
            List<Path> old = s.filter(p -> p.getFileName().toString().startsWith("orison-"))
                    .sorted().toList();
            for (int i = 0; i < old.size() - keep; i++) Files.deleteIfExists(old.get(i));
        }
    }

    private Connection connection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try { Class.forName("org.sqlite.JDBC"); } catch (ClassNotFoundException ignored) { }
            connection = DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
            try (Statement st = connection.createStatement()) {
                st.execute("PRAGMA foreign_keys = ON");
                st.execute("PRAGMA journal_mode = WAL");
            }
        }
        return connection;
    }

    private void migrate(Connection c) throws SQLException {
        try (Statement st = c.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL)");
        }
        int current = schemaVersion(c);
        for (int v = current; v < MIGRATIONS.size(); v++) {
            c.setAutoCommit(false);
            try (Statement st = c.createStatement()) {
                st.execute(MIGRATIONS.get(v));
                st.execute("DELETE FROM schema_version");
                st.execute("INSERT INTO schema_version (version) VALUES (" + (v + 1) + ")");
                c.commit();
                plugin.getLogger().info("Database migrated to schema v" + (v + 1));
            } catch (SQLException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    private static int schemaVersion(Connection c) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT version FROM schema_version")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public int schemaVersion() {
        return callBlocking(Database::schemaVersion);
    }

    /** Runs on the DB thread, never the main thread. */
    public <T> CompletableFuture<T> submit(SqlFunction<T> work) {
        return CompletableFuture.supplyAsync(() -> {
            try { return work.apply(connection()); }
            catch (SQLException e) { throw new RuntimeException(e); }
        }, executor);
    }

    /** Startup/shutdown only. */
    public <T> T callBlocking(SqlFunction<T> work) {
        try { return submit(work).join(); }
        catch (RuntimeException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            throw new RuntimeException(cause);
        }
    }

    @Override
    public void close() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) executor.shutdownNow();
            if (connection != null) connection.close();
        } catch (Exception e) {
            plugin.getLogger().warning("Error closing database: " + e);
        }
    }
}
