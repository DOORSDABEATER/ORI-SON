package dev.des.orison.echo;

import dev.des.orison.OrisonPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.NPC;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Summoning, recall, orders and the Legion AI. Echoes are plain vanilla mobs of the original's body type (optionally
 * wearing its ModelEngine model); they are never MythicMobs, so no original encounter script can run on them.
 * Main thread only.
 */
public final class EchoService {

    public record SummonResult(boolean ok, String message) { }

    private static final class Active {
        final UUID echoId;
        UUID entityId;
        OrderType order = OrderType.FOLLOW;
        UUID focus;
        Location lastPos;
        int stuck;
        Active(UUID echoId) { this.echoId = echoId; }
    }

    private final OrisonPlugin plugin;
    private final NamespacedKey key;
    private final Map<UUID, Active> active = new LinkedHashMap<>();
    private final MiniMessage mm = MiniMessage.miniMessage();
    private BukkitTask task;
    private long tickCounter;
    private UUID threatId;
    private long threatUntil;
    private long lastErrorLog;

    public EchoService(OrisonPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "echo_id");
    }

    // ------------------------------------------------------------------ lifecycle

    public void start() {
        stop();
        int interval = Math.max(2, Math.min(40, plugin.getConfig().getInt("echo.ai-interval-ticks", 10)));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tickAi, 40L, interval);
        for (World w : Bukkit.getWorlds()) purgeOrphans(w);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    /** Plugin disable: remove every Echo entity, persist state. */
    public void shutdown() {
        stop();
        recallAll(false);
        plugin.echoRepo().flushDirtyBlocking();
    }

    // ------------------------------------------------------------------ identity helpers

    public boolean isEchoEntity(Entity e) { return e != null && e.getPersistentDataContainer().has(key, PersistentDataType.STRING); }

    public UUID echoIdOf(Entity e) {
        if (e == null) return null;
        String s = e.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        try { return s == null ? null : UUID.fromString(s); } catch (IllegalArgumentException ex) { return null; }
    }

    public int activeCount() { return active.size(); }

    public Mob mobOf(UUID echoId) {
        Active a = active.get(echoId);
        Entity e = a == null || a.entityId == null ? null : Bukkit.getEntity(a.entityId);
        return e instanceof Mob m ? m : null;
    }

    public void forEachActive(java.util.function.Consumer<Mob> fn) {
        for (UUID id : new ArrayList<>(active.keySet())) {
            Mob m = mobOf(id);
            if (m != null) fn.accept(m);
        }
    }
    public boolean isActive(UUID echoId) { return active.containsKey(echoId); }
    public Collection<UUID> activeIds() { return new ArrayList<>(active.keySet()); }
    public OrderType orderOf(UUID echoId) { Active a = active.get(echoId); return a == null ? null : a.order; }

    private Player owner() {
        UUID id = plugin.owners().owner().orElse(null);
        Player p = id == null ? null : Bukkit.getPlayer(id);
        return p != null && p.isOnline() ? p : null;
    }

    /** Removes tagged Echo entities nobody is tracking (crash leftovers, entities loaded from disk). */
    public int purgeOrphans(World w) {
        int removed = 0;
        Collection<UUID> tracked = new ArrayList<>();
        for (Active a : active.values()) if (a.entityId != null) tracked.add(a.entityId);
        for (Entity e : w.getEntities()) {
            if (isEchoEntity(e) && !tracked.contains(e.getUniqueId())) { e.remove(); removed++; }
        }
        return removed;
    }

    public void noteThreat(Entity attacker) {
        if (attacker instanceof LivingEntity && !(attacker instanceof Player) && !isEchoEntity(attacker)) {
            threatId = attacker.getUniqueId();
            threatUntil = System.currentTimeMillis() + 10_000;
        }
    }

    // ------------------------------------------------------------------ summon / recall

    public SummonResult summon(EchoRecord r) { return summon(r, 0); }

    /** @param extraCapacity temporary headroom above the configured active limit (e.g. a combo) */
    public SummonResult summon(EchoRecord r, int extraCapacity) {
        Player owner = owner();
        if (owner == null) return new SummonResult(false, "the owner is not present");
        long now = System.currentTimeMillis();
        if (r.downedUntil > now) return new SummonResult(false, "reforming for " + ((r.downedUntil - now + 999) / 1000) + "s");
        if (active.containsKey(r.id)) return new SummonResult(false, "already active");
        if (active.size() >= plugin.settings().echoActiveLimit() + Math.max(0, extraCapacity)) return new SummonResult(false, "the active Echo limit is reached");
        if (plugin.getConfig().getStringList("abilities.disabled-worlds").contains(owner.getWorld().getName())) {
            return new SummonResult(false, "ORISON cannot be used in this world");
        }
        EntityType type = ClaimService.resolveType(r.entityType);
        Class<? extends Entity> cls = type == null ? null : type.getEntityClass();
        if (cls == null || !Mob.class.isAssignableFrom(cls) || !type.isSpawnable()) {
            return new SummonResult(false, "its form cannot be reconstructed");
        }

        int idx = active.size();
        Location loc = slotLocation(owner, idx, idx + 1, plugin.echoRepo().formation());
        World w = loc.getWorld();
        Entity ent;
        try {
            @SuppressWarnings("unchecked") Class<Entity> spawnClass = (Class<Entity>) cls;
            ent = w.spawn(loc, spawnClass, e -> prepare(e, r));
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Echo spawn failed for " + r.identity, t);
            return new SummonResult(false, "the world refused it");
        }
        if (ent == null || !ent.isValid()) return new SummonResult(false, "the spawn was blocked here");

        if (r.modelId != null && plugin.getConfig().getBoolean("echo.apply-models", true)) plugin.models().apply(ent, r.modelId);

        Active a = new Active(r.id);
        a.entityId = ent.getUniqueId();
        active.put(r.id, a);
        fxEmerge(owner, loc);
        return new SummonResult(true, "summoned");
    }

    private void prepare(Entity e, EchoRecord r) {
        e.getPersistentDataContainer().set(key, PersistentDataType.STRING, r.id.toString());
        e.setPersistent(false);
        if (!(e instanceof Mob m)) return;
        m.setRemoveWhenFarAway(false);
        m.setCanPickupItems(false);
        m.setLootTable(null);
        if (m instanceof Ageable ageable) ageable.setAdult();
        double f = EchoMath.statScale(EchoMath.rankIndex(r.xp, r.integrity), r.integrity);
        AttributeInstance hp = m.getAttribute(Attribute.MAX_HEALTH);
        if (hp != null) {
            double v = Math.max(4, Math.min(1024, r.maxHealth * f));
            hp.setBaseValue(v);
            m.setHealth(v);
        }
        AttributeInstance atk = m.getAttribute(Attribute.ATTACK_DAMAGE);
        if (atk != null && r.attackDamage > 0) atk.setBaseValue(Math.max(1, r.attackDamage * f));
        AttributeInstance spd = m.getAttribute(Attribute.MOVEMENT_SPEED);
        if (spd != null && r.moveSpeed > 0) spd.setBaseValue(Math.min(0.6, r.moveSpeed));
        if (m.getEquipment() != null) for (EquipmentSlot s : EquipmentSlot.values()) m.getEquipment().setDropChance(s, 0f);
        m.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, PotionEffect.INFINITE_DURATION, 0, false, false));
        m.customName(nameOf(r));
        m.setCustomNameVisible(true);
    }

    private Component nameOf(EchoRecord r) {
        return Component.text(r.label() + " ", NamedTextColor.WHITE)
                .append(Component.text("[" + r.rank() + "]", NamedTextColor.DARK_GRAY));
    }

    public void recall(UUID echoId, boolean fx) {
        Active a = active.remove(echoId);
        if (a == null) return;
        Entity e = a.entityId == null ? null : Bukkit.getEntity(a.entityId);
        if (e != null) {
            if (fx) fxRecall(owner(), e.getLocation());
            e.remove();
        }
    }

    public void recallAll(boolean fx) {
        for (UUID id : new ArrayList<>(active.keySet())) recall(id, fx);
    }

    /** Echoes never die for good: they are undone and reform after a cooldown. */
    public void onEchoDeath(Entity e) {
        UUID id = echoIdOf(e);
        if (id == null) return;
        active.remove(id);
        EchoRecord r = plugin.echoRepo().echo(id);
        if (r == null) return;
        int secs = plugin.getConfig().getInt("echo.downed-seconds", 120);
        r.downedUntil = System.currentTimeMillis() + secs * 1000L;
        plugin.echoRepo().saveEcho(r);
        Player o = owner();
        plugin.audio().at(e.getLocation(), "echo.down", dev.des.orison.audio.AudioService.Kind.ECHO, 24, 1.0f);
        fxRecall(o, e.getLocation());
        if (o != null) o.sendMessage(mm.deserialize("<gray>" + mm.escapeTags(r.label()) + " was undone. It will reform in " + secs + "s."));
    }

    public void awardXp(UUID echoId, long xp) {
        if (echoId == null) return;
        EchoRecord r = plugin.echoRepo().echo(echoId);
        if (r == null) return;
        Rank before = r.rank();
        r.xp += xp;
        plugin.echoRepo().markDirty(r.id);
        if (r.rank() != before) {
            plugin.quests().event(dev.des.orison.quest.ObjectiveType.ECHO_RANK, "", r.rank().ordinal());
            Player o = owner();
            if (o != null) o.sendMessage(mm.deserialize("<gray>" + mm.escapeTags(r.label()) + " advanced to <white>" + r.rank() + "<gray>."));
            Active a = active.get(r.id);
            Entity e = a == null || a.entityId == null ? null : Bukkit.getEntity(a.entityId);
            if (e != null) e.customName(nameOf(r));
        }
    }

    // ------------------------------------------------------------------ orders

    /** @return how many active Echoes took the order */
    public int order(Collection<UUID> echoIds, OrderType type, LivingEntity focus) {
        int n = 0;
        for (UUID id : new ArrayList<>(echoIds)) {
            Active a = active.get(id);
            if (a == null) continue;
            if (type == OrderType.RETURN) { recall(id, true); n++; continue; }
            a.order = type;
            a.focus = type == OrderType.FOCUS && focus != null ? focus.getUniqueId() : null;
            n++;
        }
        return n;
    }

    // ------------------------------------------------------------------ AI

    private void tickAi() {
        tickCounter++;
        Player owner = owner();
        if (owner == null || owner.isDead()) {
            if (!active.isEmpty()) recallAll(false);
            return;
        }
        if (tickCounter % Math.max(1, 1200 / Math.max(1, plugin.getConfig().getInt("echo.ai-interval-ticks", 10))) == 0) {
            plugin.echoRepo().flushDirtyAsync();
        }
        int n = active.size(), i = 0;
        for (Iterator<Active> it = active.values().iterator(); it.hasNext(); i++) {
            Active a = it.next();
            if (n > 6 && (tickCounter + i) % 2 != 0) continue; // performance: half rate when crowded
            Entity ent = a.entityId == null ? null : Bukkit.getEntity(a.entityId);
            if (!(ent instanceof Mob m) || !m.isValid() || m.isDead()) { it.remove(); continue; }
            try {
                think(owner, a, m, i, n);
            } catch (Throwable t) {
                long now = System.currentTimeMillis();
                if (now - lastErrorLog > 30_000) { lastErrorLog = now; plugin.getLogger().log(Level.WARNING, "Echo AI error (rate-limited)", t); }
            }
        }
    }

    private void think(Player owner, Active a, Mob m, int idx, int n) {
        EchoRecord r = plugin.echoRepo().echo(a.echoId);
        if (r == null) { m.remove(); return; }
        Location ml = m.getLocation(), ol = owner.getLocation();
        double tp = plugin.getConfig().getDouble("echo.teleport-distance", 32);
        if (ml.getWorld() != ol.getWorld() || ml.distanceSquared(ol) > tp * tp) {
            m.teleport(slotLocation(owner, idx, n, formationFor(a)));
            m.setTarget(null);
            a.stuck = 0;
            return;
        }
        Personality ps = r.personality;
        LivingEntity target = null;
        switch (a.order) {
            case STAY -> target = pick(owner, m, 3.0, 99, false, ps);
            case ATTACK -> target = pick(owner, m, ps.aggroRange * 1.25, ps.leash * 1.5, false, ps);
            case FOCUS -> {
                LivingEntity f = a.focus == null ? null : (Bukkit.getEntity(a.focus) instanceof LivingEntity le ? le : null);
                if (f != null && f.isValid() && !f.isDead() && canFocus(f)) target = f;
                else { a.order = OrderType.FOLLOW; a.focus = null; }
            }
            case DEFEND -> target = pick(owner, m, 8, 8, true, ps);
            case PROTECT -> target = pick(owner, m, 6, 6, true, ps);
            default -> target = pick(owner, m, ps.aggroRange, ps.leash, ps == Personality.DEFENSIVE || ps == Personality.SUPPORT, ps);
        }
        if (m.getTarget() != target) m.setTarget(target);

        boolean wantsMove = target == null && a.order != OrderType.STAY;
        if (wantsMove) {
            Location slot = slotLocation(owner, idx, n, formationFor(a));
            double d2 = ml.distanceSquared(slot);
            if (d2 > 2.25) {
                m.getPathfinder().moveTo(slot, 1.25);
                if (a.lastPos != null && a.lastPos.getWorld() == ml.getWorld() && a.lastPos.distanceSquared(ml) < 0.06 && d2 > 36) a.stuck++;
                else a.stuck = 0;
                if (a.stuck >= 4) { m.teleport(slot); a.stuck = 0; }
            } else {
                m.getPathfinder().stopPathfinding();
                a.stuck = 0;
            }
        } else {
            a.stuck = 0;
        }
        a.lastPos = ml;
    }

    private Formation formationFor(Active a) {
        return a.order == OrderType.PROTECT ? Formation.SOVEREIGN : plugin.echoRepo().formation();
    }

    private boolean canFocus(LivingEntity e) {
        return !(e instanceof Player) && !isEchoEntity(e) && !(e instanceof NPC) && !(e instanceof ArmorStand)
                && !(e instanceof Tameable t && t.isTamed());
    }

    private boolean hostile(LivingEntity e) {
        return e.isValid() && !e.isDead() && e instanceof Enemy && canFocus(e);
    }

    private LivingEntity pick(Player owner, Mob m, double range, double leash, boolean onlyThreats, Personality ps) {
        LivingEntity best = null;
        double bestScore = -1e9;
        boolean threatFresh = threatId != null && System.currentTimeMillis() < threatUntil;
        int scanned = 0;
        Location ol = owner.getLocation();
        for (LivingEntity e : m.getWorld().getNearbyLivingEntities(m.getLocation(), range)) {
            if (++scanned > 40) break;
            if (!hostile(e)) continue;
            double dOwner = e.getLocation().distance(ol);
            if (dOwner > leash + 6) continue;
            boolean targetsOwner = e instanceof Mob em && owner.equals(em.getTarget());
            boolean isThreat = threatFresh && e.getUniqueId().equals(threatId);
            if (onlyThreats && !targetsOwner && !isThreat && dOwner > 8) continue;
            double score = -m.getLocation().distance(e.getLocation());
            if (targetsOwner) score += 100;
            if (isThreat) score += 60;
            if (ps == Personality.TACTICAL) score += (1 - e.getHealth() / Math.max(1, e.getMaxHealth())) * 20;
            if (score > bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    // ------------------------------------------------------------------ placement + fx

    public Location slotLocation(Player owner, int idx, int n, Formation f) {
        Formations.Slot s = Formations.slot(f, idx, n);
        Location o = owner.getLocation();
        double yaw = Math.toRadians(o.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        Location l = o.clone().add(fx * s.forward() + rx * s.right(), 0, fz * s.forward() + rz * s.right());
        return safe(l) ? l : (safe(l.clone().add(0, 1, 0)) ? l.clone().add(0, 1, 0) : o);
    }

    private static boolean safe(Location l) {
        Block b = l.getBlock();
        return b.isPassable() && !b.isLiquid() && b.getRelative(0, 1, 0).isPassable();
    }

    private void fxEmerge(Player owner, Location l) {
        plugin.audio().at(l, "echo.emerge", dev.des.orison.audio.AudioService.Kind.ECHO, 30, 1.0f);
        if (owner != null && plugin.vfx().usable(owner)) {
            plugin.vfxLib().gate(l, l.getYaw() + 90f, 1.0f, 18);
            plugin.vfxLib().beam(l, 3.5f, 16);
            plugin.vfxLib().shock(l, 1.8f, 12);
        } else {
            l.getWorld().spawnParticle(Particle.END_ROD, l.clone().add(0, 1, 0), 14, 0.3, 0.7, 0.3, 0.02);
        }
    }

    private void fxRecall(Player owner, Location l) {
        plugin.audio().at(l, "echo.recall", dev.des.orison.audio.AudioService.Kind.ECHO, 24, 1.0f);
        if (owner != null && plugin.vfx().usable(owner)) {
            plugin.vfxLib().gate(l, l.getYaw() + 90f, 0.9f, 14);
            plugin.vfxLib().shock(l, 1.4f, 10);
        } else {
            l.getWorld().spawnParticle(Particle.WHITE_ASH, l.clone().add(0, 1, 0), 14, 0.3, 0.7, 0.3, 0.02);
        }
    }

    public List<EchoRecord> activeRecords() {
        List<EchoRecord> out = new ArrayList<>();
        for (UUID id : active.keySet()) { EchoRecord r = plugin.echoRepo().echo(id); if (r != null) out.add(r); }
        return out;
    }
}
