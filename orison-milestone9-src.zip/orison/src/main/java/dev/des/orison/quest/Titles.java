package dev.des.orison.quest;

import java.util.LinkedHashMap;
import java.util.Map;

/** Title ids -> display text. stage_N titles are granted automatically on reaching stage N. */
public final class Titles {
    private Titles() { }

    private static final Map<String, String> ALL = new LinkedHashMap<>();
    static {
        for (int s = 1; s <= 7; s++) ALL.put("stage_" + s, Stages.subtitle(s));
        ALL.put("legion_sovereign", "LEGION SOVEREIGN");
        ALL.put("unbroken", "THE UNBROKEN");
        ALL.put("hunter_unwritten", "HUNTER OF THE UNWRITTEN");
        ALL.put("the_exception", "THE EXCEPTION");
    }

    public static Map<String, String> all() { return ALL; }
    public static String display(String id) { return ALL.getOrDefault(id, id.toUpperCase()); }
    public static boolean exists(String id) { return ALL.containsKey(id); }
}
