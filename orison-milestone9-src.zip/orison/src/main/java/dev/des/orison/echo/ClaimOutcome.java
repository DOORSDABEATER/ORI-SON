package dev.des.orison.echo;

public enum ClaimOutcome { ACCEPTED, RESISTED, INCOMPLETE, UNRECOGNIZED, SEALED, IRREGULAR }
