package dev.des.orison.mastery;

import dev.des.orison.persistence.Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Per-ability use counts -> mastery level. Main-thread mutation; written to the database in batches. */
public final class MasteryService {
    private final Database db;
    private final Map<String, Integer> uses = new HashMap<>();
    private final Set<String> dirty = new HashSet<>();

    public MasteryService(Database db) { this.db = db; }

    public void loadBlocking() {
        Map<String, Integer> loaded = db.callBlocking(c -> {
            Map<String, Integer> m = new HashMap<>();
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT ability_id, uses FROM mastery")) {
                while (rs.next()) m.put(rs.getString(1), rs.getInt(2));
            }
            return m;
        });
        uses.putAll(loaded);
    }

    public int uses(String abilityId) { return uses.getOrDefault(abilityId, 0); }
    public int level(String abilityId) { return MasteryMath.level(uses(abilityId)); }
    public double costFactor(String abilityId) { return MasteryMath.costFactor(level(abilityId)); }
    public double cooldownFactor(String abilityId) { return MasteryMath.cooldownFactor(level(abilityId)); }

    /** @return the new level if this use raised it, else -1 */
    public int record(String abilityId) {
        int before = level(abilityId);
        uses.merge(abilityId, 1, Integer::sum);
        dirty.add(abilityId);
        int after = level(abilityId);
        return after > before ? after : -1;
    }

    private Map<String, Integer> drain() {
        Map<String, Integer> out = new HashMap<>();
        for (String id : dirty) out.put(id, uses.getOrDefault(id, 0));
        dirty.clear();
        return out;
    }

    public void flushAsync() {
        Map<String, Integer> batch = drain();
        if (batch.isEmpty()) return;
        db.submit(c -> { write(c, batch); return null; });
    }

    public void flushBlocking() {
        Map<String, Integer> batch = drain();
        if (batch.isEmpty()) return;
        db.callBlocking(c -> { write(c, batch); return null; });
    }

    private static void write(java.sql.Connection c, Map<String, Integer> batch) throws java.sql.SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT OR REPLACE INTO mastery (ability_id, uses) VALUES (?, ?)")) {
            for (Map.Entry<String, Integer> e : batch.entrySet()) {
                ps.setString(1, e.getKey());
                ps.setInt(2, e.getValue());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }
}
