package dev.des.orison;

import dev.des.orison.ability.AbilityEngine;
import dev.des.orison.ability.AbilityRegistry;
import dev.des.orison.ability.ParadoxService;
import dev.des.orison.ability.impl.InvalidAbility;
import dev.des.orison.ability.impl.StepBetweenAbility;
import dev.des.orison.ability.impl.UnseenAbility;
import dev.des.orison.command.OrisonCommand;
import dev.des.orison.config.OrisonConfig;
import dev.des.orison.core.ModuleManager;
import dev.des.orison.audio.AudioService;
import dev.des.orison.azriel.AzrielService;
import dev.des.orison.combat.CombatState;
import dev.des.orison.combo.ComboEngine;
import dev.des.orison.domain.DomainService;
import dev.des.orison.ability.impl.AdvancedAbilities;
import dev.des.orison.ability.impl.AwakenAbility;
import dev.des.orison.ability.impl.AwakenAllAbility;
import dev.des.orison.ability.impl.AwakenOneAbility;
import dev.des.orison.diagnostics.CompatReport;
import dev.des.orison.echo.ClaimService;
import dev.des.orison.echo.EchoListener;
import dev.des.orison.echo.EchoRepository;
import dev.des.orison.echo.EchoService;
import dev.des.orison.echo.HuntTracker;
import dev.des.orison.echo.MythicAdapter;
import dev.des.orison.mastery.MasteryService;
import dev.des.orison.quest.QuestService;
import dev.des.orison.transform.TransformationService;
import dev.des.orison.ability.impl.ContradictionAbility;
import dev.des.orison.ability.impl.TransformAbility;
import dev.des.orison.echo.ModelAdapter;
import dev.des.orison.diagnostics.DiagnosticsModule;
import dev.des.orison.owner.OwnerService;
import dev.des.orison.persistence.AuditLog;
import dev.des.orison.persistence.Database;
import dev.des.orison.presence.PresenceListener;
import dev.des.orison.presence.PresenceService;
import dev.des.orison.progress.ProgressService;
import dev.des.orison.status.StatusListener;
import dev.des.orison.status.StatusManager;
import dev.des.orison.vfx.DisplayVfx;
import dev.des.orison.vfx.VfxLibrary;
import dev.des.orison.vfx.VfxListener;
import dev.des.orison.vfx.VfxOverlay;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;
import java.util.UUID;

public final class OrisonPlugin extends JavaPlugin {

    private OrisonConfig settings;
    private Database database;
    private AuditLog audit;
    private OwnerService owners;
    private ProgressService progress;
    private ParadoxService paradox;
    private AbilityRegistry registry;
    private AbilityEngine engine;
    private StatusManager statuses;
    private PresenceService presence;
    private DisplayVfx vfx;
    private MasteryService mastery;
    private AudioService audio;
    private AzrielService azriel;
    private CombatState combat;
    private ComboEngine combos;
    private DomainService domains;
    private QuestService quests;
    private TransformationService transform;
    private EchoRepository echoRepo;
    private EchoService echo;
    private ClaimService claims;
    private HuntTracker hunts;
    private MythicAdapter mythic;
    private ModelAdapter models;
    private VfxLibrary vfxLib;
    private VfxOverlay vfxOverlay;
    private ModuleManager modules;
    private volatile boolean debug;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = OrisonConfig.load(this);
        debug = settings.debug();

        database = new Database(this);
        try {
            database.open(settings.backupKeep());
        } catch (SQLException | RuntimeException e) {
            getLogger().severe("Database failed to open; disabling ORISON: " + e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        audit = new AuditLog(this, database);
        owners = new OwnerService(this, database, audit);
        try {
            owners.loadBlocking();
            seedInitialOwner();
            progress = new ProgressService(database);
            progress.loadBlocking();
            echoRepo = new EchoRepository(database);
            echoRepo.loadBlocking();
            mastery = new MasteryService(database);
            mastery.loadBlocking();
            quests = new QuestService(this);
            quests.loadBlocking();
            quests.syncTitles();
            combos = new ComboEngine(this);
            combos.loadBlocking();
        } catch (RuntimeException e) {
            getLogger().severe("Could not load owner/progress state; disabling ORISON: " + e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        paradox = new ParadoxService(this);
        registry = new AbilityRegistry(this);
        registry.load();
        statuses = new StatusManager(this);
        engine = new AbilityEngine(this);
        engine.register(new UnseenAbility(this));
        engine.register(new StepBetweenAbility());
        engine.register(new InvalidAbility(this));
        mythic = new MythicAdapter(this);
        models = new ModelAdapter(this);
        hunts = new HuntTracker(this);
        claims = new ClaimService(this);
        echo = new EchoService(this);
        engine.register(new AwakenAbility(this));
        engine.register(new AwakenOneAbility(this));
        engine.register(new AwakenAllAbility(this));
        getServer().getPluginManager().registerEvents(hunts, this);
        getServer().getPluginManager().registerEvents(new EchoListener(this), this);
        echo.start();
        transform = new TransformationService(this);
        combat = new CombatState(this);
        domains = new DomainService(this);
        azriel = new AzrielService(this);
        getServer().getPluginManager().registerEvents(azriel, this);
        AdvancedAbilities.registerAll(this, engine);
        for (int lvl = 1; lvl <= 4; lvl++) engine.register(new TransformAbility(this, lvl));
        engine.register(new ContradictionAbility(this));
        // batch persistence of quest progress and mastery, snapshotted on the main thread
        getServer().getScheduler().runTaskTimer(this, () -> { quests.flushAsync(); mastery.flushAsync(); }, 600L, 600L);

        getServer().getPluginManager().registerEvents(new StatusListener(this), this);
        audio = new AudioService(this);
        vfx = new DisplayVfx(this);
        vfxLib = new VfxLibrary(vfx);
        vfxOverlay = new VfxOverlay(vfx);
        getServer().getPluginManager().registerEvents(new VfxListener(this), this);
        vfx.start();
        presence = new PresenceService(this);
        getServer().getPluginManager().registerEvents(new PresenceListener(this), this);
        presence.start();

        PluginCommand cmd = getCommand("orison");
        if (cmd != null) {
            OrisonCommand handler = new OrisonCommand(this);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }

        // Persist PARADOX at most once a minute, and only when it changed.
        getServer().getScheduler().runTaskTimerAsynchronously(this, () -> progress.flushAsync(), 1200L, 1200L);

        modules = new ModuleManager(getLogger());
        modules.register(new DiagnosticsModule(this));
        modules.enableAll();

        getLogger().info("ORISON online. Owner bound: " + owners.owner().isPresent()
                + ", abilities defined: " + registry.all().size());
    }

    @Override
    public void onDisable() {
        if (modules != null) modules.disableAll();
        // end statuses first: their cleanup may still spawn effects, so the VFX engine must still be running
        if (statuses != null) statuses.endEverything();
        if (azriel != null) azriel.shutdown();
        if (domains != null) domains.shutdown();
        if (combat != null) combat.shutdown();
        if (echo != null) echo.shutdown();
        if (presence != null) presence.stop();
        if (vfx != null) vfx.stop();
        if (quests != null) quests.flushBlocking();
        if (mastery != null) mastery.flushBlocking();
        if (progress != null) progress.flushBlocking();
        if (database != null) database.close();
    }

    private void seedInitialOwner() {
        if (owners.owner().isPresent()) return;
        String raw = settings.initialOwnerUuid();
        if (raw.isBlank()) {
            getLogger().warning("No ORISON owner is bound. Set owner.initial-uuid or use /orison admin grant.");
            return;
        }
        try {
            owners.bindBlocking(UUID.fromString(raw.trim()), "CONFIG", "SEED");
        } catch (IllegalArgumentException e) {
            getLogger().severe("owner.initial-uuid is not a valid UUID; ignoring it.");
        }
    }

    public void reloadSettings() {
        reloadConfig();
        settings = OrisonConfig.load(this);
        debug = settings.debug();
        registry.load();
        if (vfx != null) vfx.reload();
        if (presence != null) presence.reload();
        if (modules != null) modules.reloadAll();
    }

    public OrisonConfig settings() { return settings; }
    public Database database() { return database; }
    public AuditLog audit() { return audit; }
    public OwnerService owners() { return owners; }
    public ProgressService progress() { return progress; }
    public ParadoxService paradox() { return paradox; }
    public AbilityRegistry registry() { return registry; }
    public AbilityEngine engine() { return engine; }
    public StatusManager statuses() { return statuses; }
    public PresenceService presence() { return presence; }
    public DisplayVfx vfx() { return vfx; }
    public MasteryService mastery() { return mastery; }
    public AudioService audio() { return audio; }
    public AzrielService azriel() { return azriel; }
    public CombatState combat() { return combat; }
    public ComboEngine combos() { return combos; }
    public DomainService domains() { return domains; }
    public QuestService quests() { return quests; }
    public TransformationService transform() { return transform; }
    public EchoRepository echoRepo() { return echoRepo; }
    public EchoService echo() { return echo; }
    public ClaimService claims() { return claims; }
    public HuntTracker hunts() { return hunts; }
    public MythicAdapter mythic() { return mythic; }
    public ModelAdapter models() { return models; }
    public VfxLibrary vfxLib() { return vfxLib; }
    public VfxOverlay vfxOverlay() { return vfxOverlay; }
    public CompatReport compat() { return CompatReport.scan(this); }

    public boolean debugEnabled() { return debug; }
    public void setDebug(boolean value) { this.debug = value; }

    public void debug(String message) {
        if (debug) getLogger().info("[debug] " + message);
    }
}
