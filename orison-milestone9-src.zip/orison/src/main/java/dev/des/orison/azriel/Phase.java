package dev.des.orison.azriel;

/** The five Azriel Protocol phases, in order. */
public enum Phase {
    RECOGNITION_FAILURE(1, "RECOGNITION FAILURE"),
    AUTHORITY_CONFLICT(2, "AUTHORITY CONFLICT"),
    IMPOSSIBLE_RECORD(3, "IMPOSSIBLE RECORD"),
    THE_THING_THAT_NEVER_WAS(4, "THE THING THAT NEVER WAS"),
    FINAL_OMISSION(5, "FINAL OMISSION");

    public final int number;
    public final String title;

    Phase(int number, String title) {
        this.number = number;
        this.title = title;
    }

    public static Phase of(int n) { return values()[Math.max(1, Math.min(5, n)) - 1]; }
    public Phase next() { return this == FINAL_OMISSION ? this : values()[ordinal() + 1]; }
}
