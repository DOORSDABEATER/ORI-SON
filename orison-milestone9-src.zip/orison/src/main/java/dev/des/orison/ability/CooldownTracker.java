package dev.des.orison.ability;

import java.util.HashMap;
import java.util.Map;

/** Per-ability cooldowns, fully independent of PARADOX cost. Main thread only. */
public final class CooldownTracker {
    private final Map<String, Long> readyAtNanos = new HashMap<>();

    public long remainingMillis(String abilityId) {
        Long t = readyAtNanos.get(abilityId);
        if (t == null) return 0;
        long left = t - System.nanoTime();
        if (left <= 0) { readyAtNanos.remove(abilityId); return 0; }
        return left / 1_000_000L;
    }

    public void start(String abilityId, double seconds) {
        if (seconds <= 0) return;
        readyAtNanos.put(abilityId, System.nanoTime() + (long) (seconds * 1_000_000_000L));
    }

    public void clear() { readyAtNanos.clear(); }
}
