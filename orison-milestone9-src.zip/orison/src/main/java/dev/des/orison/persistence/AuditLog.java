package dev.des.orison.persistence;

import org.bukkit.plugin.Plugin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/** Append-only record of sensitive actions: written to the database and to the server log. */
public final class AuditLog {
    private final Plugin plugin;
    private final Database db;

    public AuditLog(Plugin plugin, Database db) {
        this.plugin = plugin;
        this.db = db;
    }

    public void record(String actor, String action, String detail) {
        plugin.getLogger().info("[AUDIT] " + actor + " " + action + " " + detail);
        db.submit(c -> { insert(c, actor, action, detail); return null; })
          .exceptionally(t -> { plugin.getLogger().severe("Audit write failed: " + t); return null; });
    }

    /** For use inside an existing transaction so the audit row commits atomically with the change. */
    public static void insert(Connection c, String actor, String action, String detail) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO audit_log (ts, actor, action, detail) VALUES (?, ?, ?, ?)")) {
            ps.setLong(1, System.currentTimeMillis());
            ps.setString(2, actor);
            ps.setString(3, action);
            ps.setString(4, detail);
            ps.executeUpdate();
        }
    }
}
