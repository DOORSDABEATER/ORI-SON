package dev.des.orison.echo;

public enum OrderType { FOLLOW, STAY, ATTACK, DEFEND, PROTECT, FOCUS, RETURN }
