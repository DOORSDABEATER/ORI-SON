package dev.des.orison.combo;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Pure combo matching (unit tested). */
public final class ComboLogic {
    private ComboLogic() { }

    public record Cast(String abilityId, long atMillis, UUID target) { }

    /** The combo completed by casting {@code abilityId} (on {@code target}) at {@code now}, or null. History is oldest-first. */
    public static ComboDef find(List<ComboDef> combos, List<Cast> history, String abilityId, UUID target, long now) {
        for (ComboDef c : combos) {
            if (!c.second().equals(abilityId)) continue;
            for (int i = history.size() - 1; i >= 0; i--) {
                Cast h = history.get(i);
                if (!h.abilityId().equals(c.first())) continue;
                long age = now - h.atMillis();
                if (age < 0 || age > (long) (c.windowSeconds() * 1000)) break;       // newest first-cast is too old: no match
                if (c.sameTarget() && (target == null || !Objects.equals(target, h.target()))) break;
                return c;
            }
        }
        return null;
    }

    /** Drops casts older than the longest window so the history stays tiny. */
    public static void prune(List<Cast> history, long now, long maxAgeMillis, int maxSize) {
        history.removeIf(c -> now - c.atMillis() > maxAgeMillis);
        while (history.size() > maxSize) history.remove(0);
    }
}
