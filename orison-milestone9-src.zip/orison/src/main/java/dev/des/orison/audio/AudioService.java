package dev.des.orison.audio;

import dev.des.orison.OrisonPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

/**
 * ORISON's sound layer. Plays the pack's custom sounds ("orison:<event>") only to clients that have loaded the pack, with
 * per-category volume settings (accessibility), distance-aware range and simple rate limiting. Events are defined in
 * tools/sounds.py and shipped in sounds.json. Main thread only.
 */
public final class AudioService {
    public enum Kind { ABILITY, PRESENCE, ECHO, UI }

    private final OrisonPlugin plugin;
    private final Map<String, Long> lastPlayed = new HashMap<>();

    public AudioService(OrisonPlugin plugin) { this.plugin = plugin; }

    private boolean enabled() { return plugin.getConfig().getBoolean("audio.enabled", true); }

    private double volumeFor(Kind k) {
        var c = plugin.getConfig();
        double master = plugin.settings().audioVolume();
        return master * switch (k) {
            case ABILITY -> c.getDouble("audio.ability-volume", 1.0);
            case PRESENCE -> c.getDouble("audio.presence-volume", 0.5);
            case ECHO -> c.getDouble("audio.echo-volume", 1.0);
            case UI -> c.getDouble("audio.ui-volume", 0.8);
        };
    }

    /** True if this event was played too recently (ms) to play again. */
    private boolean throttled(String event, long ms) {
        long now = System.currentTimeMillis();
        Long last = lastPlayed.get(event);
        if (last != null && now - last < ms) return true;
        lastPlayed.put(event, now);
        return false;
    }

    /** Spatial sound at a location. range is in blocks (vanilla sounds carry about 16 blocks per 1.0 volume). */
    public void at(Location l, String event, Kind kind, double range, float pitch) {
        if (!enabled() || l.getWorld() == null) return;
        double vol = volumeFor(kind);
        if (vol <= 0.001) return;
        float v = (float) Math.min(4.0, vol * Math.max(0.25, range / 16.0));
        String key = "orison:" + event;
        double r2 = range * range;
        for (Player p : l.getWorld().getPlayers()) {
            if (!plugin.vfx().hasPack(p) || p.getLocation().distanceSquared(l) > r2) continue;
            p.playSound(l, key, SoundCategory.PLAYERS, v, pitch);
        }
    }

    /** Non-spatial sound for one player (interface feedback). */
    public void to(Player p, String event, Kind kind, float pitch) {
        if (!enabled() || !plugin.vfx().hasPack(p)) return;
        double vol = volumeFor(kind);
        if (vol <= 0.001) return;
        p.playSound(p.getLocation(), "orison:" + event, SoundCategory.PLAYERS, (float) Math.min(2.0, vol), pitch);
    }

    /** Several layers with tick offsets, e.g. cinematic sequences. Offsets are short and the task count is bounded by callers. */
    public void layered(Location l, Kind kind, double range, String[] events, int[] delays) {
        for (int i = 0; i < events.length; i++) {
            final String ev = events[i];
            if (delays[i] <= 0) at(l, ev, kind, range, 1.0f);
            else Bukkit.getScheduler().runTaskLater(plugin, () -> at(l, ev, kind, range, 1.0f), delays[i]);
        }
    }

    // ------------------------------------------------------------------ named hooks

    public void authority(Player p, String authorityKey) {
        at(p.getLocation(), "authority." + authorityKey, Kind.ABILITY, 28, 1.0f);
    }

    public void fail(Player p) {
        if (throttled("ability.fail:" + p.getUniqueId(), 600)) return;
        to(p, "ability.fail", Kind.UI, 1.0f);
    }

    public void step(Location l, int tier) {
        if (tier <= 0 || throttled("step", 180)) return;
        String[] n = {"", "absence", "sovereign", "unwritten", "beyond"};
        at(l, "presence.step." + n[Math.min(4, tier)], Kind.PRESENCE, 14, 0.95f + (float) (Math.random() * 0.1));
    }

    public void land(Location l, double strength) {
        if (throttled("land", 250)) return;
        at(l, "presence.land", Kind.PRESENCE, 20 + 8 * strength, (float) (1.1 - 0.15 * strength));
    }

    public void transformation(Location l, int level) {
        if (level < 1 || level > 4) return;
        at(l, "transform.level_" + level, Kind.ABILITY, 32 + 8 * level, 1.0f);
    }

    public void claim(Player p, String outcome) {
        to(p, "claim." + outcome.toLowerCase(), Kind.ECHO, 1.0f);
    }
}
