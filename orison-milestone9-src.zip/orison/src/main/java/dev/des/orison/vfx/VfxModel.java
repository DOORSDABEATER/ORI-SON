package dev.des.orison.vfx;

import org.bukkit.NamespacedKey;

/** Item-model ids shipped in the resource pack (assets/orison/items/&lt;name&gt;.json). */
public enum VfxModel {
    FRACTURE, RING, SHOCK, RIFT, CUT, GATE, BEAM, SHIELD, SHARD_A, SHARD_B, SHARD_C, SHARD_D, SILHOUETTE, EYES;

    private final NamespacedKey key = NamespacedKey.fromString("orison:" + name().toLowerCase());

    public NamespacedKey key() { return key; }
}
