package dev.des.orison.core;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Enables modules in order, disables in reverse, and isolates failures so one module cannot take down the rest. */
public final class ModuleManager {
    private final Logger log;
    private final List<OrisonModule> registered = new ArrayList<>();
    private final List<OrisonModule> active = new ArrayList<>();

    public ModuleManager(Logger log) { this.log = log; }

    public void register(OrisonModule module) { registered.add(module); }

    public void enableAll() {
        for (OrisonModule m : registered) {
            try {
                m.enable();
                active.add(m);
            } catch (Throwable t) {
                log.log(Level.SEVERE, "Module '" + m.id() + "' failed to enable", t);
            }
        }
    }

    public void reloadAll() {
        for (OrisonModule m : active) {
            try { m.reload(); }
            catch (Throwable t) { log.log(Level.WARNING, "Module '" + m.id() + "' failed to reload", t); }
        }
    }

    public void disableAll() {
        for (int i = active.size() - 1; i >= 0; i--) {
            OrisonModule m = active.get(i);
            try { m.disable(); }
            catch (Throwable t) { log.log(Level.WARNING, "Module '" + m.id() + "' failed to disable", t); }
        }
        active.clear();
    }
}
