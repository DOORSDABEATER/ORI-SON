package dev.des.orison.vfx;

import dev.des.orison.vfx.DisplayVfx.Handle;
import dev.des.orison.vfx.DisplayVfx.Spec;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.Random;
import java.util.function.Supplier;

/**
 * The reusable model-based effect families. Every recipe returns its Handle, or null when the display
 * budget is exhausted / models are unavailable so the caller can fall back to particles.
 *
 * Model conventions (see tools/build_pack.py): the entity location is the model's centre. Horizontal planes
 * lie at the entity's height, vertical planes face the display's yaw, the humanoid silhouette's feet sit
 * 1.0 block below its anchor.
 */
public final class VfxLibrary {
    private final DisplayVfx vfx;
    private final Random rng = new Random();

    public VfxLibrary(DisplayVfx vfx) { this.vfx = vfx; }

    private static Transformation tf(float sx, float sy, float sz, float yawDeg) {
        return new Transformation(new Vector3f(), new AxisAngle4f((float) Math.toRadians(yawDeg), 0, 1, 0),
                new Vector3f(sx, sy, sz), new AxisAngle4f());
    }

    private static Location at(Location l, double dy) { return new Location(l.getWorld(), l.getX(), l.getY() + dy, l.getZ()); }

    /** Black-and-white crack decal on the ground that snaps open then dissolves. */
    public Handle fracture(Location ground, float size, int life) {
        float yaw = rng.nextFloat() * 360f;
        return vfx.spawn(new Spec(VfxModel.FRACTURE, at(ground, 0.02)).life(life)
                .start(tf(size * 0.15f, 1f, size * 0.15f, yaw))
                .frame(1, tf(size, 1f, size, yaw), 3)
                .frame(Math.max(2, life - 8), tf(size * 0.1f, 1f, size * 0.1f, yaw + 20f), 8));
    }

    /** Fractured ring on the ground expanding to the given radius. */
    public Handle ring(Location ground, float radius, int life) { return expanding(VfxModel.RING, ground, radius, life); }

    /** Monochrome shockwave expanding to the given radius. */
    public Handle shock(Location ground, float radius, int life) { return expanding(VfxModel.SHOCK, ground, radius, life); }

    private Handle expanding(VfxModel m, Location ground, float radius, int life) {
        float d = radius * 2f;
        int grow = Math.max(2, (int) (life * 0.7));
        return vfx.spawn(new Spec(m, at(ground, 0.03)).life(life)
                .start(tf(d * 0.1f, 1f, d * 0.1f, 0))
                .frame(1, tf(d * 0.85f, 1f, d * 0.85f, 25f), grow)
                .frame(grow + 1, tf(d, 1f, d, 40f), Math.max(1, life - grow - 1)));
    }

    /** Vertical tear in space, splitting open and closing again. yaw: facing of the tear's plane. */
    public Handle rift(Location base, float yaw, float height, int life) {
        float w = height * 0.25f;
        return vfx.spawn(new Spec(VfxModel.RIFT, at(base, height / 2.0)).life(life)
                .start(tf(0.02f, height * 0.1f, 1f, yaw))
                .frame(1, tf(w, height, 1f, yaw), 3)
                .frame(Math.max(2, life - 8), tf(0.01f, height, 1f, yaw), 8));
    }

    /** A spatial cut: a blade-shaped slash drawn between two points. */
    public Handle cut(Location from, Location to, int life) {
        double dx = to.getX() - from.getX(), dz = to.getZ() - from.getZ();
        double len = Math.max(0.6, Math.hypot(dx, dz));
        float yawDeg = (float) Math.toDegrees(Math.atan2(-dz, dx));
        float h = (float) Math.max(0.4, Math.min(1.3, len / 4.0));
        Location mid = new Location(from.getWorld(), (from.getX() + to.getX()) / 2, (from.getY() + to.getY()) / 2, (from.getZ() + to.getZ()) / 2);
        return vfx.spawn(new Spec(VfxModel.CUT, mid).life(life)
                .start(tf((float) len, 0.02f, 1f, yawDeg))
                .frame(1, tf((float) len, h, 1f, yawDeg), 2)
                .frame(Math.max(2, life - 4), tf((float) len, 0.02f, 1f, yawDeg), 4));
    }

    /** Dimensional gate: swirling void ellipse that opens, holds, collapses. */
    public Handle gate(Location base, float yaw, float size, int life) {
        float s = size * 2f;
        return vfx.spawn(new Spec(VfxModel.GATE, at(base, size)).life(life)
                .start(tf(s * 0.1f, s * 0.1f, 1f, yaw))
                .frame(1, tf(s, s, 1f, yaw), 5)
                .frame(Math.max(6, life - 6), tf(s * 0.05f, s * 1.1f, 1f, yaw), 6));
    }

    /** Huge ground ring marking a domain's boundary. Opens over 1.5 s and holds for {@code life} ticks. */
    public Handle domainRing(Location ground, float radius, int life) {
        float d = radius * 2f;
        return vfx.spawn(new Spec(VfxModel.RING, at(ground, 0.06)).life(life).viewRange(4f)
                .start(tf(d * 0.05f, 1f, d * 0.05f, 0))
                .frame(1, tf(d, 1f, d, 90f), 30));
    }

    /** The boundary ring collapsing inward. */
    public Handle collapseRing(Location ground, float radius) {
        float d = radius * 2f;
        return vfx.spawn(new Spec(VfxModel.RING, at(ground, 0.06)).life(22).viewRange(4f)
                .start(tf(d, 1f, d, 0))
                .frame(1, tf(d * 0.02f, 1f, d * 0.02f, -120f), 20));
    }

    /** Vertical beam (two crossed planes). */
    public Handle beam(Location base, float height, int life) {
        return vfx.spawn(new Spec(VfxModel.BEAM, at(base, height / 2.0)).life(life)
                .start(tf(0.3f, height * 0.2f, 0.3f, 0))
                .frame(1, tf(1.1f, height, 1.1f, 0), 4)
                .frame(Math.max(2, life - 6), tf(0.05f, height, 0.05f, 0), 6));
    }

    /** Geometric shield following the owner. Persistent: kill the handle when the status ends. */
    public Handle shield(Player owner, float size) {
        Location start = owner.getLocation().add(0, 1.0, 0);
        Supplier<Location> follow = () -> owner.isOnline() ? owner.getLocation().add(0, 1.0, 0) : null;
        float s = size * 2f;
        return vfx.spawn(new Spec(VfxModel.SHIELD, start).life(0).follow(follow)
                .start(tf(s * 0.2f, s * 0.2f, s * 0.2f, 0))
                .frame(1, tf(s, s, s, 0), 4)
                .spin(3f, new Vector3f(0, 1, 0), new Vector3f(s, s, s)));
    }

    /** Orbiting shard with its own tumble. Persistent; position comes from {@code pos} every tick. */
    public Handle shard(VfxModel shard, Supplier<Location> pos, float size, Player hideFrom) {
        Location start = pos.get();
        if (start == null) return null;
        Vector3f axis = new Vector3f(rng.nextFloat() - 0.5f, 1f, rng.nextFloat() - 0.5f);
        Vector3f scale = new Vector3f(size, size, size);
        Spec s = new Spec(shard, start).life(0).follow(pos)
                .start(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(size * 0.1f, size * 0.1f, size * 0.1f), new AxisAngle4f()))
                .frame(1, new Transformation(new Vector3f(), new AxisAngle4f(), scale, new AxisAngle4f()), 5)
                .spin(7f + rng.nextFloat() * 6f, axis, scale);
        if (hideFrom != null) s.hideFrom(hideFrom);
        return vfx.spawn(s);
    }

    /** A standing ghost of the owner that holds briefly then shrinks away. feet = where the owner was. */
    public Handle silhouette(Location feet, float yaw, int life, Player hideFrom) {
        Location anchor = at(feet, 1.0);
        anchor.setYaw(0);
        Spec s = new Spec(VfxModel.SILHOUETTE, anchor).life(life)
                .start(tf(0.9f, 0.9f, 0.9f, 180f - yaw))
                .frame(Math.max(1, life - 5), tf(0.02f, 0.9f, 0.02f, 180f - yaw), 5);
        if (hideFrom != null) s.hideFrom(hideFrom);
        return vfx.spawn(s);
    }

    /** The recognised gaze: two bright bars floating at the eyes, following the head every tick. */
    public Handle eyes(Player owner, float size, Player hideFrom) {
        Supplier<Location> follow = () -> {
            if (!owner.isOnline()) return null;
            Location e = owner.getEyeLocation();
            org.bukkit.util.Vector d = e.getDirection();
            Location l = e.clone().add(d.getX() * 0.27, d.getY() * 0.27 - 0.06, d.getZ() * 0.27);
            l.setYaw(e.getYaw());
            l.setPitch(e.getPitch());
            return l;
        };
        Location start = follow.get();
        if (start == null) return null;
        Spec s = new Spec(VfxModel.EYES, start).life(0).follow(follow).viewRange(0.5f)
                .start(tf(size, size, size, 0));
        if (hideFrom != null) s.hideFrom(hideFrom);
        return vfx.spawn(s);
    }
}
