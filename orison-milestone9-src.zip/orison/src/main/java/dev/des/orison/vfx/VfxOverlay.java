package dev.des.orison.vfx;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;

import java.time.Duration;

/**
 * Full-screen client overlays drawn with the pack's oversized font glyphs (U+E000 white flash, U+E001 dark vignette)
 * sent as a title. EXPERIMENTAL: the glyph height/ascent in tools/build_pack.py may need tuning for your GUI scales.
 */
public final class VfxOverlay {
    private static final Key FONT = Key.key("orison", "overlay");

    private final DisplayVfx vfx;

    public VfxOverlay(DisplayVfx vfx) { this.vfx = vfx; }

    public boolean whiteout(Player p, int fadeIn, int stay, int fadeOut) { return show(p, "\ue000", fadeIn, stay, fadeOut); }
    public boolean vignette(Player p, int fadeIn, int stay, int fadeOut) { return show(p, "\ue001", fadeIn, stay, fadeOut); }

    private boolean show(Player p, String glyph, int in, int stay, int out) {
        if (!vfx.enabled() || !vfx.hasPack(p)) return false;
        Component c = Component.text(glyph).font(FONT).color(NamedTextColor.WHITE);
        p.showTitle(Title.title(c, Component.empty(), Title.Times.times(
                Duration.ofMillis(in * 50L), Duration.ofMillis(stay * 50L), Duration.ofMillis(out * 50L))));
        return true;
    }
}
