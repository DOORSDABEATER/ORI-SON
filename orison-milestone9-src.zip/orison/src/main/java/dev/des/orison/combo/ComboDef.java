package dev.des.orison.combo;

/**
 * A cross-authority combination: casting {@code second} within {@code windowSeconds} of {@code first}.
 * sameTarget: both casts must have targeted the same entity.
 */
public record ComboDef(String id, String name, String first, String second, double windowSeconds,
                       boolean sameTarget, String hint, String effect) { }
