package dev.des.orison.command;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityDef;
import dev.des.orison.ability.Authority;
import dev.des.orison.echo.EchoCommand;
import dev.des.orison.quest.ProgressCommand;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * /orison (owner: cast, abilities, paradox) and /orison admin ...
 * Admin access = OP and orison.admin, checked on every call. Ownership changes need an explicit,
 * expiring two-step confirmation and are audit-logged.
 */
public final class OrisonCommand implements TabExecutor {

    private static final long CONFIRM_WINDOW_MS = 30_000L;
    private static final List<String> ADMIN_SUBS = List.of(
            "inspect", "grant", "revoke", "unlock", "stage", "awaken", "echo", "quest", "combo", "azriel", "vfx", "reload", "debug");
    /** Reserved by the master spec; implemented in later milestones. */
    private static final List<String> RESERVED = List.of();

    private record Pending(String action, UUID target, long expiresAt) { }

    private final OrisonPlugin plugin;
    private final Map<String, Pending> pending = new HashMap<>();
    private final MiniMessage mm = MiniMessage.miniMessage();

    private final EchoCommand echoCmd;
    private final ProgressCommand progressCmd;

    public OrisonCommand(OrisonPlugin plugin) {
        this.plugin = plugin;
        this.echoCmd = new EchoCommand(plugin);
        this.progressCmd = new ProgressCommand(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String root = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        if (root.equals("admin")) { admin(sender, args); return true; }

        if (sender instanceof Player p && plugin.owners().isOwner(p.getUniqueId())) {
            switch (root) {
                case "cast" -> {
                    if (args.length < 2) send(sender, "<gray>Usage: /orison cast <ability name, id or number>");
                    else plugin.engine().cast(p, String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
                }
                case "abilities" -> abilities(p, args);
                case "echo" -> echoCmd.owner(p, args);
                case "quests", "combos", "mastery", "titles", "title", "transform" -> progressCmd.owner(p, args);
                case "hunts" -> echoCmd.owner(p, new String[]{"echo", "hunts"});
                case "awaken" -> plugin.engine().cast(p, "awaken");
                case "paradox" -> send(sender, "<white>PARADOX <gray>" + (int) plugin.paradox().current()
                        + "/" + (int) plugin.paradox().max());
                default -> send(sender, "<gray>/orison <white>cast <gray>| <white>abilities [1-10] <gray>| <white>paradox <gray>| <white>echo <gray>| <white>hunts <gray>| <white>quests <gray>| <white>combos <gray>| <white>mastery <gray>| <white>titles <gray>| <white>transform");
            }
        } else {
            send(sender, "<dark_gray>Nothing here recognises you.");
        }
        return true;
    }

    private void abilities(Player p, String[] args) {
        if (args.length < 2) {
            for (Authority a : Authority.values()) {
                long avail = plugin.registry().of(a).stream().filter(plugin.engine()::available).count();
                long impl = plugin.registry().of(a).stream().filter(d -> plugin.engine().implemented(d.id())).count();
                send(p, "<white>" + (a.ordinal() + 1) + " <gray>" + a.roman() + " " + a.title().toUpperCase(Locale.ROOT)
                        + " <dark_gray>recognised " + avail + "/7, implemented " + impl + "/7");
            }
            send(p, "<dark_gray>/orison abilities <1-10> for detail");
            return;
        }
        int n;
        try { n = Integer.parseInt(args[1]); } catch (NumberFormatException e) { n = 0; }
        if (n < 1 || n > 10) { send(p, "<red>Choose an authority from 1 to 10."); return; }
        Authority a = Authority.values()[n - 1];
        send(p, "<white>" + a.roman() + " " + a.title().toUpperCase(Locale.ROOT) + " <dark_gray>- " + a.domain());
        for (AbilityDef d : plugin.registry().of(a)) {
            String state;
            if (!plugin.engine().implemented(d.id())) state = "<dark_gray>not implemented";
            else if (!plugin.engine().available(d)) state = "<dark_gray>locked (stage " + d.unlockStage() + ")";
            else {
                long left = plugin.engine().cooldowns().remainingMillis(d.id());
                state = left > 0 ? "<yellow>" + String.format(Locale.ROOT, "%.1fs", left / 1000.0) : "<green>ready";
            }
            send(p, "<gray>" + d.number() + ". <white>" + d.name() + " <dark_gray>cost " + (int) d.cost()
                    + " cd " + (int) d.cooldown() + "s  " + state);
        }
    }

    // ---------------------------------------------------------------- admin

    private void admin(CommandSender sender, String[] args) {
        if (!isAdmin(sender)) { send(sender, "<red>You do not have permission to do that."); return; }
        if (args.length < 2) { send(sender, "<gray>Usage: /orison admin <" + String.join("|", ADMIN_SUBS) + ">"); return; }
        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "inspect" -> inspect(sender, args);
            case "grant" -> grant(sender, args);
            case "revoke" -> revoke(sender, args);
            case "unlock" -> unlock(sender, args);
            case "stage" -> stage(sender, args);
            case "vfx" -> vfx(sender, args);
            case "echo" -> echoCmd.admin(sender, args);
            case "quest" -> progressCmd.admin(sender, args);
            case "combo" -> progressCmd.adminCombo(sender, args);
            case "azriel" -> plugin.azriel().admin(sender, args);
            case "awaken" -> echoCmd.adminAwaken(sender);
            case "reload" -> {
                plugin.reloadSettings();
                plugin.audit().record(actorKey(sender), "RELOAD", "config + abilities reloaded");
                send(sender, "<gray>ORISON configuration reloaded.");
            }
            case "debug" -> debug(sender, args);
            default -> {
                if (RESERVED.contains(sub)) send(sender, "<gray>'" + sub + "' is reserved for a later milestone and is not implemented yet.");
                else send(sender, "<red>Unknown admin subcommand.");
            }
        }
    }

    private boolean isAdmin(CommandSender s) { return s.isOp() && s.hasPermission("orison.admin"); }

    private String actorKey(CommandSender s) {
        return s instanceof Player p ? p.getName() + "(" + p.getUniqueId() + ")" : "CONSOLE";
    }

    private void inspect(CommandSender sender, String[] args) {
        if (args.length >= 3) {
            OfflinePlayer target = resolve(args[2]);
            if (target == null) { send(sender, "<red>Unknown player: " + esc(args[2])); return; }
            boolean owner = plugin.owners().isOwner(target.getUniqueId());
            send(sender, "<gray>" + esc(args[2]) + " (" + target.getUniqueId() + ") is "
                    + (owner ? "<white>the ORISON owner" : "not the ORISON owner") + "<gray>.");
            return;
        }
        UUID owner = plugin.owners().owner().orElse(null);
        String ownerName = owner == null ? "none" : String.valueOf(Bukkit.getOfflinePlayer(owner).getName());
        send(sender, "<white><b>ORISON</b> <gray>inspect");
        send(sender, "<gray>Owner: <white>" + esc(ownerName) + " <dark_gray>" + owner);
        send(sender, "<gray>Stage: <white>" + plugin.progress().stage() + "/7  <gray>PARADOX: <white>"
                + (int) plugin.paradox().current() + "/" + (int) plugin.paradox().max());
        long impl = plugin.registry().all().stream().filter(d -> plugin.engine().implemented(d.id())).count();
        send(sender, "<gray>Abilities defined: <white>" + plugin.registry().all().size() + " <gray>implemented: <white>" + impl);
        plugin.compat().lines().forEach(l -> send(sender, "<dark_gray>" + esc(l)));
    }

    private void grant(CommandSender sender, String[] args) {
        if (args.length < 3) { send(sender, "<gray>Usage: /orison admin grant <player> [confirm]"); return; }
        OfflinePlayer target = resolve(args[2]);
        if (target == null) { send(sender, "<red>Unknown player: " + esc(args[2])); return; }
        UUID uuid = target.getUniqueId();
        String key = actorKey(sender);
        boolean confirm = args.length >= 4 && args[3].equalsIgnoreCase("confirm");

        if (!confirm) {
            pending.put(key, new Pending("grant", uuid, System.currentTimeMillis() + CONFIRM_WINDOW_MS));
            send(sender, "<yellow>This binds ORISON to <white>" + esc(args[2]) + "<yellow> (" + uuid
                    + "). Current owner: " + plugin.owners().owner().map(UUID::toString).orElse("none") + ".");
            send(sender, "<yellow>Run <white>/orison admin grant " + esc(args[2]) + " confirm<yellow> within 30 seconds to proceed.");
            return;
        }
        if (!consume(key, "grant", uuid)) {
            send(sender, "<red>No matching pending grant (or it expired). Start again without 'confirm'.");
            return;
        }
        plugin.owners().bind(uuid, key)
                .thenCompose(v -> plugin.progress().reload())
                .whenComplete((v, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (err != null) {
                        plugin.getLogger().severe("Grant failed: " + err);
                        send(sender, "<red>Grant failed. See console.");
                    } else {
                        send(sender, "<gray>ORISON is now bound to <white>" + esc(args[2]) + "<gray>.");
                    }
                }));
    }

    private void revoke(CommandSender sender, String[] args) {
        String key = actorKey(sender);
        boolean confirm = args.length >= 3 && args[2].equalsIgnoreCase("confirm");
        if (plugin.owners().owner().isEmpty()) { send(sender, "<gray>No owner is bound."); return; }
        if (!confirm) {
            pending.put(key, new Pending("revoke", null, System.currentTimeMillis() + CONFIRM_WINDOW_MS));
            send(sender, "<yellow>This removes the current ORISON owner. Run <white>/orison admin revoke confirm<yellow> within 30 seconds to proceed.");
            return;
        }
        if (!consume(key, "revoke", null)) {
            send(sender, "<red>No pending revoke (or it expired). Start again without 'confirm'.");
            return;
        }
        plugin.owners().owner().ifPresent(id -> plugin.statuses().endAll(id));
        plugin.owners().revoke(key).whenComplete((v, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (err != null) send(sender, "<red>Revoke failed. See console.");
            else send(sender, "<gray>ORISON owner removed.");
        }));
    }

    /** Test/admin helper. Audit-logged. Progression normally comes from gameplay (later milestones). */
    private void unlock(CommandSender sender, String[] args) {
        if (args.length < 3) { send(sender, "<gray>Usage: /orison admin unlock <ability|all>"); return; }
        List<String> ids = new ArrayList<>();
        if (args[2].equalsIgnoreCase("all")) {
            plugin.registry().all().forEach(d -> ids.add(d.id()));
        } else {
            AbilityDef d = plugin.registry().find(String.join(" ", Arrays.copyOfRange(args, 2, args.length)));
            if (d == null) { send(sender, "<red>Unknown ability."); return; }
            ids.add(d.id());
        }
        plugin.progress().unlock(ids, actorKey(sender)).whenComplete((v, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (err != null) send(sender, "<red>Unlock failed. See console.");
            else send(sender, "<gray>Unlocked " + ids.size() + " ability(ies).");
        }));
    }

    private void stage(CommandSender sender, String[] args) {
        int n;
        try { n = args.length >= 3 ? Integer.parseInt(args[2]) : 0; } catch (NumberFormatException e) { n = 0; }
        if (n < 1 || n > 7) { send(sender, "<gray>Usage: /orison admin stage <1-7>"); return; }
        int target = n;
        plugin.progress().setStage(target, actorKey(sender)).whenComplete((v, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (err != null) send(sender, "<red>Could not set stage (is an owner bound?).");
            else { plugin.quests().syncTitles(); send(sender, "<gray>Evolution stage set to <white>" + target + "<gray>."); }
        }));
    }

    /** Presence test controls: /orison admin vfx <status|preview <1-7|off>|transform <0-4>> */
    private void vfx(CommandSender sender, String[] args) {
        String mode = args.length >= 3 ? args[2].toLowerCase(Locale.ROOT) : "status";
        switch (mode) {
            case "status" -> plugin.presence().describe().forEach(l -> send(sender, "<dark_gray>" + esc(l)));
            case "preview" -> {
                if (args.length < 4) { send(sender, "<gray>Usage: /orison admin vfx preview <1-7|off>"); return; }
                if (args[3].equalsIgnoreCase("off")) {
                    plugin.presence().setPreviewStage(null);
                    send(sender, "<gray>Presence preview off (using real stage).");
                    return;
                }
                int n;
                try { n = Integer.parseInt(args[3]); } catch (NumberFormatException e) { n = 0; }
                if (n < 1 || n > 7) { send(sender, "<red>Stage must be 1-7."); return; }
                plugin.presence().setPreviewStage(n);
                send(sender, "<gray>Presence previewing stage <white>" + n + "<gray> (not saved).");
            }
            case "transform" -> {
                int n;
                try { n = args.length >= 4 ? Integer.parseInt(args[3]) : -1; } catch (NumberFormatException e) { n = -1; }
                if (n < 0 || n > 4) { send(sender, "<gray>Usage: /orison admin vfx transform <0-4>"); return; }
                plugin.presence().setTransformation(n);
                send(sender, "<gray>Presence transformation level <white>" + n + "<gray> (test; not saved).");
            }
            case "pack" -> {
                boolean has = sender instanceof Player pl && plugin.vfx().hasPack(pl);
                send(sender, "<gray>Model VFX enabled: <white>" + plugin.vfx().enabled() + "<gray>  your client has the pack: <white>" + has
                        + "<gray>  live displays: <white>" + plugin.vfx().liveCount() + "/" + plugin.vfx().maxLive());
            }
            case "demo" -> {
                if (!(sender instanceof Player pl)) { send(sender, "<red>Players only."); return; }
                if (args.length < 4) { send(sender, "<gray>Usage: /orison admin vfx demo <fracture|ring|shock|rift|cut|gate|beam|shield|shard|silhouette|eyes|whiteout|vignette>"); return; }
                demo(pl, args[3].toLowerCase(Locale.ROOT));
            }
            default -> send(sender, "<gray>Usage: /orison admin vfx <status|preview|transform|pack|demo>");
        }
    }

    private void demo(Player p, String what) {
        var lib = plugin.vfxLib();
        org.bukkit.Location eye = p.getEyeLocation();
        org.bukkit.Location ahead = p.getLocation().add(eye.getDirection().setY(0).normalize().multiply(3));
        float yaw = p.getLocation().getYaw();
        if (what.equals("whiteout") || what.equals("vignette")) {
            boolean ok = what.equals("whiteout") ? plugin.vfxOverlay().whiteout(p, 2, 8, 12) : plugin.vfxOverlay().vignette(p, 6, 30, 20);
            send(p, ok ? "<gray>Overlay sent." : "<red>Your client has not loaded the pack (see /orison admin vfx pack).");
            return;
        }
        if (!plugin.vfx().usable(p)) { send(p, "<red>Model VFX unavailable: pack not loaded on your client, disabled, or at the cap."); return; }
        Object h = switch (what) {
            case "fracture" -> lib.fracture(ahead, 1.6f, 60);
            case "ring" -> lib.ring(ahead, 2.5f, 40);
            case "shock" -> lib.shock(ahead, 4f, 40);
            case "rift" -> lib.rift(ahead, yaw, 2.2f, 50);
            case "cut" -> lib.cut(ahead.clone().add(-1.5, 1, 0), ahead.clone().add(1.5, 1.4, 0), 30);
            case "gate" -> lib.gate(ahead, yaw, 1.1f, 60);
            case "beam" -> lib.beam(ahead, 6f, 60);
            case "silhouette" -> lib.silhouette(ahead, yaw + 180f, 80, null);
            case "shield" -> { var s = lib.shield(p, 1.2f); if (s != null) Bukkit.getScheduler().runTaskLater(plugin, s::kill, 100L); yield s; }
            case "eyes" -> { var s = lib.eyes(p, 1.4f, null); if (s != null) Bukkit.getScheduler().runTaskLater(plugin, s::kill, 100L); yield s; }
            case "shard" -> {
                var fixed = ahead.clone().add(0, 1.2, 0);
                var s = lib.shard(dev.des.orison.vfx.VfxModel.SHARD_C, () -> fixed, 0.8f, null);
                if (s != null) Bukkit.getScheduler().runTaskLater(plugin, s::kill, 100L);
                yield s;
            }
            default -> { send(p, "<red>Unknown demo."); yield "x"; }
        };
        if (h == null) send(p, "<red>Spawn refused (display cap or rate limit).");
    }

    private void debug(CommandSender sender, String[] args) {
        boolean value = args.length >= 3 ? args[2].equalsIgnoreCase("on") : !plugin.debugEnabled();
        plugin.setDebug(value);
        plugin.audit().record(actorKey(sender), "DEBUG", value ? "on" : "off");
        send(sender, "<gray>ORISON debug: <white>" + (value ? "on" : "off"));
    }

    private boolean consume(String key, String action, UUID target) {
        Pending p = pending.remove(key);
        return p != null && p.action().equals(action) && Objects.equals(p.target(), target)
                && System.currentTimeMillis() <= p.expiresAt();
    }

    private OfflinePlayer resolve(String name) {
        Player online = Bukkit.getPlayerExact(name);
        return online != null ? online : Bukkit.getOfflinePlayerIfCached(name);
    }

    private String esc(String s) { return mm.escapeTags(s); }
    private void send(CommandSender to, String miniMessage) { to.sendMessage(mm.deserialize(miniMessage)); }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = isAdmin(sender);
        boolean owner = sender instanceof Player p && plugin.owners().isOwner(p.getUniqueId());
        if (args.length == 1) {
            if (admin) out.add("admin");
            if (owner) out.addAll(List.of("cast", "abilities", "paradox", "echo", "hunts", "awaken", "quests", "combos", "mastery", "titles", "title", "transform"));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("admin") && admin) {
            out.addAll(ADMIN_SUBS);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("cast") && owner) {
            plugin.registry().all().stream().filter(d -> plugin.engine().implemented(d.id())).forEach(d -> out.add(d.id()));
        } else if (admin && args[0].equalsIgnoreCase("admin")) {
            String sub = args[1].toLowerCase(Locale.ROOT);
            if (args.length == 3 && (sub.equals("grant") || sub.equals("inspect"))) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
            else if (args.length == 4 && sub.equals("grant")) out.add("confirm");
            else if (args.length == 3 && sub.equals("revoke")) out.add("confirm");
            else if (args.length == 3 && sub.equals("debug")) out.addAll(List.of("on", "off"));
            else if (args.length == 3 && sub.equals("unlock")) { out.add("all"); plugin.registry().all().forEach(d -> out.add(d.id())); }
            else if (args.length == 3 && sub.equals("stage")) out.addAll(List.of("1", "2", "3", "4", "5", "6", "7"));
            else if (args.length == 3 && sub.equals("azriel")) out.addAll(List.of("status", "spawn", "phase", "reset"));
            else if (args.length == 3 && sub.equals("vfx")) out.addAll(List.of("status", "preview", "transform", "pack", "demo"));
            else if (args.length == 4 && sub.equals("vfx") && args[2].equalsIgnoreCase("demo")) out.addAll(List.of("fracture", "ring", "shock", "rift", "cut", "gate", "beam", "shield", "shard", "silhouette", "eyes", "whiteout", "vignette"));
            else if (args.length == 4 && sub.equals("vfx") && args[2].equalsIgnoreCase("preview")) out.addAll(List.of("1", "2", "3", "4", "5", "6", "7", "off"));
            else if (args.length == 4 && sub.equals("vfx") && args[2].equalsIgnoreCase("transform")) out.addAll(List.of("0", "1", "2", "3", "4"));
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
