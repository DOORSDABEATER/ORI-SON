package dev.des.orison.echo;

import dev.des.orison.OrisonPlugin;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.world.WorldUnloadEvent;

/** Keeps Echoes from harming players or each other, handles their death/cleanup, and listens for the word AWAKEN. */
public final class EchoListener implements Listener {
    private final OrisonPlugin plugin;

    public EchoListener(OrisonPlugin plugin) { this.plugin = plugin; }

    private static Entity source(Entity damager) {
        if (damager instanceof Projectile p && p.getShooter() instanceof Entity s) return s;
        return damager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTarget(EntityTargetLivingEntityEvent e) {
        if (!plugin.echo().isEchoEntity(e.getEntity())) return;
        LivingEntity t = e.getTarget();
        if (t == null) return;
        if (t instanceof Player || plugin.echo().isEchoEntity(t) || (t instanceof Tameable tm && tm.isTamed())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        Entity damager = source(e.getDamager());
        Entity victim = e.getEntity();
        boolean damagerEcho = plugin.echo().isEchoEntity(damager);
        boolean victimEcho = plugin.echo().isEchoEntity(victim);
        if (damagerEcho && (victim instanceof Player || victimEcho)) { e.setCancelled(true); return; }
        if (victimEcho && damager instanceof Player) { e.setCancelled(true); return; } // Echoes are the owner's; nobody else harms them
        // remember what is hurting the owner so the Legion can answer it
        if (victim instanceof Player p && plugin.owners().isOwner(p.getUniqueId())) plugin.echo().noteThreat(damager);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEchoDeath(EntityDeathEvent e) {
        if (!plugin.echo().isEchoEntity(e.getEntity())) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        plugin.echo().onEchoDeath(e.getEntity());
    }

    @EventHandler
    public void onOwnerQuit(PlayerQuitEvent e) {
        if (plugin.owners().isOwner(e.getPlayer().getUniqueId())) plugin.echo().recallAll(false);
    }

    @EventHandler
    public void onOwnerDeath(PlayerDeathEvent e) {
        if (plugin.owners().isOwner(e.getPlayer().getUniqueId())) plugin.echo().recallAll(false);
    }

    @EventHandler
    public void onOwnerWorld(PlayerChangedWorldEvent e) {
        if (plugin.owners().isOwner(e.getPlayer().getUniqueId())) plugin.echo().recallAll(false);
    }

    @EventHandler
    public void onWorldUnload(WorldUnloadEvent e) { plugin.echo().recallAll(false); }

    /** Echo entities are never persistent; anything tagged that loads from disk is a leftover. */
    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (plugin.echo().isEchoEntity(en) && plugin.echo().echoIdOf(en) != null
                    && !plugin.echo().isActive(plugin.echo().echoIdOf(en))) en.remove();
        }
    }

    /** Saying AWAKEN in chat casts the AWAKEN ability. The chat message itself is not altered. */
    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        if (!plugin.owners().isOwner(p.getUniqueId())) return;
        String msg = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        if (!msg.equalsIgnoreCase("awaken")) return;
        Bukkit.getScheduler().runTask(plugin, () -> plugin.engine().cast(p, "awaken"));
    }
}
