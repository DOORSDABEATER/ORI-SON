package dev.des.orison.combo;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityDef;
import dev.des.orison.audio.AudioService;
import dev.des.orison.persistence.Database;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Detects cross-authority combinations from the owner's recent casts and records which ones have been discovered.
 * The combo is resolved BEFORE an ability runs (so its behaviour can use the bonus) and committed after it succeeds.
 */
public final class ComboEngine {
    private final OrisonPlugin plugin;
    private final Database db;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final List<ComboDef> defs = ComboCatalog.defaults();
    private final List<ComboLogic.Cast> history = new ArrayList<>();
    private final Set<String> discovered = new HashSet<>();

    public ComboEngine(OrisonPlugin plugin) {
        this.plugin = plugin;
        this.db = plugin.database();
    }

    public void loadBlocking() {
        discovered.addAll(db.callBlocking(c -> {
            Set<String> ids = new HashSet<>();
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT combo_id FROM combo_unlock")) {
                while (rs.next()) ids.add(rs.getString(1));
            }
            return ids;
        }));
    }

    public List<ComboDef> defs() { return defs; }
    public boolean discovered(String id) { return discovered.contains(id); }
    public int discoveredCount() { return discovered.size(); }

    public ComboDef preview(String abilityId, UUID target) {
        return ComboLogic.find(defs, history, abilityId, target, System.currentTimeMillis());
    }

    /** Record a successful cast; if it completed a combo, announce it and remember the discovery. */
    public void commit(Player p, AbilityDef def, LivingEntity target, ComboDef combo) {
        long now = System.currentTimeMillis();
        history.add(new ComboLogic.Cast(def.id(), now, target == null ? null : target.getUniqueId()));
        ComboLogic.prune(history, now, 35_000, 24);
        if (combo == null) return;
        boolean first = discovered.add(combo.id());
        if (first) persist(combo.id());
        if (first) {
            p.sendMessage(mm.deserialize("<gold>COMBO DISCOVERED <dark_gray>| <white>" + combo.name() + " <gray>- " + mm.escapeTags(combo.effect())));
            plugin.audio().to(p, "combo.discover", AudioService.Kind.UI, 1.0f);
        } else {
            p.sendActionBar(mm.deserialize("<white>COMBO <dark_gray>| <gray>" + combo.name()));
            plugin.audio().to(p, "combo.trigger", AudioService.Kind.UI, 1.0f);
        }
        if (plugin.vfx().usable(p)) plugin.vfxLib().shock(p.getLocation(), 3.2f, 12);
    }

    private void persist(String id) {
        db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO combo_unlock (combo_id, unlocked_at) VALUES (?, ?)")) {
                ps.setString(1, id);
                ps.setLong(2, System.currentTimeMillis());
                ps.executeUpdate();
            }
            return null;
        });
    }

    public boolean adminUnlock(String idOrAll, String actor) {
        List<String> ids = new ArrayList<>();
        if (idOrAll.equalsIgnoreCase("all")) defs.forEach(d -> ids.add(d.id()));
        else if (defs.stream().anyMatch(d -> d.id().equals(idOrAll))) ids.add(idOrAll);
        else return false;
        for (String id : ids) if (discovered.add(id)) persist(id);
        plugin.audit().record(actor, "COMBO_UNLOCK", String.join(",", ids));
        return true;
    }

    public boolean adminReset(String idOrAll, String actor) {
        List<String> ids = new ArrayList<>();
        if (idOrAll.equalsIgnoreCase("all")) defs.forEach(d -> ids.add(d.id()));
        else if (defs.stream().anyMatch(d -> d.id().equals(idOrAll))) ids.add(idOrAll);
        else return false;
        discovered.removeAll(ids);
        db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM combo_unlock WHERE combo_id = ?")) {
                for (String id : ids) { ps.setString(1, id); ps.addBatch(); }
                ps.executeBatch();
            }
            return null;
        });
        plugin.audit().record(actor, "COMBO_RESET", String.join(",", ids));
        return true;
    }
}
