package dev.des.orison.quest;

import java.util.Set;

/** Pure quest rules (unit tested). Counters are one int per objective, in objective order. */
public final class QuestLogic {
    private QuestLogic() { }

    public static boolean matches(Objective o, ObjectiveType type, String key) {
        return o.type() == type && (o.key().equals("*") || o.key().equals(key));
    }

    /** Applies an event; returns true if any counter changed. Counters never exceed the requirement. */
    public static boolean apply(QuestDef def, int[] counters, ObjectiveType type, String key, int amount) {
        boolean changed = false;
        for (int i = 0; i < def.objectives().size(); i++) {
            Objective o = def.objectives().get(i);
            if (!matches(o, type, key)) continue;
            int before = counters[i];
            int after = type.isMax() ? Math.max(before, amount) : before + Math.max(0, amount);
            after = Math.min(o.required(), after);
            if (after != before) { counters[i] = after; changed = true; }
        }
        return changed;
    }

    public static boolean isComplete(QuestDef def, int[] counters) {
        for (int i = 0; i < def.objectives().size(); i++) {
            if (counters[i] < def.objectives().get(i).required()) return false;
        }
        return true;
    }

    /** A quest accepts progress only while incomplete and the owner has reached its minimum stage. */
    public static boolean isActive(QuestDef def, int stage, boolean complete) {
        return !complete && stage >= def.minStage();
    }

    public static boolean progressed(int[] counters) {
        for (int c : counters) if (c > 0) return true;
        return false;
    }

    public static boolean isRevealed(QuestDef def, int[] counters, boolean complete, Set<String> storyFlags) {
        if (!def.hidden() || complete) return true;
        if (def.revealFlag() != null && storyFlags.contains(def.revealFlag())) return true;
        return progressed(counters);
    }

    public static int totalRequired(QuestDef def) {
        int t = 0;
        for (Objective o : def.objectives()) t += o.required();
        return t;
    }

    public static int totalDone(QuestDef def, int[] counters) {
        int t = 0;
        for (int i = 0; i < def.objectives().size(); i++) t += Math.min(counters[i], def.objectives().get(i).required());
        return t;
    }
}
