package dev.des.orison.echo;

public enum IntegrityBand {
    UNSTABLE, PARTIAL, RECOGNIZABLE, HIGH_FIDELITY, NEAR_PERFECT, COMPLETE;

    public static IntegrityBand of(int integrity) {
        if (integrity >= 100) return COMPLETE;
        if (integrity >= 90) return NEAR_PERFECT;
        if (integrity >= 75) return HIGH_FIDELITY;
        if (integrity >= 50) return RECOGNIZABLE;
        if (integrity >= 25) return PARTIAL;
        return UNSTABLE;
    }

    public String label() { return name().replace('_', ' '); }
}
