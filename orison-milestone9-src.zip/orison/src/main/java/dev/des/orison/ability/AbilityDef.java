package dev.des.orison.ability;

/** Static, config-driven definition of one ability. Behaviour lives in an {@link AbilityBehavior}. */
public record AbilityDef(
        String id,
        String name,
        Authority authority,
        int number,          // 1-70, global order
        int indexInAuthority, // 1-7
        double cost,         // PARADOX
        double cooldown,     // seconds, independent of cost
        double range,        // blocks
        double duration,     // seconds
        double damage,
        int unlockStage,
        boolean ultimate) { }
