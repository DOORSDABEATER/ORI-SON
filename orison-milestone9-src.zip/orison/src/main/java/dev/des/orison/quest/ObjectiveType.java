package dev.des.orison.quest;

/** Gameplay events quests can count. ECHO_RANK keeps the highest value seen instead of a running total. */
public enum ObjectiveType {
    DEFEAT_HOSTILE, ABILITY_USE, ECHO_CLAIM, ECHO_KILL, DAMAGE_NEGATED, TRANSFORM_USED, ECHO_RANK, STORY;

    public boolean isMax() { return this == ECHO_RANK; }
}
