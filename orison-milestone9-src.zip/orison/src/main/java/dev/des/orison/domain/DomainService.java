package dev.des.orison.domain;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.audio.AudioService;
import dev.des.orison.ability.Targets;
import dev.des.orison.vfx.DisplayVfx;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Domains: a temporary sphere under ORISON's authority. One at a time. They never change blocks; effects on mobs are
 * short potion pulses (so they expire on their own) plus, for THE STILL WORLD, a reversible setAware(false) that is
 * restored on collapse. Collapse runs from a StatusManager status, so it also fires on death, logout and plugin disable.
 */
public final class DomainService {
    private final OrisonPlugin plugin;
    private DomainType type;
    private Location center;
    private double radius;
    private BukkitTask task;
    private final List<DisplayVfx.Handle> handles = new ArrayList<>();
    private final Set<UUID> frozen = new HashSet<>();

    public DomainService(OrisonPlugin plugin) { this.plugin = plugin; }

    public boolean active() { return type != null; }
    public DomainType type() { return type; }

    public boolean inside(Location l) {
        return type != null && l.getWorld() == center.getWorld()
                && DomainRules.inside(center.getX(), center.getY(), center.getZ(), l.getX(), l.getY(), l.getZ(), radius);
    }

    private boolean ownerInside(Player p) { return p != null && inside(p.getLocation()); }

    public double cooldownMultiplier(Player p) { return type == null ? 1.0 : DomainRules.cooldownMultiplier(type, ownerInside(p)); }
    public double claimBonus(Player p) { return type == null ? 0.0 : DomainRules.claimChanceBonus(type, ownerInside(p)); }
    public double claimWindowMultiplier(Player p) {
        return type == DomainType.KINGDOM_OF_NOTHING && ownerInside(p) ? DomainRules.KINGDOM_CLAIM_WINDOW : 1.0;
    }
    public double paradoxPerDefeat(Player owner, Location at) {
        return type == null || !inside(at) ? 0.0 : DomainRules.paradoxPerDefeat(type, ownerInside(owner));
    }

    /** @return false if a domain is already open or the world forbids ORISON */
    public boolean start(Player p, DomainType t, double rad, double seconds) {
        if (type != null) return false;
        if (plugin.getConfig().getStringList("abilities.disabled-worlds").contains(p.getWorld().getName())) return false;
        double min = plugin.getConfig().getDouble("domain.min-seconds", 20), max = plugin.getConfig().getDouble("domain.max-seconds", 45);
        double dur = DomainRules.clampDuration(seconds, min, max);
        radius = Math.max(6, Math.min(plugin.getConfig().getDouble("domain.max-radius", 30), rad));
        center = p.getLocation().clone();
        type = t;
        long ticks = (long) (dur * 20);

        expansion(p, ticks);
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> pulse(p), 10L, 10L);
        plugin.statuses().start(p, "domain", ticks, this::collapse);
        return true;
    }

    // ------------------------------------------------------------------ visuals / audio

    private void expansion(Player p, long ticks) {
        plugin.audio().at(center, "domain.expand", AudioService.Kind.ABILITY, 56, 1.0f);
        if (plugin.vfx().usable(p)) {
            var lib = plugin.vfxLib();
            add(lib.domainRing(center, (float) radius, (int) ticks));
            add(lib.beam(center, 14f, (int) ticks));
            for (int i = 0; i < 6; i++) {
                double a = Math.PI * 2 * i / 6;
                Location base = center.clone().add(Math.cos(a) * radius * 0.92, 0, Math.sin(a) * radius * 0.92);
                add(lib.rift(base, (float) Math.toDegrees(a) + 90f, 8f, (int) ticks));
            }
            if (type == DomainType.KINGDOM_OF_NOTHING) plugin.vfxOverlay().vignette(p, 10, (int) Math.min(ticks, 200), 30);
            plugin.vfxOverlay().whiteout(p, 1, 2, 12);
        } else {
            center.getWorld().spawnParticle(Particle.WHITE_ASH, center.clone().add(0, 1, 0), 300, radius / 3, 2, radius / 3, 0.01);
        }
        p.sendActionBar(net.kyori.adventure.text.Component.text(type.title));
    }

    private void add(DisplayVfx.Handle h) { if (h != null) handles.add(h); }

    // ------------------------------------------------------------------ effects

    private void pulse(Player owner) {
        if (type == null || center == null) return;
        int processed = 0;
        Set<UUID> still = new HashSet<>();
        for (LivingEntity e : center.getWorld().getNearbyLivingEntities(center, radius)) {
            if (++processed > 80) break;
            if (!(e instanceof Enemy) || !Targets.canAffect(plugin, owner, e) || !inside(e.getLocation())) continue;
            if (type == DomainType.KINGDOM_OF_NOTHING) {
                e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, DomainRules.KINGDOM_SLOW_AMPLIFIER, false, false, false));
                e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 30, 0, false, false, false));
            } else if (e instanceof Mob m) {
                e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, DomainRules.STILL_SLOW_AMPLIFIER, false, false, false));
                if (frozen.add(m.getUniqueId())) m.setAware(false);
                still.add(m.getUniqueId());
            }
        }
        // anything frozen that left the sphere is released immediately
        if (type == DomainType.THE_STILL_WORLD) {
            for (UUID id : new ArrayList<>(frozen)) {
                if (still.contains(id)) continue;
                frozen.remove(id);
                if (Bukkit.getEntity(id) instanceof Mob m && m.isValid()) m.setAware(true);
            }
        }
    }

    private void collapse() {
        if (type == null) return;
        if (task != null) { task.cancel(); task = null; }
        for (DisplayVfx.Handle h : handles) h.kill();
        handles.clear();
        for (UUID id : frozen) if (Bukkit.getEntity(id) instanceof Mob m && m.isValid()) m.setAware(true);
        frozen.clear();

        Location c = center;
        Player owner = plugin.owners().owner().map(Bukkit::getPlayer).orElse(null);
        plugin.audio().at(c, "domain.collapse", AudioService.Kind.ABILITY, 56, 1.0f);
        if (owner != null && owner.isOnline() && plugin.vfx().usable(owner)) {
            plugin.vfxLib().collapseRing(c, (float) radius);
            plugin.vfxLib().shock(c, (float) radius * 0.6f, 20);
            plugin.vfxOverlay().whiteout(owner, 1, 1, 14);
        } else {
            c.getWorld().spawnParticle(Particle.WHITE_ASH, c.clone().add(0, 1, 0), 200, radius / 4, 2, radius / 4, 0.02);
        }
        type = null;
        center = null;
    }

    /** Ends the domain now (used by cancel and shutdown paths that run without the status). */
    public void shutdown() { collapse(); }
}
