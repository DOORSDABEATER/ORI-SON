package dev.des.orison.echo;

import dev.des.orison.OrisonPlugin;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.NPC;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Records defeats caused by the owner or the owner's Echoes. Eligible defeats become hunt records (one per identity,
 * so no duplicates) and short-lived claimable {@link Pending} entries that AWAKEN can act on.
 */
public final class HuntTracker implements Listener {
    private final OrisonPlugin plugin;
    private final List<Pending> pending = new ArrayList<>();
    private final MiniMessage mm = MiniMessage.miniMessage();

    public HuntTracker(OrisonPlugin plugin) { this.plugin = plugin; }

    public List<Pending> pending() { pruneExpired(); return pending; }

    public void remove(Pending p) { pending.remove(p); }

    /** Admin/test: register a claimable defeat that did not come from a real kill. */
    public void add(Pending p) {
        pending.add(p);
        if (pending.size() > 16) pending.remove(0);
    }

    private void pruneExpired() {
        long now = System.currentTimeMillis();
        pending.removeIf(p -> p.expiresAt < now);
    }

    /** Nearest unexpired defeat to the location within range, or null. */
    public Pending nearest(Location from, double range) {
        pruneExpired();
        Pending best = null;
        double bestD = range * range;
        for (Pending p : pending) {
            if (p.location.getWorld() != from.getWorld()) continue;
            double d = p.location.distanceSquared(from);
            if (d <= bestD) { bestD = d; best = p; }
        }
        return best;
    }

    public String identityOf(LivingEntity v) {
        if (plugin.azriel().isAzriel(v)) return dev.des.orison.azriel.AzrielService.IDENTITY;
        return plugin.mythic().internalName(v).map(n -> "mythic:" + n.toLowerCase())
                .orElse("vanilla:" + v.getType().getKey().getKey());
    }

    private static double attr(LivingEntity e, Attribute a, double fallback) {
        AttributeInstance i = e.getAttribute(a);
        return i == null ? fallback : i.getBaseValue();
    }

    private static Entity lastDamager(LivingEntity v) {
        EntityDamageEvent ev = v.getLastDamageCause();
        if (ev instanceof EntityDamageByEntityEvent be) {
            Entity d = be.getDamager();
            if (d instanceof Projectile pr && pr.getShooter() instanceof Entity sh) return sh;
            return d;
        }
        return null;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(EntityDeathEvent e) {
        LivingEntity v = e.getEntity();
        if (v instanceof Player || plugin.echo().isEchoEntity(v)) return;
        UUID ownerId = plugin.owners().owner().orElse(null);
        if (ownerId == null) return;

        boolean byOwner = v.getKiller() != null && v.getKiller().getUniqueId().equals(ownerId);
        Entity damager = lastDamager(v);
        boolean byEcho = damager != null && plugin.echo().isEchoEntity(damager);
        if (!byOwner && !byEcho) return;

        double maxHealth = attr(v, Attribute.MAX_HEALTH, v.getMaxHealth());
        if (byEcho) plugin.echo().awardXp(plugin.echo().echoIdOf(damager), EchoMath.xpForKill(maxHealth));
        if (v instanceof org.bukkit.entity.Enemy) {
            plugin.quests().event(dev.des.orison.quest.ObjectiveType.DEFEAT_HOSTILE, identityOf(v), 1);
            if (byEcho) plugin.quests().event(dev.des.orison.quest.ObjectiveType.ECHO_KILL, identityOf(v), 1);
        }

        if (!(v instanceof Mob) || v instanceof NPC || (v instanceof Tameable t && t.isTamed())) return;

        if (plugin.azriel().handles(v)) return;   // the encounter writes its own victory record
        Pending p = new Pending();
        p.identity = identityOf(v);
        p.displayName = v.getName();
        p.entityType = v.getType().getKey().getKey();
        p.mythicId = plugin.mythic().internalName(v).orElse(null);
        p.modelId = plugin.models().modelId(v).orElse(null);
        p.maxHealth = maxHealth;
        p.attackDamage = attr(v, Attribute.ATTACK_DAMAGE, 2.0);
        p.moveSpeed = attr(v, Attribute.MOVEMENT_SPEED, 0.23);
        p.location = v.getLocation();
        p.marked = plugin.combat().marked(v);
        Player ownerNow = plugin.getServer().getPlayer(ownerId);
        double windowMult = (p.marked ? 2.0 : 1.0) * (ownerNow == null ? 1.0 : plugin.domains().claimWindowMultiplier(ownerNow));
        p.expiresAt = System.currentTimeMillis() + (long) (plugin.getConfig().getInt("echo.claim-window-seconds", 45) * 1000L * windowMult);
        if (ownerNow != null) plugin.paradox().gain(plugin.domains().paradoxPerDefeat(ownerNow, v.getLocation()));
        if (Double.isNaN(p.maxHealth) || p.maxHealth <= 0 || p.maxHealth > 4096) {
            p.irregular = true;
            p.irregularReason = "Its record is internally inconsistent (health " + p.maxHealth + ").";
        }

        HuntRecord h = plugin.echoRepo().recordDefeat(p, 1);
        pending.add(p);
        if (pending.size() > 16) pending.remove(0);

        Player owner = plugin.getServer().getPlayer(ownerId);
        if (owner != null && plugin.getConfig().getBoolean("echo.hunt-feedback", true)) {
            int need = plugin.claims().requiredKillsFor(p);
            if (h.kills == 1 || h.kills == need) {
                owner.sendActionBar(mm.deserialize("<dark_gray>recorded: <white>" + mm.escapeTags(p.displayName)
                        + " <gray>" + Math.min(h.kills, need) + "/" + need));
            }
        }
    }
}
