package dev.des.orison.combo;

import java.util.List;

/** The ten required combinations. Each second ability appears in exactly one combo, so a cast resolves to at most one. */
public final class ComboCatalog {
    private ComboCatalog() { }

    public static List<ComboDef> defaults() {
        return List.of(
            new ComboDef("blink_omission", "UNSEEN GEOMETRY", "step_between", "omission_form", 4, false,
                "Cross a distance, then remove a form.", "Arrive behind the target, formless for 1.5x as long, plus a strike."),
            new ComboDef("perfect_return", "PERFECT RETURN", "invalid", "return_to_sender", 6, false,
                "Declare it invalid, then send it back.", "The return is doubled and costs you nothing."),
            new ComboDef("erasure", "ERASURE", "collapse_the_distance", "nothing_remains", 4, true,
                "Close the distance, then leave nothing.", "NOTHING REMAINS strikes for double."),
            new ComboDef("vanishing_frame", "VANISHING FRAME", "unseen", "missing_frame", 6, false,
                "Be unseen, then skip a frame.", "The skip is longer and the immunity twice as long."),
            new ComboDef("marked_record", "MARKED RECORD", "hunt_mark", "awaken", 20, false,
                "Mark it, defeat it, then record it.", "A marked defeat is easier to claim and needs one fewer defeat."),
            new ComboDef("kingdom_legion", "KINGDOM LEGION", "kingdom_of_nothing", "awaken_all", 30, false,
                "Open the kingdom, then call everyone.", "Four extra Echoes may answer, and they arrive empowered."),
            new ComboDef("full_account", "FULL ACCOUNT", "debt_collector", "everything_comes_back", 12, false,
                "Collect the debt, then let it all return.", "The debt returns at one and a half times its size."),
            new ComboDef("refused_future", "REFUSED FUTURE", "future_fracture", "not_today", 8, false,
                "See it coming, then refuse it.", "NOT TODAY restores far more and grants two seconds of immunity."),
            new ComboDef("one_will", "ONE WILL", "sovereign_command", "one_authority", 6, false,
                "Command the legion, then make it one.", "Every Echo converges on the target, empowered."),
            new ComboDef("overdrive", "CONTRADICTION OVERDRIVE", "contradiction", "beyond_existence", 15, false,
                "Overcharge, then go beyond.", "The final manifestation lasts longer, refunds PARADOX and shatters nearby hostiles.")
        );
    }
}
