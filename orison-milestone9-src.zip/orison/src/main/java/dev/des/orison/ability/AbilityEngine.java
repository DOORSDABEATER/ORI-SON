package dev.des.orison.ability;

import dev.des.orison.OrisonPlugin;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.FluidCollisionMode;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;

/**
 * Validates and runs a cast: owner -> known -> implemented -> world -> unlocked -> cooldown ->
 * PARADOX -> targeting -> behaviour. PARADOX and cooldown are only charged after the behaviour
 * succeeds, so a failed cast costs nothing. Main thread only.
 */
public final class AbilityEngine {
    private final OrisonPlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Map<String, AbilityBehavior> behaviors = new HashMap<>();
    private final CooldownTracker cooldowns = new CooldownTracker();

    public AbilityEngine(OrisonPlugin plugin) { this.plugin = plugin; }

    public void register(AbilityBehavior behavior) { behaviors.put(behavior.abilityId(), behavior); }
    public boolean implemented(String abilityId) { return behaviors.containsKey(abilityId); }
    public CooldownTracker cooldowns() { return cooldowns; }

    public boolean available(AbilityDef def) {
        return plugin.progress().stage() >= def.unlockStage() || plugin.progress().isUnlocked(def.id());
    }

    public void cast(Player p, String query) {
        if (!plugin.owners().isOwner(p.getUniqueId())) return;

        AbilityDef def = plugin.registry().find(query);
        if (def == null) { bar(p, "<red>Unknown ability."); return; }

        AbilityBehavior behavior = behaviors.get(def.id());
        if (behavior == null) { bar(p, "<white>" + def.name() + " <dark_gray>is not implemented yet."); return; }

        if (plugin.getConfig().getStringList("abilities.disabled-worlds").contains(p.getWorld().getName())) {
            bar(p, "<red>ORISON cannot be used in this world.");
            return;
        }
        if (!available(def)) { bar(p, "<white>" + def.name() + " <dark_gray>has not been recognised yet."); return; }

        double cost = def.cost() * plugin.mastery().costFactor(def.id()) * plugin.transform().costMultiplier();
        double cooldown = def.cooldown() * plugin.mastery().cooldownFactor(def.id()) * plugin.transform().cooldownMultiplier()
                * plugin.domains().cooldownMultiplier(p);
        long left = cooldowns.remainingMillis(def.id());
        if (left > 0) {
            bar(p, "<white>" + def.name() + " <gray>recovering: " + String.format(Locale.ROOT, "%.1fs", left / 1000.0));
            return;
        }
        if (!plugin.paradox().canSpend(cost)) {
            plugin.audio().fail(p);
            bar(p, "<red>Not enough PARADOX <gray>(" + (int) plugin.paradox().current() + "/" + (int) Math.ceil(cost) + ")");
            return;
        }

        LivingEntity target = null;
        if (behavior.targeting() == Targeting.ENTITY) {
            target = findTarget(p, def.range() * plugin.transform().rangeMultiplier());
            if (target == null) { bar(p, "<gray>No target in sight."); return; }
        }

        AbilityResult result;
        dev.des.orison.combo.ComboDef combo = plugin.combos().preview(def.id(), target == null ? null : target.getUniqueId());
        String resisted = plugin.azriel().gate(p, def, combo);
        if (resisted != null) { bar(p, "<red>" + mm.escapeTags(resisted)); plugin.audio().fail(p); return; }
        try {
            result = behavior.execute(new AbilityContext(plugin, p, def, target, combo));
        } catch (Throwable t) {
            plugin.getLogger().log(Level.SEVERE, "Ability '" + def.id() + "' threw", t);
            result = AbilityResult.fail("The ability failed.");
        }
        if (!result.ok()) { bar(p, "<red>" + mm.escapeTags(result.message())); plugin.audio().fail(p); return; }

        plugin.paradox().spend(cost);
        cooldowns.start(def.id(), cooldown);
        plugin.combos().commit(p, def, target, combo);
        int newLevel = plugin.mastery().record(def.id());
        plugin.quests().event(dev.des.orison.quest.ObjectiveType.ABILITY_USE, def.id(), 1);
        if (newLevel > 0) {
            p.sendMessage(mm.deserialize("<gray>" + def.name() + " mastery reached <white>level " + newLevel + "<gray>."));
            plugin.audio().to(p, "ui.mastery_up", dev.des.orison.audio.AudioService.Kind.UI, 1.0f);
        }
        // transformations play their own layered sequence; every other ability plays its Authority's signature
        if (dev.des.orison.transform.TransformRules.levelOf(def.id()) == 0 && !def.id().equals("step_between")) {
            plugin.audio().authority(p, def.authority().name().toLowerCase());
        }
        bar(p, "<white>" + def.name() + " <dark_gray>| <gray>PARADOX " + (int) plugin.paradox().current()
                + "/" + (int) plugin.paradox().max());
        plugin.debug(p.getName() + " cast " + def.id());
    }

    /** First living entity in line of sight; solid blocks stop the ray. */
    private LivingEntity findTarget(Player p, double range) {
        RayTraceResult r = p.getWorld().rayTrace(p.getEyeLocation(), p.getEyeLocation().getDirection(), range,
                FluidCollisionMode.NEVER, true, 0.2, e -> e instanceof LivingEntity le && Targets.canAffect(plugin, p, le));
        return r != null && r.getHitEntity() instanceof LivingEntity le ? le : null;
    }

    private void bar(Player p, String mini) { p.sendActionBar(mm.deserialize(mini)); }
}
