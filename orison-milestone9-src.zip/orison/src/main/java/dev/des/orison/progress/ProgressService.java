package dev.des.orison.progress;

import dev.des.orison.persistence.AuditLog;
import dev.des.orison.persistence.Database;
import dev.des.orison.persistence.Tx;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Cached owner progression (stage, Paradox, explicit ability unlocks). Reads are cached and cheap;
 * writes go to the database thread. Mutate from the main thread only.
 */
public final class ProgressService {

    private record Snapshot(int stage, double paradox, Set<String> unlocked) { }

    private final Database db;
    private volatile int stage;
    private volatile double paradox;
    private volatile boolean dirty;
    private final Set<String> unlocked = ConcurrentHashMap.newKeySet();

    public ProgressService(Database db) { this.db = db; }

    public void loadBlocking() { apply(db.callBlocking(this::read)); }

    public CompletableFuture<Void> reload() { return db.submit(this::read).thenAccept(this::apply); }

    private Snapshot read(Connection c) throws SQLException {
        int st = 0;
        double par = 0;
        try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT stage, paradox FROM progress WHERE id = 1")) {
            if (rs.next()) { st = rs.getInt(1); par = rs.getDouble(2); }
        }
        Set<String> ids = new HashSet<>();
        try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT ability_id FROM ability_unlock")) {
            while (rs.next()) ids.add(rs.getString(1));
        }
        return new Snapshot(st, par, ids);
    }

    private void apply(Snapshot s) {
        stage = s.stage();
        paradox = s.paradox();
        unlocked.clear();
        unlocked.addAll(s.unlocked());
        dirty = false;
    }

    public int stage() { return stage; }
    public double paradox() { return paradox; }
    public boolean isUnlocked(String abilityId) { return unlocked.contains(abilityId); }

    public void setParadox(double value) {
        paradox = value;
        dirty = true;
    }

    public CompletableFuture<Void> flushAsync() {
        if (!dirty) return CompletableFuture.completedFuture(null);
        double v = paradox;
        dirty = false;
        return db.submit(c -> { writeParadox(c, v); return null; });
    }

    public void flushBlocking() {
        if (!dirty) return;
        double v = paradox;
        dirty = false;
        db.callBlocking(c -> { writeParadox(c, v); return null; });
    }

    private static void writeParadox(Connection c, double v) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("UPDATE progress SET paradox = ? WHERE id = 1")) {
            ps.setDouble(1, v);
            ps.executeUpdate();
        }
    }

    public CompletableFuture<Void> setStage(int newStage, String actor) {
        int previous = stage;
        return db.submit(c -> {
            Tx.run(c, () -> {
                try (PreparedStatement ps = c.prepareStatement("UPDATE progress SET stage = ?, updated_at = ? WHERE id = 1")) {
                    ps.setInt(1, newStage);
                    ps.setLong(2, System.currentTimeMillis());
                    if (ps.executeUpdate() == 0) throw new SQLException("No progress row (no owner bound yet)");
                }
                AuditLog.insert(c, actor, "STAGE_SET", previous + " -> " + newStage);
            });
            return null;
        }).thenAccept(v -> stage = newStage);
    }

    public CompletableFuture<Void> unlock(Collection<String> abilityIds, String actor) {
        List<String> ids = List.copyOf(abilityIds);
        return db.submit(c -> {
            Tx.run(c, () -> {
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT OR IGNORE INTO ability_unlock (ability_id, unlocked_at, source) VALUES (?, ?, ?)")) {
                    for (String id : ids) {
                        ps.setString(1, id);
                        ps.setLong(2, System.currentTimeMillis());
                        ps.setString(3, actor);
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                AuditLog.insert(c, actor, "ABILITY_UNLOCK",
                        ids.size() <= 5 ? String.join(",", ids) : ids.size() + " abilities");
            });
            return null;
        }).thenAccept(v -> unlocked.addAll(ids));
    }
}
