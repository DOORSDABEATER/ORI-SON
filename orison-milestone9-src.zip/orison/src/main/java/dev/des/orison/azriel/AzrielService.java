package dev.des.orison.azriel;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityDef;
import dev.des.orison.audio.AudioService;
import dev.des.orison.combo.ComboDef;
import dev.des.orison.echo.ClaimOutcome;
import dev.des.orison.echo.ClaimService;
import dev.des.orison.echo.Pending;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/**
 * The Azriel Protocol. Wraps an existing Azriel boss (a MythicMobs mob whose internal name is azriel.mythic-id, or the admin-spawned
 * fallback) with a five-phase script. Azriel's own health bar is never rewritten: phases are enforced by clamping damage to a
 * per-phase floor, so none can be skipped. Nothing here spawns Mythic skills or changes blocks. Main thread only.
 */
public final class AzrielService implements Listener {
    public static final String IDENTITY = "mythic:azriel";

    private final OrisonPlugin plugin;
    private final NamespacedKey tag;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Random rng = new Random();
    private final AzrielRules.Adaptation adaptation = new AzrielRules.Adaptation(20_000, 3);
    private final Map<UUID, Boolean> identityCache = new LinkedHashMap<>(64, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<UUID, Boolean> e) { return size() > 512; }
    };
    private final Set<UUID> barViewers = new HashSet<>();
    private final Set<UUID> handledVictims = new HashSet<>();   // bosses whose victory record the encounter already wrote

    private boolean active;
    private Phase phase;
    private UUID boss;
    private Location arena;
    private long shieldBrokenUntil;
    private BossBar bar;
    private BukkitTask watchTask, phase3Task, pulseTask;
    private UUID warnedBoss;

    public AzrielService(OrisonPlugin plugin) {
        this.plugin = plugin;
        this.tag = new NamespacedKey(plugin, "azriel");
    }

    // ------------------------------------------------------------------ identity

    private boolean enabled() { return plugin.getConfig().getBoolean("azriel.enabled", true); }

    public boolean active() { return active; }

    /** True while this boss is part of the running encounter, or after the encounter wrote its victory record. */
    public boolean handles(Entity e) {
        return e != null && ((active && e.getUniqueId().equals(boss)) || handledVictims.contains(e.getUniqueId()));
    }
    public Phase phase() { return phase; }

    /** True for the admin-spawned fallback boss or a MythicMobs mob named azriel.mythic-id. Cached per entity. */
    public boolean isAzriel(Entity e) {
        if (!(e instanceof LivingEntity) || e instanceof Player) return false;
        if (e.getPersistentDataContainer().has(tag, PersistentDataType.BYTE)) return true;
        Boolean cached = identityCache.get(e.getUniqueId());
        if (cached != null) return cached;
        String want = plugin.getConfig().getString("azriel.mythic-id", "azriel").toLowerCase(Locale.ROOT);
        boolean is = plugin.mythic().internalName(e).map(n -> n.toLowerCase(Locale.ROOT).equals(want)).orElse(false);
        identityCache.put(e.getUniqueId(), is);
        return is;
    }

    private Player ownerPlayer() { return plugin.owners().owner().map(Bukkit::getPlayer).orElse(null); }

    private static Entity source(Entity damager) {
        return damager instanceof Projectile p && p.getShooter() instanceof Entity s ? s : damager;
    }

    // ------------------------------------------------------------------ engagement

    private boolean engage(Player owner, LivingEntity b, boolean ignoreStage) {
        if (!enabled()) return false;
        int min = plugin.getConfig().getInt("azriel.min-stage", 6);
        if (!ignoreStage && plugin.progress().stage() < min) {
            if (!b.getUniqueId().equals(warnedBoss)) {
                warnedBoss = b.getUniqueId();
                owner.sendMessage(mm.deserialize("<dark_gray>Azriel does not recognise you. Return when you are more than this."));
            }
            return false;
        }
        active = true;
        boss = b.getUniqueId();
        arena = b.getLocation().clone();
        adaptation.clear();
        shieldBrokenUntil = 0;
        double frac = b.getHealth() / Math.max(1.0, b.getMaxHealth());
        Phase start = AzrielRules.initialPhase(frac, plugin.quests().hasStory("azriel_phase4"));

        bar = BossBar.bossBar(Component.text("AZRIEL"), (float) Math.max(0.0, Math.min(1.0, frac)), BossBar.Color.WHITE, BossBar.Overlay.PROGRESS);
        watchTask = Bukkit.getScheduler().runTaskTimer(plugin, this::watch, 10L, 10L);
        owner.sendMessage(mm.deserialize("<white><b>AZRIEL PROTOCOL</b> <dark_gray>- <gray>the final encounter begins."));
        enterPhase(start);
        return true;
    }

    /** Ends the scripted encounter (boss and flags are left as they are). Safe to call repeatedly. */
    public void reset() {
        if (watchTask != null) { watchTask.cancel(); watchTask = null; }
        if (phase3Task != null) { phase3Task.cancel(); phase3Task = null; }
        if (pulseTask != null) { pulseTask.cancel(); pulseTask = null; }
        if (bar != null) {
            for (UUID id : barViewers) { Player p = Bukkit.getPlayer(id); if (p != null) p.hideBossBar(bar); }
            barViewers.clear();
            bar = null;
        }
        if (boss != null && Bukkit.getEntity(boss) instanceof Mob m && m.isValid()) m.setAware(true);
        adaptation.clear();
        active = false;
        phase = null;
        boss = null;
    }

    /** Plugin disable: end the script and remove the fallback boss if one is standing. */
    public void shutdown() {
        Entity b = boss == null ? null : Bukkit.getEntity(boss);
        boolean fallback = b != null && b.getPersistentDataContainer().has(tag, PersistentDataType.BYTE);
        reset();
        if (fallback) b.remove();
    }

    private LivingEntity bossEntity() {
        return boss != null && Bukkit.getEntity(boss) instanceof LivingEntity le && le.isValid() && !le.isDead() ? le : null;
    }

    private boolean inArena(Player p) {
        double r = plugin.getConfig().getDouble("azriel.arena-radius", 48);
        return arena != null && p.getWorld() == arena.getWorld() && p.getLocation().distanceSquared(arena) <= r * r;
    }

    // ------------------------------------------------------------------ watch loop

    private void watch() {
        LivingEntity b = bossEntity();
        Player owner = ownerPlayer();
        if (b == null || owner == null || owner.isDead()) { reset(); return; }
        arena = b.getLocation().clone();
        bar.progress((float) Math.max(0.0, Math.min(1.0, b.getHealth() / Math.max(1.0, b.getMaxHealth()))));
        for (Player p : b.getWorld().getPlayers()) {
            boolean near = inArena(p);
            if (near && barViewers.add(p.getUniqueId())) p.showBossBar(bar);
            else if (!near && barViewers.remove(p.getUniqueId())) p.hideBossBar(bar);
        }
    }

    private void updateBarTitle() {
        if (bar == null || phase == null) return;
        String extra = phase == Phase.RECOGNITION_FAILURE ? " | RECORD: IRREGULAR" : phase == Phase.IMPOSSIBLE_RECORD ? " | RECORD: NONE" : "";
        bar.name(Component.text("AZRIEL - " + roman(phase.number) + ": " + phase.title + extra));
        bar.color(phase == Phase.IMPOSSIBLE_RECORD || phase == Phase.FINAL_OMISSION ? BossBar.Color.RED : BossBar.Color.WHITE);
    }

    private static String roman(int n) { return new String[]{"", "PHASE I", "PHASE II", "PHASE III", "PHASE IV", "PHASE V"}[Math.max(1, Math.min(5, n))]; }

    // ------------------------------------------------------------------ phases

    private void announce(String title, String subtitle) {
        for (UUID id : barViewers) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.showTitle(Title.title(Component.text(title), Component.text(subtitle),
                    Title.Times.times(Duration.ofMillis(400), Duration.ofMillis(2800), Duration.ofMillis(800))));
        }
        Player o = ownerPlayer();
        if (o != null && !barViewers.contains(o.getUniqueId())) o.showTitle(Title.title(Component.text(title), Component.text(subtitle)));
    }

    private void enterPhase(Phase p) {
        phase = p;
        updateBarTitle();
        Player owner = ownerPlayer();
        LivingEntity b = bossEntity();
        if (owner == null || b == null) return;
        Location at = b.getLocation();
        plugin.audio().at(at, "azriel.phase", AudioService.Kind.ABILITY, 64, 1.0f);
        if (plugin.vfx().usable(owner)) {
            plugin.vfxLib().shock(at, 9f, 22);
            plugin.vfxLib().gate(at, at.getYaw(), 1.6f, 24);
        }
        switch (p) {
            case RECOGNITION_FAILURE -> {
                announce("RECOGNITION FAILURE", "ORISON cannot read this record");
                owner.sendMessage(mm.deserialize("<dark_gray>[interface] <gray>Perception returns incomplete results. Some authorities are resisted. <white>IRREGULAR."));
            }
            case AUTHORITY_CONFLICT -> {
                shieldBrokenUntil = 0;
                adaptation.clear();
                announce("AUTHORITY CONFLICT", "Azriel answers what you repeat");
                owner.sendMessage(mm.deserialize("<dark_gray>[interface] <gray>Azriel answers any authority you lean on. Only a combination breaks its answer; your Legion wears it down."));
            }
            case IMPOSSIBLE_RECORD -> {
                if (b instanceof Mob m) m.setAware(false);
                announce("IMPOSSIBLE RECORD", "Say AWAKEN");
                owner.sendMessage(mm.deserialize("<dark_gray>[interface] <gray>Azriel stills. ORISON reaches for the record. <white>Say AWAKEN."));
                int secs = plugin.getConfig().getInt("azriel.phase3-seconds", 30);
                if (phase3Task != null) phase3Task.cancel();
                phase3Task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    Player o = ownerPlayer();
                    if (active && phase == Phase.IMPOSSIBLE_RECORD && o != null) {
                        o.sendMessage(mm.deserialize("<dark_gray>[interface] <gray>ORISON makes the attempt on its own."));
                        plugin.claims().claim(o, false);   // routed through interceptClaim
                    }
                }, secs * 20L);
            }
            case THE_THING_THAT_NEVER_WAS -> phaseFour(owner, b);
            case FINAL_OMISSION -> {
                announce("FINAL OMISSION", "Nothing is left to omit but this");
                owner.sendMessage(mm.deserialize("<dark_gray>[interface] <gray>Azriel begins to omit the ground beneath you. Watch the ring."));
                startPulses();
            }
        }
    }

    /** Phase IV: the final recognition. The owner is given the final manifestation and full PARADOX. */
    private void phaseFour(Player owner, LivingEntity b) {
        if (b instanceof Mob m) m.setAware(true);
        announce("THE THING THAT NEVER WAS", "Absolute recognition");
        plugin.quests().setStory("azriel_phase4", "AZRIEL");                       // completes ABSOLUTE RECOGNITION -> stage 7
        plugin.paradox().gain(plugin.paradox().max());
        plugin.transform().start(owner, 4, plugin.getConfig().getDouble("azriel.final-manifestation-seconds", 60));
        plugin.vfxOverlay().whiteout(owner, 2, 6, 24);
        plugin.audio().to(owner, "ui.stage_up", AudioService.Kind.UI, 1.0f);
        owner.sendMessage(mm.deserialize("<white>THE THING THAT NEVER WAS <dark_gray>| <gray>the last recognition arrives. Every authority answers."));
    }

    private void startPulses() {
        if (pulseTask != null) pulseTask.cancel();
        pulseTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            LivingEntity b = bossEntity();
            if (b == null || phase != Phase.FINAL_OMISSION) return;
            Location at = b.getLocation();
            Player owner = ownerPlayer();
            plugin.audio().at(at, "azriel.pulse", AudioService.Kind.ABILITY, 48, 1.0f);       // telegraph
            if (owner != null && plugin.vfx().usable(owner)) plugin.vfxLib().ring(at, 12f, 40);
            double dmg = plugin.getConfig().getDouble("azriel.pulse-damage", 6.0);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                LivingEntity bb = bossEntity();
                if (bb == null || phase != Phase.FINAL_OMISSION) return;
                for (Player p : bb.getWorld().getPlayers()) {
                    if (p.getLocation().distanceSquared(at) <= 144 && !p.isDead()) p.damage(dmg, bb);   // normal damage events: immunity/NOT TODAY apply
                }
            }, 40L);
        }, 100L, 240L);
    }

    // ------------------------------------------------------------------ ability + claim hooks

    /** Phase rules for abilities cast by the owner inside the arena. Returns a refusal message or null to allow. Resisted casts cost nothing. */
    public String gate(Player p, AbilityDef def, ComboDef combo) {
        if (!active || phase == null || !plugin.owners().isOwner(p.getUniqueId()) || !inArena(p)) return null;
        String auth = def.authority().name().toLowerCase(Locale.ROOT);
        switch (phase) {
            case RECOGNITION_FAILURE -> {
                if (def.id().equals("awaken")) return null;
                if (AzrielRules.resistedInPhaseOne(auth, rng.nextDouble())) {
                    return Set.of("perception", "omission", "nonexistence").contains(auth)
                            ? "RECOGNITION FAILURE: ORISON cannot read this record." : "IRREGULAR: Azriel does not respond as recorded.";
                }
                return null;
            }
            case AUTHORITY_CONFLICT -> {
                if (combo != null) {
                    shieldBrokenUntil = System.currentTimeMillis() + 8000;
                    p.sendMessage(mm.deserialize("<white>ANSWER BROKEN <dark_gray>| <gray>" + combo.name() + " - strike now."));
                    return null;
                }
                if (adaptation.shouldCounter(auth, System.currentTimeMillis())) return "ANSWERED: Azriel has already answered your " + def.authority().title() + ".";
                return null;
            }
            case IMPOSSIBLE_RECORD -> {
                return def.id().equals("awaken") ? null : "IMPOSSIBLE RECORD: nothing else can be recorded now.";
            }
            default -> { return null; }
        }
    }

    /** Called at the start of every AWAKEN claim. During phase III this is the failed claim; otherwise null (normal claim). */
    public ClaimService.ClaimResult interceptClaim(Player owner) {
        if (!active || phase != Phase.IMPOSSIBLE_RECORD) return null;
        if (phase3Task != null) { phase3Task.cancel(); phase3Task = null; }
        plugin.audio().at(owner.getLocation(), "azriel.impossible", AudioService.Kind.ECHO, 40, 1.0f);
        Bukkit.getScheduler().runTask(plugin, () -> { if (active && phase == Phase.IMPOSSIBLE_RECORD) enterPhase(Phase.THE_THING_THAT_NEVER_WAS); });
        return new ClaimService.ClaimResult(ClaimOutcome.IRREGULAR,
                "AZRIEL: IMPOSSIBLE RECORD. ORISON reaches for the record and finds an irregularity that cannot be recorded through ordinary reclamation.", null);
    }

    /** After Azriel has fallen, the first attempt to claim its record is the acknowledgement that completes THE EXCEPTION. */
    public void beforeAzrielClaim(Player owner) {
        if (plugin.quests().hasStory("azriel_defeated") && !plugin.quests().hasStory("exception_acknowledged")) {
            plugin.quests().setStory("exception_acknowledged", "AZRIEL");
            owner.sendMessage(mm.deserialize("<white>THE EXCEPTION <dark_gray>| <gray>the record accepts what it could not read."));
        }
    }

    // ------------------------------------------------------------------ damage + death

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBossDamaged(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof LivingEntity v) || !isAzriel(v)) return;
        if (!active) {
            Entity src = e instanceof EntityDamageByEntityEvent be ? source(be.getDamager()) : null;
            Player owner = ownerPlayer();
            if (src == null || owner == null || !(src.equals(owner) || plugin.echo().isEchoEntity(src))) return;
            if (!engage(owner, v, false)) return;
        }
        if (!v.getUniqueId().equals(boss) || phase == null) return;

        double health = v.getHealth(), max = v.getMaxHealth();
        if (phase == Phase.AUTHORITY_CONFLICT) {
            int[] near = {0};
            plugin.echo().forEachActive(m -> { if (m.getWorld() == v.getWorld() && m.getLocation().distanceSquared(v.getLocation()) <= 64) near[0]++; });
            double red = AzrielRules.shieldReduction(near[0], System.currentTimeMillis() < shieldBrokenUntil);
            e.setDamage(e.getDamage() * (1.0 - red));
        }
        double dmg = e.getFinalDamage();
        double allowed = AzrielRules.allowedDamage(health, max, dmg, phase);
        if (allowed <= 0) e.setCancelled(true);
        else if (allowed < dmg) e.setDamage(e.getDamage() * (allowed / dmg));
        if (AzrielRules.reachesFloor(health, max, dmg, phase)) {
            Phase from = phase;
            Bukkit.getScheduler().runTask(plugin, () -> { if (active && phase == from) enterPhase(from.next()); });
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        if (!active || !e.getEntity().getUniqueId().equals(boss)) return;
        if (phase == Phase.FINAL_OMISSION) victory(e.getEntity());
        else {
            plugin.getLogger().warning("Azriel died during " + phase + " (outside the script); ending the encounter without the lore victory.");
            reset();
        }
    }

    @EventHandler public void onOwnerQuit(PlayerQuitEvent e) { if (active && plugin.owners().isOwner(e.getPlayer().getUniqueId())) reset(); }
    @EventHandler public void onOwnerDeath(PlayerDeathEvent e) { if (active && plugin.owners().isOwner(e.getPlayer().getUniqueId())) reset(); }

    // ------------------------------------------------------------------ victory

    private void victory(LivingEntity dead) {
        Location at = dead.getLocation();
        Set<UUID> audience = new HashSet<>(barViewers);
        Player owner = ownerPlayer();
        if (owner != null) audience.add(owner.getUniqueId());

        // the record Azriel leaves behind: claimable only after THE EXCEPTION
        Pending pd = new Pending();
        pd.identity = IDENTITY;
        pd.displayName = "Azriel";
        pd.entityType = plugin.getConfig().getString("azriel.echo-entity", "wither_skeleton");
        AttributeInstance hp = dead.getAttribute(Attribute.MAX_HEALTH);
        pd.maxHealth = hp == null ? 600 : hp.getBaseValue();
        pd.attackDamage = 10;
        pd.moveSpeed = 0.28;
        pd.location = at.clone();
        pd.expiresAt = System.currentTimeMillis() + plugin.getConfig().getInt("azriel.claim-window-seconds", 600) * 1000L;
        plugin.echoRepo().recordDefeat(pd, 3);
        plugin.hunts().add(pd);
        handledVictims.add(dead.getUniqueId());
        if (handledVictims.size() > 16) handledVictims.clear();
        handledVictims.add(dead.getUniqueId());

        plugin.quests().setStory("azriel_defeated", "AZRIEL");
        reset();

        String[] lines = {
                "<white><b>AZRIEL IS OMITTED.</b>",
                "<gray>Here, once, you were defeated. The record of that defeat remains.",
                "<gray>NULL REQUIEM broke against this thing, and was not rebuilt.",
                "<gray>ORISON does not carry you. You are its only recognised manifestation. The evolution is complete.",
                "<gray>Azriel could not be recorded. That was the point. <white>THE EXCEPTION has begun."};
        for (int i = 0; i < lines.length; i++) {
            final String line = lines[i];
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                for (UUID id : audience) { Player p = Bukkit.getPlayer(id); if (p != null) p.sendMessage(mm.deserialize(line)); }
            }, i * 70L);
        }
        plugin.audio().at(at, "azriel.victory", AudioService.Kind.ABILITY, 80, 1.0f);
        for (UUID id : audience) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            p.showTitle(Title.title(Component.text("AZRIEL IS OMITTED"), Component.text("The Azriel Protocol is complete"),
                    Title.Times.times(Duration.ofMillis(600), Duration.ofMillis(4000), Duration.ofMillis(1500))));
            plugin.vfxOverlay().whiteout(p, 2, 4, 30);
        }
        if (owner != null && plugin.vfx().usable(owner)) {
            plugin.vfxLib().beam(at, 12f, 60);
            plugin.vfxLib().shock(at, 14f, 30);
        }
    }

    // ------------------------------------------------------------------ admin

    /** /orison admin azriel <status|spawn|phase <1-5>|reset> */
    public void admin(CommandSender sender, String[] args) {
        String sub = args.length < 3 ? "status" : args[2].toLowerCase(Locale.ROOT);
        String actor = sender instanceof Player pl ? pl.getName() + "(" + pl.getUniqueId() + ")" : "CONSOLE";
        switch (sub) {
            case "status" -> {
                send(sender, "<gray>Encounter: <white>" + (active ? phase.title + " (phase " + phase.number + ")" : "inactive")
                        + " <gray>flags: <white>phase4=" + plugin.quests().hasStory("azriel_phase4") + " defeated=" + plugin.quests().hasStory("azriel_defeated")
                        + " exception=" + plugin.quests().hasStory("exception_acknowledged"));
                LivingEntity b = bossEntity();
                if (b != null) send(sender, "<gray>Boss health: <white>" + (int) b.getHealth() + "/" + (int) b.getMaxHealth());
            }
            case "spawn" -> {
                if (!(sender instanceof Player p)) { send(sender, "<red>Players only."); return; }
                plugin.audit().record(actor, "AZRIEL_SPAWN", "fallback boss");
                send(sender, spawnFallback(p) ? "<gray>Fallback Azriel spawned. Hit it as the owner to begin."
                        : "<red>Could not spawn the fallback (check azriel.fallback-entity).");
            }
            case "reset" -> {
                plugin.audit().record(actor, "AZRIEL_RESET", "encounter reset");
                shutdown();
                send(sender, "<gray>Encounter reset; fallback boss removed.");
            }
            case "phase" -> {
                int n;
                try { n = args.length >= 4 ? Integer.parseInt(args[3]) : 0; } catch (NumberFormatException ex) { n = 0; }
                if (n < 1 || n > 5) { send(sender, "<gray>Usage: /orison admin azriel phase <1-5>"); return; }
                setPhase(sender, n, actor);
            }
            default -> send(sender, "<gray>Usage: /orison admin azriel <status|spawn|phase|reset>");
        }
    }

    private void setPhase(CommandSender sender, int n, String actor) {
        Player owner = ownerPlayer();
        if (owner == null) { send(sender, "<red>The owner must be online."); return; }
        LivingEntity b = active ? bossEntity() : null;
        if (b == null) {
            for (LivingEntity le : owner.getWorld().getNearbyLivingEntities(owner.getLocation(), 64)) if (isAzriel(le)) { b = le; break; }
        }
        if (b == null) { send(sender, "<red>No Azriel within 64 blocks of the owner."); return; }
        plugin.audit().record(actor, "AZRIEL_PHASE", "phase " + n + " (test)");
        if (!active && !engage(owner, b, true)) { send(sender, "<red>Could not engage."); return; }
        double[] frac = {0, 0.95, 0.70, 0.45, 0.40, 0.18};
        b.setHealth(Math.max(1.0, b.getMaxHealth() * frac[n]));
        enterPhase(Phase.of(n));
        send(sender, "<gray>Azriel set to phase <white>" + n + "<gray> (test).");
    }

    private boolean spawnFallback(Player p) {
        EntityType type = ClaimService.resolveType(plugin.getConfig().getString("azriel.fallback-entity", "wither_skeleton"));
        Class<? extends Entity> cls = type == null ? null : type.getEntityClass();
        if (cls == null || !Mob.class.isAssignableFrom(cls) || !type.isSpawnable()) return false;
        Location l = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(6));
        try {
            @SuppressWarnings("unchecked") Class<Entity> c = (Class<Entity>) cls;
            Entity e = p.getWorld().spawn(l, c, en -> {
                en.getPersistentDataContainer().set(tag, PersistentDataType.BYTE, (byte) 1);
                en.setPersistent(false);
                en.customName(Component.text("AZRIEL"));
                en.setCustomNameVisible(true);
                if (en instanceof Mob m) {
                    m.setRemoveWhenFarAway(false);
                    double health = plugin.getConfig().getDouble("azriel.fallback-health", 600);
                    AttributeInstance hp = m.getAttribute(Attribute.MAX_HEALTH);
                    if (hp != null) { hp.setBaseValue(Math.min(1024, health)); m.setHealth(Math.min(1024, health)); }
                }
            });
            return e != null && e.isValid();
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Fallback Azriel spawn failed", t);
            return false;
        }
    }

    private void send(CommandSender to, String s) { to.sendMessage(mm.deserialize(s)); }
}
