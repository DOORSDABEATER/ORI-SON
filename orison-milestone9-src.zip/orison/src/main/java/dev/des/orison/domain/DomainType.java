package dev.des.orison.domain;

/** Domains temporarily alter a battlefield area. They never modify blocks. */
public enum DomainType {
    KINGDOM_OF_NOTHING("kingdom_of_nothing", "KINGDOM OF NOTHING"),
    THE_STILL_WORLD("the_still_world", "THE STILL WORLD");

    public final String abilityId;
    public final String title;

    DomainType(String abilityId, String title) {
        this.abilityId = abilityId;
        this.title = title;
    }

    public static DomainType ofAbility(String id) {
        for (DomainType t : values()) if (t.abilityId.equals(id)) return t;
        return null;
    }
}
