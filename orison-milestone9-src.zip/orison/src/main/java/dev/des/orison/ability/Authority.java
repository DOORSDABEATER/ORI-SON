package dev.des.orison.ability;

/** The ten Authorities. Each owns exactly seven abilities, in spec order. */
public enum Authority {
    ABSENCE("I", "Absence", "Authority over presence", 2,
            "UNSEEN", "STEP BETWEEN", "NO FOOTPRINTS", "UNTOUCHABLE MOMENT", "MISSING FRAME", "ABSENT HORIZON", "I WAS NEVER THERE"),
    DENIAL("II", "Denial", "Authority over rejection", 2,
            "INVALID", "NO ENTRY", "UNANSWERED", "WRONG TARGET", "NOT TODAY", "SILENCE THE LAW", "ABSOLUTE REFUSAL"),
    OMISSION("III", "Omission", "Authority over removal", 3,
            "WEIGHTLESS", "DIRECTIONLESS", "SOUNDLESS", "BROKEN MOMENTUM", "MISSING GROUND", "OMISSION: FORM", "NOTHING REMAINS"),
    RECKONING("IV", "Reckoning", "Authority over consequences", 3,
            "DEBT COLLECTOR", "RETURN TO SENDER", "UNPAID CONSEQUENCE", "COLLAPSE THE DISTANCE", "JUDGEMENT WITHOUT CAUSE", "EVERYTHING COMES BACK", "FINAL ACCOUNT"),
    THE_UNWRITTEN("V", "The Unwritten", "Authority over the battlefield", 4,
            "WHITEOUT", "THE STILL WORLD", "NO DISTANCE", "FALSE REALITY", "UNWRITTEN LAW", "THE WORLD FORGETS", "KINGDOM OF NOTHING"),
    NONEXISTENCE("VI", "Nonexistence", "Authority over existence", 5,
            "UNMAKE", "UNBEGIN", "UNWRITE", "THE ABSOLUTE ZERO", "EXISTENCE DENIED", "THE THING THAT NEVER WAS", "THE FINAL OMISSION"),
    RECLAMATION("VII", "Reclamation", "Authority over the defeated", 4,
            "AWAKEN", "AWAKEN: ONE", "AWAKEN: LEGION", "AWAKEN: ALL", "PERFECT RECORD", "SOVEREIGN COMMAND", "UNENDING LEGION"),
    DOMINION("VIII", "Dominion", "Authority over the Legion", 4,
            "MY WILL", "FORMATION: VEIL", "FORMATION: HUNT", "DIVIDED PURPOSE", "SOVEREIGN'S PROTECTION", "CONVERGENCE", "ONE AUTHORITY"),
    PERCEPTION("IX", "Perception", "Authority over knowledge", 3,
            "TRUE SIGHT", "EXISTENCE SCAN", "HUNT MARK", "WEAKNESS RECOGNIZED", "RECORD ANALYSIS", "FUTURE FRACTURE", "NOTHING ESCAPES"),
    TRANSCENDENCE("X", "Transcendence", "Authority over ORISON itself", 6,
            "FIRST RECOGNITION", "LIMITLESS MOMENT", "CONTRADICTION", "FRACTURED ASCENSION", "THE UNBOUND", "ABSOLUTE MANIFESTATION", "BEYOND EXISTENCE");

    private final String roman;
    private final String title;
    private final String domain;
    private final int baseUnlockStage;
    private final String[] abilityNames;

    Authority(String roman, String title, String domain, int baseUnlockStage, String... abilityNames) {
        if (abilityNames.length != 7) throw new IllegalStateException(name() + " must have exactly 7 abilities");
        this.roman = roman;
        this.title = title;
        this.domain = domain;
        this.baseUnlockStage = baseUnlockStage;
        this.abilityNames = abilityNames;
    }

    public String roman() { return roman; }
    public String title() { return title; }
    public String domain() { return domain; }
    public int baseUnlockStage() { return baseUnlockStage; }
    public String[] abilityNames() { return abilityNames.clone(); }
}
