package dev.des.orison.presence;

import dev.des.orison.OrisonPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

/** Drops all retained presence state on any discontinuity so nothing stale can render later. */
public final class PresenceListener implements Listener {
    private final OrisonPlugin plugin;

    public PresenceListener(OrisonPlugin plugin) { this.plugin = plugin; }

    private void resetIfOwner(Player p) {
        if (plugin.owners().isOwner(p.getUniqueId())) plugin.presence().reset();
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) { resetIfOwner(e.getPlayer()); }
    @EventHandler public void onJoin(PlayerJoinEvent e) { resetIfOwner(e.getPlayer()); }
    @EventHandler public void onDeath(PlayerDeathEvent e) { resetIfOwner(e.getPlayer()); }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { resetIfOwner(e.getPlayer()); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { resetIfOwner(e.getPlayer()); }
    @EventHandler public void onTeleport(PlayerTeleportEvent e) { resetIfOwner(e.getPlayer()); }
}
