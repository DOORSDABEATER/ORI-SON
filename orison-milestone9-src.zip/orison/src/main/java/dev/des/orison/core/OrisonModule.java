package dev.des.orison.core;

/** A self-contained ORISON subsystem with an isolated lifecycle. */
public interface OrisonModule {
    String id();
    void enable();
    void disable();
    default void reload() {}
}
