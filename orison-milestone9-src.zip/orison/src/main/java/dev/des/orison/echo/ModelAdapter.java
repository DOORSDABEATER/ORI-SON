package dev.des.orison.echo;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.Optional;

/**
 * Optional ModelEngine bridge, by reflection. Reads which model an entity wears and applies the same model
 * to an Echo's base entity. UNVERIFIED against your ModelEngine build: it disables itself on any failure and
 * Echoes then keep the vanilla body.
 */
public final class ModelAdapter {
    private final Plugin plugin;
    private boolean broken;

    public ModelAdapter(Plugin plugin) { this.plugin = plugin; }

    private boolean unavailable() { return broken || !Bukkit.getPluginManager().isPluginEnabled("ModelEngine"); }

    public Optional<String> modelId(Entity e) {
        if (unavailable()) return Optional.empty();
        try {
            Class<?> api = Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
            Object modeled = api.getMethod("getModeledEntity", java.util.UUID.class).invoke(null, e.getUniqueId());
            if (modeled == null) return Optional.empty();
            Object models = modeled.getClass().getMethod("getModels").invoke(modeled);
            if (models instanceof Map<?, ?> map && !map.isEmpty()) {
                Object first = map.keySet().iterator().next();
                return first instanceof String s ? Optional.of(s) : Optional.empty();
            }
            return Optional.empty();
        } catch (Throwable t) {
            fail(t);
            return Optional.empty();
        }
    }

    public boolean apply(Entity target, String modelId) {
        if (unavailable() || modelId == null) return false;
        try {
            Class<?> api = Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
            Object modeled = api.getMethod("createModeledEntity", Entity.class).invoke(null, target);
            Object active = api.getMethod("createActiveModel", String.class).invoke(null, modelId);
            if (modeled == null || active == null) return false;
            for (Method m : modeled.getClass().getMethods()) {
                if (m.getName().equals("addModel") && m.getParameterCount() == 2) {
                    m.invoke(modeled, active, true);
                    break;
                }
            }
            try { modeled.getClass().getMethod("setBaseEntityVisible", boolean.class).invoke(modeled, false); } catch (NoSuchMethodException ignored) { }
            return true;
        } catch (Throwable t) {
            fail(t);
            return false;
        }
    }

    private void fail(Throwable t) {
        broken = true;
        plugin.getLogger().warning("ModelEngine bridge disabled (API mismatch): " + t);
    }

    public boolean broken() { return broken; }
}
