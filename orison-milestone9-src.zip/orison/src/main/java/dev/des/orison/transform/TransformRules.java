package dev.des.orison.transform;

/**
 * The four transformations and their gameplay modifiers (pure). They are manifestations, never equipment.
 * Level 0 = none. Multipliers apply to every ability while the transformation is active.
 */
public final class TransformRules {
    private TransformRules() { }

    public static final String[] NAMES = {"NONE", "INITIAL MANIFESTATION", "FRACTURED ASCENSION", "ABSOLUTE MANIFESTATION", "BEYOND EXISTENCE"};
    /** Ability id that triggers each transformation (level = index). */
    public static final String[] ABILITY_IDS = {null, "first_recognition", "fractured_ascension", "absolute_manifestation", "beyond_existence"};
    public static final int[] MIN_STAGE = {0, 4, 5, 6, 7};
    private static final double[] COST = {1.0, 0.95, 0.90, 0.85, 0.75};
    private static final double[] COOLDOWN = {1.0, 0.90, 0.80, 0.70, 0.60};
    private static final double[] RANGE = {1.0, 1.2, 1.4, 1.7, 2.2};
    private static final int[] SPEED_AMPLIFIER = {-1, -1, 0, 1, 1};   // -1 = no speed effect

    public static final double CONTRADICTION_RANGE = 1.25;
    public static final double CONTRADICTION_COOLDOWN = 0.85;

    private static int c(int level) { return Math.max(0, Math.min(4, level)); }

    public static String name(int level) { return NAMES[c(level)]; }
    public static double costFactor(int level) { return COST[c(level)]; }
    public static double cooldownFactor(int level) { return COOLDOWN[c(level)]; }
    public static double rangeFactor(int level) { return RANGE[c(level)]; }
    public static int speedAmplifier(int level) { return SPEED_AMPLIFIER[c(level)]; }

    /** Level triggered by an ability id, or 0. */
    public static int levelOf(String abilityId) {
        for (int i = 1; i < ABILITY_IDS.length; i++) if (ABILITY_IDS[i].equals(abilityId)) return i;
        return 0;
    }
}
