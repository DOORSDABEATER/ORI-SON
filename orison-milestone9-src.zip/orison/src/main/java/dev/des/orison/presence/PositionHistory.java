package dev.des.orison.presence;

/** Fixed-size ring buffer of recent owner poses, used for delayed afterimages. No allocation growth. */
public final class PositionHistory {
    public record Sample(double x, double y, double z, float yaw, boolean sneaking) { }

    private final Sample[] ring;
    private int next;
    private int size;

    public PositionHistory(int capacity) { this.ring = new Sample[Math.max(1, capacity)]; }

    public void add(Sample s) {
        ring[next] = s;
        next = (next + 1) % ring.length;
        if (size < ring.length) size++;
    }

    /** back=0 is the newest sample. Returns null when there is not that much history. */
    public Sample get(int back) {
        if (back < 0 || back >= size) return null;
        return ring[((next - 1 - back) % ring.length + ring.length) % ring.length];
    }

    public int size() { return size; }

    public void clear() {
        java.util.Arrays.fill(ring, null);
        next = 0;
        size = 0;
    }
}
