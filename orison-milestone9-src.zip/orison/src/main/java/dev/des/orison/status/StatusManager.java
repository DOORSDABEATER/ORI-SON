package dev.des.orison.status;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Timed statuses with guaranteed cleanup. Every temporary effect an ability creates is registered
 * here with an onEnd hook, which runs exactly once on expiry, replacement, cancellation, death,
 * logout or plugin disable. Main thread only.
 */
public final class StatusManager {
    private record Active(BukkitTask task, Runnable onEnd) { }

    private final Plugin plugin;
    private final Map<UUID, Map<String, Active>> active = new HashMap<>();

    public StatusManager(Plugin plugin) { this.plugin = plugin; }

    public void start(Player player, String key, long ticks, Runnable onEnd) {
        UUID id = player.getUniqueId();
        end(id, key);
        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> end(id, key), Math.max(1L, ticks));
        active.computeIfAbsent(id, k -> new HashMap<>()).put(key, new Active(task, onEnd));
    }

    public boolean has(UUID id, String key) {
        Map<String, Active> m = active.get(id);
        return m != null && m.containsKey(key);
    }

    public void end(UUID id, String key) {
        Map<String, Active> m = active.get(id);
        if (m == null) return;
        Active a = m.remove(key);
        if (m.isEmpty()) active.remove(id);
        if (a == null) return;
        a.task().cancel();
        run(a, key);
    }

    public void endAll(UUID id) {
        Map<String, Active> m = active.get(id);
        if (m == null) return;
        for (String key : new ArrayList<>(m.keySet())) end(id, key);
    }

    public void endEverything() {
        List<UUID> ids = new ArrayList<>(active.keySet());
        for (UUID id : ids) endAll(id);
    }

    private void run(Active a, String key) {
        try { a.onEnd().run(); }
        catch (Throwable t) { plugin.getLogger().log(Level.WARNING, "Status cleanup failed for '" + key + "'", t); }
    }
}
