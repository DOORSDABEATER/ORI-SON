package dev.des.orison.presence;

/** Hard per-update particle cap so presence can never flood the server or a client. */
public final class ParticleBudget {
    private int remaining;

    public ParticleBudget(int max) { this.remaining = Math.max(0, max); }

    public boolean take(int n) {
        if (remaining < n) { remaining = 0; return false; }
        remaining -= n;
        return true;
    }

    public int remaining() { return remaining; }
}
