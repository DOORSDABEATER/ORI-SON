package dev.des.orison.ability;

public record AbilityResult(boolean ok, String message) {
    public static AbilityResult ok(String message) { return new AbilityResult(true, message); }
    public static AbilityResult fail(String message) { return new AbilityResult(false, message); }
}
