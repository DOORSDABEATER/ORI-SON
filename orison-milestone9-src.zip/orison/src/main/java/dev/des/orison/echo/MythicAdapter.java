package dev.des.orison.echo;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.Optional;
import java.util.UUID;

/**
 * Optional MythicMobs bridge, by reflection so ORISON never needs MythicMobs at compile or run time.
 * Only reads identity (the mob's internal name); it never spawns or scripts Mythic mobs, which is what keeps
 * boss encounter mechanics out of Echoes. UNVERIFIED against your MythicMobs build: on any failure it disables itself.
 */
public final class MythicAdapter {
    private final Plugin plugin;
    private boolean broken;

    public MythicAdapter(Plugin plugin) { this.plugin = plugin; }

    public Optional<String> internalName(Entity e) {
        if (broken || !Bukkit.getPluginManager().isPluginEnabled("MythicMobs")) return Optional.empty();
        try {
            Class<?> bukkit = Class.forName("io.lumine.mythic.bukkit.MythicBukkit");
            Object inst = bukkit.getMethod("inst").invoke(null);
            Object mobManager = inst.getClass().getMethod("getMobManager").invoke(inst);
            Method getActive = mobManager.getClass().getMethod("getActiveMob", UUID.class);
            Object opt = getActive.invoke(mobManager, e.getUniqueId());
            if (!(opt instanceof Optional<?> o) || o.isEmpty()) return Optional.empty();
            Object active = o.get();
            Object type = active.getClass().getMethod("getType").invoke(active);
            Object name = type.getClass().getMethod("getInternalName").invoke(type);
            return name instanceof String s && !s.isBlank() ? Optional.of(s) : Optional.empty();
        } catch (Throwable t) {
            broken = true;
            plugin.getLogger().warning("MythicMobs bridge disabled (API mismatch): " + t);
            return Optional.empty();
        }
    }

    public boolean broken() { return broken; }
}
