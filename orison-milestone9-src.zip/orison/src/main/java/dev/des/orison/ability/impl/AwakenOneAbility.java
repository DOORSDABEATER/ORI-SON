package dev.des.orison.ability.impl;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityResult;
import dev.des.orison.echo.EchoRecord;
import dev.des.orison.echo.EchoService;

/** VII.2 AWAKEN: ONE - summon the strongest stored Echo that is not already active. */
public final class AwakenOneAbility implements AbilityBehavior {
    private final OrisonPlugin plugin;

    public AwakenOneAbility(OrisonPlugin plugin) { this.plugin = plugin; }

    @Override public String abilityId() { return "awaken_one"; }

    @Override
    public AbilityResult execute(AbilityContext ctx) {
        long now = System.currentTimeMillis();
        for (EchoRecord r : plugin.echoRepo().sorted()) {
            if (plugin.echo().isActive(r.id) || r.downedUntil > now) continue;
            EchoService.SummonResult s = plugin.echo().summon(r);
            return s.ok() ? AbilityResult.ok("AWAKEN: ONE") : AbilityResult.fail(r.label() + ": " + s.message());
        }
        return AbilityResult.fail("No stored Echo is ready.");
    }
}
