package dev.des.orison.ability.impl;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityResult;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * I.1 UNSEEN - the owner is removed from other players' view for the duration. Ends early if the
 * owner deals damage. Does not affect mob targeting. Players who join mid-effect are also hidden from
 * (see StatusListener). Everything is undone by the status cleanup.
 */
public final class UnseenAbility implements AbilityBehavior {
    private final OrisonPlugin plugin;

    public UnseenAbility(OrisonPlugin plugin) { this.plugin = plugin; }

    @Override public String abilityId() { return "unseen"; }

    @Override
    public AbilityResult execute(AbilityContext ctx) {
        Player owner = ctx.caster();
        if (plugin.vfx().usable(owner)) {
            plugin.vfxLib().silhouette(owner.getLocation(), owner.getLocation().getYaw(), 26, null);
            plugin.vfxLib().rift(owner.getLocation(), owner.getLocation().getYaw(), 2.0f, 18);
        }
        for (Player other : Bukkit.getOnlinePlayers()) {
            if (!other.equals(owner)) other.hidePlayer(plugin, owner);
        }
        plugin.statuses().start(owner, "unseen", (long) (ctx.def().duration() * 20), () -> {
            for (Player other : Bukkit.getOnlinePlayers()) {
                if (!other.equals(owner)) other.showPlayer(plugin, owner);
            }
            if (owner.isOnline() && plugin.vfx().usable(owner)) {
                plugin.vfxLib().rift(owner.getLocation(), owner.getLocation().getYaw(), 2.0f, 16);
            }
        });
        return AbilityResult.ok("UNSEEN");
    }
}
