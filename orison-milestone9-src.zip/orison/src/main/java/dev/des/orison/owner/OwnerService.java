package dev.des.orison.owner;

import dev.des.orison.persistence.AuditLog;
import dev.des.orison.persistence.Database;
import org.bukkit.plugin.Plugin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * The single source of truth for who owns ORISON. Ownership is a stored UUID only:
 * OP status, permissions and names never confer it.
 */
public final class OwnerService {
    private final Plugin plugin;
    private final Database db;
    private volatile UUID owner;

    public OwnerService(Plugin plugin, Database db, AuditLog audit) {
        this.plugin = plugin;
        this.db = db;
    }

    public void loadBlocking() {
        owner = db.callBlocking(c -> {
            try (PreparedStatement ps = c.prepareStatement("SELECT uuid FROM owner WHERE id = 1");
                 ResultSet rs = ps.executeQuery()) {
                return rs.next() ? UUID.fromString(rs.getString(1)) : null;
            }
        });
    }

    public Optional<UUID> owner() { return Optional.ofNullable(owner); }

    public boolean isOwner(UUID uuid) { return uuid != null && uuid.equals(owner); }

    /** Startup only. */
    public void bindBlocking(UUID newOwner, String actor, String action) {
        write(newOwner, actor, action).join();
    }

    public CompletableFuture<Void> bind(UUID newOwner, String actor) {
        return write(newOwner, actor, "OWNER_GRANT");
    }

    public CompletableFuture<Void> revoke(String actor) {
        UUID previous = owner;
        return db.submit(c -> {
            transaction(c, () -> {
                try (PreparedStatement ps = c.prepareStatement("DELETE FROM owner WHERE id = 1")) {
                    ps.executeUpdate();
                }
                AuditLog.insert(c, actor, "OWNER_REVOKE", "previous=" + previous);
            });
            return null;
        }).thenAccept(v -> {
            owner = null;
            plugin.getLogger().info("[AUDIT] " + actor + " OWNER_REVOKE previous=" + previous);
        });
    }

    private CompletableFuture<Void> write(UUID newOwner, String actor, String action) {
        UUID previous = owner;
        return db.submit(c -> {
            transaction(c, () -> {
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT OR REPLACE INTO owner (id, uuid, bound_at) VALUES (1, ?, ?)")) {
                    ps.setString(1, newOwner.toString());
                    ps.setLong(2, System.currentTimeMillis());
                    ps.executeUpdate();
                }
                // Progression row is created once and kept across reassignment.
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT OR IGNORE INTO progress (id, stage, updated_at) VALUES (1, 1, ?)")) {
                    ps.setLong(1, System.currentTimeMillis());
                    ps.executeUpdate();
                }
                AuditLog.insert(c, actor, action, "previous=" + previous + " new=" + newOwner);
            });
            return null;
        }).thenAccept(v -> {
            owner = newOwner;
            plugin.getLogger().info("[AUDIT] " + actor + " " + action + " previous=" + previous + " new=" + newOwner);
        });
    }

    public CompletableFuture<Integer> stage() {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("SELECT stage FROM progress WHERE id = 1");
                 ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        });
    }

    @FunctionalInterface
    private interface SqlWork { void run() throws java.sql.SQLException; }

    private static void transaction(Connection c, SqlWork work) throws java.sql.SQLException {
        c.setAutoCommit(false);
        try {
            work.run();
            c.commit();
        } catch (java.sql.SQLException | RuntimeException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }
}
