package dev.des.orison.ability;

import dev.des.orison.OrisonPlugin;

/** PARADOX resource. Read-modify-write from the main thread only. */
public final class ParadoxService {
    private final OrisonPlugin plugin;

    public ParadoxService(OrisonPlugin plugin) { this.plugin = plugin; }

    public double max() { return plugin.settings().paradoxMax(); }
    public double current() { return Math.min(plugin.progress().paradox(), max()); }
    public boolean canSpend(double amount) { return current() + 1e-9 >= amount; }

    public boolean spend(double amount) {
        if (!canSpend(amount)) return false;
        set(current() - amount);
        return true;
    }

    public void gain(double amount) { if (amount > 0) set(current() + amount); }

    private void set(double v) { plugin.progress().setParadox(Math.max(0, Math.min(max(), v))); }
}
