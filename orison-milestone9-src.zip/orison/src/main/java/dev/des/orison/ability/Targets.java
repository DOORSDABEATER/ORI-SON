package dev.des.orison.ability;

import dev.des.orison.OrisonPlugin;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.NPC;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;

/**
 * Who ORISON abilities may affect. Players are excluded unless abilities.affect-players is on AND the world allows PvP,
 * because potion effects and teleports would bypass region PvP rules; damage always goes through normal damage events.
 */
public final class Targets {
    private Targets() { }

    public static boolean canAffect(OrisonPlugin plugin, Player owner, LivingEntity e) {
        if (e == null || e.equals(owner) || !e.isValid() || e.isDead()) return false;
        if (plugin.echo().isEchoEntity(e) || e instanceof NPC || e instanceof ArmorStand) return false;
        if (e instanceof Tameable t && t.isTamed()) return false;
        if (e instanceof Player) return plugin.getConfig().getBoolean("abilities.affect-players", false) && owner.getWorld().getPVP();
        return true;
    }
}
