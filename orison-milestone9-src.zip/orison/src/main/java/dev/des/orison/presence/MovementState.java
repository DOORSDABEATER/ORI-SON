package dev.des.orison.presence;

/** What the owner is physically doing right now. Detected from real position/flags, never assumed. */
public enum MovementState {
    IDLE, WALKING, RUNNING, SPRINTING, SNEAKING, JUMPING, FALLING, LANDING, ABILITY_MOVEMENT, TRANSFORMATION
}
