package dev.des.orison.transform;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.quest.ObjectiveType;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;

/**
 * The four transformations and the CONTRADICTION overcharge. All state is a StatusManager status, so it ends and cleans up
 * on expiry, cancellation, death, logout and plugin disable. Casting a higher transformation replaces the current one.
 */
public final class TransformationService {
    private final OrisonPlugin plugin;
    private int level;
    private boolean contradiction;

    public TransformationService(OrisonPlugin plugin) { this.plugin = plugin; }

    public int level() { return level; }
    public boolean contradiction() { return contradiction; }

    public double costMultiplier() { return TransformRules.costFactor(level); }
    public double cooldownMultiplier() { return TransformRules.cooldownFactor(level) * (contradiction ? TransformRules.CONTRADICTION_COOLDOWN : 1.0); }
    public double rangeMultiplier() { return TransformRules.rangeFactor(level) * (contradiction ? TransformRules.CONTRADICTION_RANGE : 1.0); }

    public void start(Player p, int newLevel, double durationSeconds) {
        UUID id = p.getUniqueId();
        long ticks = Math.max(20L, (long) (durationSeconds * 20));
        boolean speed = TransformRules.speedAmplifier(newLevel) >= 0;
        if (speed) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, (int) ticks + 20, TransformRules.speedAmplifier(newLevel), false, false, false));
        }
        plugin.statuses().start(p, "transformation", ticks, () -> {
            level = 0;
            if (p.isOnline()) plugin.audio().at(p.getLocation(), "transform.end", dev.des.orison.audio.AudioService.Kind.ABILITY, 24, 1.0f);
            plugin.presence().setTransformation(0);
            if (speed) p.removePotionEffect(PotionEffectType.SPEED);
        });
        level = newLevel;
        plugin.presence().setTransformation(newLevel);
        plugin.quests().event(ObjectiveType.TRANSFORM_USED, String.valueOf(newLevel), 1);
    }

    public void startContradiction(Player p, double durationSeconds) {
        long ticks = Math.max(20L, (long) (durationSeconds * 20));
        plugin.statuses().start(p, "contradiction", ticks, () -> {
            contradiction = false;
            plugin.presence().setContradiction(false);
        });
        plugin.audio().at(p.getLocation(), "transform.contradiction", dev.des.orison.audio.AudioService.Kind.ABILITY, 28, 1.0f);
        contradiction = true;
        plugin.presence().setContradiction(true);
    }

    public boolean cancel(Player p) {
        boolean any = plugin.statuses().has(p.getUniqueId(), "transformation") || plugin.statuses().has(p.getUniqueId(), "contradiction");
        plugin.statuses().end(p.getUniqueId(), "transformation");
        plugin.statuses().end(p.getUniqueId(), "contradiction");
        return any;
    }
}
