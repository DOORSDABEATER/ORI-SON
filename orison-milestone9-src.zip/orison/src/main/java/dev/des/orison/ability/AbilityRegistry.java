package dev.des.orison.ability;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * All 70 ability definitions. Defaults are generated from the Authority table and written to
 * abilities.yml on first run; every numeric field is then editable there. Missing keys are
 * back-filled so the file stays complete across updates. Default numbers are provisional
 * test values, not final balance.
 */
public final class AbilityRegistry {

    /**
     * id -> {cost, cooldown, range/radius, duration, damage, unlock-stage}. Each id is applied to abilities.yml once
     * (tracked by meta.applied.<id>), so later additions never overwrite values you have tuned.
     */
    private static final Map<String, double[]> OVERRIDES = Map.ofEntries(
            Map.entry("first_recognition", new double[]{30, 120, 0, 40, 0, 4}),
            Map.entry("contradiction", new double[]{25, 60, 0, 15, 0, 5}),
            Map.entry("fractured_ascension", new double[]{45, 150, 0, 50, 0, 5}),
            Map.entry("absolute_manifestation", new double[]{60, 200, 0, 60, 0, 6}),
            Map.entry("beyond_existence", new double[]{80, 300, 0, 90, 0, 7}),
            Map.entry("missing_frame", new double[]{12, 8, 5, 0.6, 0, 2}),
            Map.entry("not_today", new double[]{35, 90, 0, 10, 0, 3}),
            Map.entry("omission_form", new double[]{20, 18, 18, 4, 0, 4}),
            Map.entry("nothing_remains", new double[]{40, 60, 14, 0, 30, 4}),
            Map.entry("return_to_sender", new double[]{18, 25, 0, 5, 0, 3}),
            Map.entry("debt_collector", new double[]{15, 30, 18, 12, 0, 3}),
            Map.entry("everything_comes_back", new double[]{25, 40, 30, 0, 80, 4}),
            Map.entry("collapse_the_distance", new double[]{16, 14, 24, 0, 0, 3}),
            Map.entry("hunt_mark", new double[]{10, 20, 30, 20, 0, 3}),
            Map.entry("future_fracture", new double[]{14, 30, 0, 8, 0, 4}),
            Map.entry("sovereign_command", new double[]{20, 35, 30, 8, 0, 5}),
            Map.entry("one_authority", new double[]{30, 60, 0, 10, 0, 5}),
            Map.entry("kingdom_of_nothing", new double[]{60, 150, 18, 30, 0, 5}),
            Map.entry("the_still_world", new double[]{35, 90, 14, 20, 0, 4}));
    private static final java.util.Set<String> V2_IDS = java.util.Set.of("first_recognition", "contradiction",
            "fractured_ascension", "absolute_manifestation", "beyond_existence");

    private final Plugin plugin;
    private final Map<String, AbilityDef> byId = new LinkedHashMap<>();
    private final List<AbilityDef> byNumber = new ArrayList<>();

    public AbilityRegistry(Plugin plugin) { this.plugin = plugin; }

    public static String slug(String name) {
        return name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
    }

    public void load() {
        byId.clear();
        byNumber.clear();
        File file = new File(plugin.getDataFolder(), "abilities.yml");
        YamlConfiguration yaml = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
        boolean dirty = !file.exists();
        int version = yaml.getInt("meta.defaults-version", 1);
        for (Map.Entry<String, double[]> e : OVERRIDES.entrySet()) {
            String flag = "meta.applied." + e.getKey();
            if (yaml.getBoolean(flag, false)) continue;
            dirty = true;
            yaml.set(flag, true);
            if (version >= 2 && V2_IDS.contains(e.getKey())) continue;   // applied by an earlier version; keep the owner's edits
            String q = "abilities." + e.getKey() + ".";
            double[] v = e.getValue();
            yaml.set(q + "cost", v[0]); yaml.set(q + "cooldown", v[1]); yaml.set(q + "range", v[2]);
            yaml.set(q + "duration", v[3]); yaml.set(q + "damage", v[4]); yaml.set(q + "unlock-stage", (int) v[5]);
        }
        yaml.set("meta.defaults-version", 3);

        for (AbilityDef d : defaults()) {
            String p = "abilities." + d.id() + ".";
            dirty |= fill(yaml, p + "cost", d.cost());
            dirty |= fill(yaml, p + "cooldown", d.cooldown());
            dirty |= fill(yaml, p + "range", d.range());
            dirty |= fill(yaml, p + "duration", d.duration());
            dirty |= fill(yaml, p + "damage", d.damage());
            dirty |= fill(yaml, p + "unlock-stage", d.unlockStage());

            AbilityDef loaded = new AbilityDef(d.id(), d.name(), d.authority(), d.number(), d.indexInAuthority(),
                    clamp(yaml.getDouble(p + "cost"), 0, 10_000),
                    clamp(yaml.getDouble(p + "cooldown"), 0, 3_600),
                    clamp(yaml.getDouble(p + "range"), 0, 256),
                    clamp(yaml.getDouble(p + "duration"), 0, 600),
                    clamp(yaml.getDouble(p + "damage"), 0, 10_000),
                    (int) clamp(yaml.getInt(p + "unlock-stage"), 1, 7),
                    d.ultimate());
            byId.put(loaded.id(), loaded);
            byNumber.add(loaded);
        }
        if (dirty) {
            try {
                plugin.getDataFolder().mkdirs();
                yaml.save(file);
            } catch (IOException e) {
                plugin.getLogger().warning("Could not save abilities.yml: " + e);
            }
        }
    }

    private static boolean fill(YamlConfiguration y, String path, double value) {
        if (y.contains(path)) return false;
        y.set(path, value);
        return true;
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    /** Provisional defaults: standard 3-28s cooldowns, ultimates 90-270s. */
    private static List<AbilityDef> defaults() {
        List<AbilityDef> out = new ArrayList<>();
        int number = 1;
        for (Authority a : Authority.values()) {
            String[] names = a.abilityNames();
            for (int i = 0; i < 7; i++, number++) {
                boolean ult = i == 6;
                int unlock = Math.min(7, a.baseUnlockStage() + (i >= 5 ? 1 : 0));
                String id = slug(names[i]);
                double[] ov = OVERRIDES.get(id);
                if (ov != null) {
                    out.add(new AbilityDef(id, names[i], a, number, i + 1, ov[0], ov[1], ov[2], ov[3], ov[4], (int) ov[5], ult));
                    continue;
                }
                out.add(new AbilityDef(id, names[i], a, number, i + 1,
                        ult ? 40 : 6 + i * 3,
                        ult ? 90 + a.ordinal() * 20 : 3 + i * 5,
                        15, 5 + i, 0, unlock, ult));
            }
        }
        return out;
    }

    public AbilityDef get(String id) { return byId.get(id); }
    public Collection<AbilityDef> all() { return Collections.unmodifiableCollection(byNumber); }

    /** Accepts an id, a display name ("STEP BETWEEN") or a number (1-70). */
    public AbilityDef find(String query) {
        if (query == null || query.isBlank()) return null;
        String q = query.trim();
        if (q.chars().allMatch(Character::isDigit)) {
            try {
                int n = Integer.parseInt(q);
                return n >= 1 && n <= byNumber.size() ? byNumber.get(n - 1) : null;
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return byId.get(slug(q));
    }

    public List<AbilityDef> of(Authority a) {
        return byNumber.stream().filter(d -> d.authority() == a).toList();
    }
}
