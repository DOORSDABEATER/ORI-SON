package dev.des.orison.echo;

/** What ORISON has learned about one identity through defeating it. One per identity: no duplicates. */
public final class HuntRecord {
    public final String identity;
    public String displayName, entityType, mythicId, modelId;
    public double maxHealth, attackDamage, moveSpeed;
    public int kills;
    public long firstDefeat, lastDefeat;

    public HuntRecord(String identity) { this.identity = identity; }
}
