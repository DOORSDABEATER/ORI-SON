package dev.des.orison.quest;

/** key "*" matches any key. */
public record Objective(ObjectiveType type, String key, int required, String label) { }
