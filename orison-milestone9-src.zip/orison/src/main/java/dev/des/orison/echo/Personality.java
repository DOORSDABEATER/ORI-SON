package dev.des.orison.echo;

import java.util.Set;

/** aggroRange: how far it looks for targets. leash: how far from the owner it will chase. */
public enum Personality {
    AGGRESSIVE(20, 16), DEFENSIVE(8, 8), TACTICAL(14, 12), GUARDIAN(10, 5), INDEPENDENT(16, 20), SUPPORT(8, 7);

    private static final Set<String> RANGED = Set.of("skeleton", "stray", "bogged", "pillager", "blaze", "witch", "ghast", "breeze");

    public final int aggroRange;
    public final int leash;

    Personality(int aggroRange, int leash) {
        this.aggroRange = aggroRange;
        this.leash = leash;
    }

    /** Starting personality from the entity's nature. Unknown/modded entities default to AGGRESSIVE. */
    public static Personality defaultFor(String entityKey) {
        String k = entityKey == null ? "" : entityKey.toLowerCase();
        if (RANGED.contains(k)) return TACTICAL;
        if (k.equals("iron_golem") || k.equals("snow_golem") || k.equals("copper_golem")) return GUARDIAN;
        return AGGRESSIVE;
    }

    public static Personality parse(String s, Personality fallback) {
        if (s == null) return fallback;
        try { return valueOf(s.trim().toUpperCase()); } catch (IllegalArgumentException e) { return fallback; }
    }
}
