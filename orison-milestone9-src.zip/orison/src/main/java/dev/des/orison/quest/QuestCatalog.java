package dev.des.orison.quest;

import java.util.List;

/**
 * The built-in quests. Stage quests form a strict chain 1->2->...->7 (each requires the previous stage); side quests grant
 * titles. Counts are provisional balance values. Stage 7 and THE EXCEPTION are driven by story flags that the Azriel
 * encounter (Milestone 9) will set.
 */
public final class QuestCatalog {
    private QuestCatalog() { }

    private static Objective o(ObjectiveType t, String key, int n, String label) { return new Objective(t, key, n, label); }

    public static List<QuestDef> defaults() {
        return List.of(
            new QuestDef("first_anomaly", "THE FIRST ANOMALY",
                "Something about you is not being recorded correctly.", 1, 2, true, null, "stage_2", null,
                List.of(o(ObjectiveType.DEFEAT_HOSTILE, "*", 15, "Defeat hostile creatures"))),
            new QuestDef("unnatural_presence", "THE UNNATURAL PRESENCE",
                "The world has started to notice you.", 2, 3, false, null, "stage_3", null,
                List.of(o(ObjectiveType.ABILITY_USE, "*", 15, "Use your authorities"),
                        o(ObjectiveType.DEFEAT_HOSTILE, "*", 40, "Defeat hostile creatures"))),
            new QuestDef("recognized_sovereign", "THE RECOGNIZED SOVEREIGN",
                "Learn what it means to be absent, and to be refused.", 3, 4, false, null, "stage_4", null,
                List.of(o(ObjectiveType.ABILITY_USE, "step_between", 10, "Step between"),
                        o(ObjectiveType.ABILITY_USE, "unseen", 5, "Go unseen"),
                        o(ObjectiveType.DAMAGE_NEGATED, "*", 3, "Declare hits invalid"))),
            new QuestDef("beyond_the_known", "BEYOND THE KNOWN",
                "Take back what you have defeated.", 4, 5, false, null, "stage_5", null,
                List.of(o(ObjectiveType.ECHO_CLAIM, "*", 3, "Awaken Echoes"),
                        o(ObjectiveType.ECHO_KILL, "*", 25, "Defeats made by your Echoes"))),
            new QuestDef("impossible_authority", "THE IMPOSSIBLE AUTHORITY",
                "Command a legion, and wear your own manifestation.", 5, 6, false, null, "stage_6", null,
                List.of(o(ObjectiveType.ECHO_RANK, "*", 2, "Raise an Echo to REPLICA"),
                        o(ObjectiveType.TRANSFORM_USED, "*", 3, "Manifest"),
                        o(ObjectiveType.ABILITY_USE, "awaken_all", 3, "Awaken the Legion"))),
            new QuestDef("final_recognition", "ABSOLUTE RECOGNITION",
                "There is one thing left that was never recorded.", 6, 7, true, null, "stage_7", null,
                List.of(o(ObjectiveType.STORY, "azriel_phase4", 1, "Reach the final manifestation"))),
            new QuestDef("the_exception", "THE EXCEPTION",
                "Azriel could not be recorded. Perhaps that was the point.", 7, 0, true, "azriel_defeated", "the_exception", "mythic:azriel",
                List.of(o(ObjectiveType.STORY, "azriel_defeated", 1, "Resolve the Azriel Protocol"),
                        o(ObjectiveType.STORY, "exception_acknowledged", 1, "Acknowledge the irregularity"))),
            new QuestDef("legion_builder", "A LEGION OF RECORDS", "Ten identities, kept.", 4, 0, false, null, "legion_sovereign", null,
                List.of(o(ObjectiveType.ECHO_CLAIM, "*", 10, "Awaken Echoes"))),
            new QuestDef("unbroken", "THE UNBROKEN", "Twenty-five hits that never happened.", 4, 0, false, null, "unbroken", null,
                List.of(o(ObjectiveType.DAMAGE_NEGATED, "*", 25, "Declare hits invalid"))),
            new QuestDef("hunter", "HUNTER OF THE UNWRITTEN", "Two hundred defeats.", 2, 0, false, null, "hunter_unwritten", null,
                List.of(o(ObjectiveType.DEFEAT_HOSTILE, "*", 200, "Defeat hostile creatures")))
        );
    }
}
