package dev.des.orison.vfx;

import dev.des.orison.OrisonPlugin;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.world.EntitiesLoadEvent;

import java.util.HexFormat;
import java.util.UUID;

/** Tracks which clients loaded the pack, optionally sends it, and sweeps orphaned VFX displays. */
public final class VfxListener implements Listener {
    private static final UUID PACK_ID = UUID.nameUUIDFromBytes("orison-vfx-pack".getBytes());
    private final OrisonPlugin plugin;

    public VfxListener(OrisonPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        String url = plugin.getConfig().getString("resourcepack.url", "");
        String sha1 = plugin.getConfig().getString("resourcepack.sha1", "");
        if (url.isBlank()) return;
        try {
            byte[] hash = sha1.isBlank() ? null : HexFormat.of().parseHex(sha1.trim());
            boolean required = plugin.getConfig().getBoolean("resourcepack.required", false);
            e.getPlayer().setResourcePack(PACK_ID, url, hash, Component.text("ORISON visual effects"), required);
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("resourcepack.sha1 is not valid hex; not sending the pack.");
        }
    }

    @EventHandler
    public void onStatus(PlayerResourcePackStatusEvent e) {
        switch (e.getStatus()) {
            case SUCCESSFULLY_LOADED -> plugin.vfx().packLoaded(e.getPlayer().getUniqueId(), true);
            case DECLINED, FAILED_DOWNLOAD, FAILED_RELOAD, INVALID_URL ->
                    plugin.vfx().packLoaded(e.getPlayer().getUniqueId(), false);
            default -> { }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { plugin.vfx().packLoaded(e.getPlayer().getUniqueId(), false); }

    /** A VFX display loading from disk is always stale: it is non-persistent, so this only catches crash leftovers. */
    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (en instanceof ItemDisplay && plugin.vfx().isVfx(en)) en.remove();
        }
    }
}
