package dev.des.orison.ability.impl;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityResult;
import dev.des.orison.ability.Targets;
import dev.des.orison.transform.TransformRules;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** X.1 FIRST RECOGNITION / X.4 FRACTURED ASCENSION / X.6 ABSOLUTE MANIFESTATION / X.7 BEYOND EXISTENCE. */
public final class TransformAbility implements AbilityBehavior {
    private final OrisonPlugin plugin;
    private final int level;

    public TransformAbility(OrisonPlugin plugin, int level) {
        this.plugin = plugin;
        this.level = level;
    }

    @Override public String abilityId() { return TransformRules.ABILITY_IDS[level]; }

    @Override
    public AbilityResult execute(AbilityContext ctx) {
        if (plugin.progress().stage() < TransformRules.MIN_STAGE[level]) return AbilityResult.fail("You have not been recognised enough for this.");
        if (plugin.transform().level() > level) return AbilityResult.fail("A greater manifestation is already active.");
        boolean overdrive = ctx.combo() != null && level == 4;        // CONTRADICTION OVERDRIVE
        plugin.transform().start(ctx.caster(), level, ctx.def().duration() * (overdrive ? 1.5 : 1.0));
        if (overdrive) {
            Player p = ctx.caster();
            plugin.paradox().gain(30);
            for (LivingEntity e : p.getWorld().getNearbyLivingEntities(p.getLocation(), 10)) {
                if (e instanceof Enemy && Targets.canAffect(plugin, p, e)) e.damage(15.0, p);   // normal damage events: protection can veto
            }
            if (plugin.vfx().usable(p)) {
                plugin.vfxLib().shock(p.getLocation(), 10f, 18);
                plugin.vfxLib().ring(p.getLocation(), 6f, 20);
            }
        }
        return AbilityResult.ok(TransformRules.name(level));
    }
}
