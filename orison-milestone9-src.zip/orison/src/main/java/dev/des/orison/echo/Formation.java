package dev.des.orison.echo;

public enum Formation { VEIL, HUNT, WALL, EXECUTION, SCATTER, SOVEREIGN }
