package dev.des.orison.quest;

import java.util.List;

/**
 * @param minStage      the quest only counts progress while the owner's stage is at least this (no pre-farming)
 * @param grantStage    evolution stage granted on completion (0 = none)
 * @param hidden        hidden quests are shown as unknown until revealed
 * @param revealFlag    story flag that reveals it (null = none); it is also revealed by its first progress
 * @param unseals       Echo identity this quest unseals on completion (null = none)
 */
public record QuestDef(String id, String title, String description, int minStage, int grantStage,
                       boolean hidden, String revealFlag, String rewardTitle, String unseals,
                       List<Objective> objectives) { }
