package dev.des.orison.echo;

/** Rank, integrity and stat-scaling rules (pure, unit tested). */
public final class EchoMath {
    private EchoMath() { }

    /** TRACE, FRAGMENT, REPLICA, RECONSTITUTED, SOVEREIGN, ABSOLUTE. Both XP and integrity must qualify. */
    public static final long[] RANK_XP = {0, 100, 400, 1200, 3500, 10000};
    public static final int[] RANK_INTEGRITY = {0, 25, 50, 75, 90, 100};

    public static int rankIndex(long xp, int integrity) {
        int r = 0;
        for (int i = 0; i < RANK_XP.length; i++) {
            if (xp >= RANK_XP[i] && integrity >= RANK_INTEGRITY[i]) r = i;
        }
        return r;
    }

    /**
     * How faithfully the record has been reconstructed. Capped at 99 unless a perfect record was made
     * (PERFECT RECORD / admin), which is the only way to reach COMPLETE.
     */
    public static int integrity(int kills, boolean hasModel, boolean hasMythicIdentity, int reinforcements, boolean perfect) {
        if (perfect) return 100;
        int v = 20 + Math.min(40, Math.max(0, kills) * 10) + (hasModel ? 15 : 0) + (hasMythicIdentity ? 10 : 0)
                + Math.max(0, reinforcements) * 5;
        return Math.min(99, v);
    }

    /** Multiplier applied to the original entity's health and damage. Never exceeds 1.1. */
    public static double statScale(int rankIndex, int integrity) {
        int r = Math.max(0, Math.min(5, rankIndex));
        double i = Math.max(0, Math.min(100, integrity)) / 100.0;
        return 0.35 + 0.1 * r + 0.25 * i;
    }

    public static long xpForKill(double victimMaxHealth) {
        return 1 + (long) (Math.max(0, victimMaxHealth) / 10.0);
    }
}
