package dev.des.orison.ability.impl;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityEngine;
import dev.des.orison.ability.AbilityResult;
import dev.des.orison.ability.Blink;
import dev.des.orison.ability.Targeting;
import dev.des.orison.domain.DomainType;
import dev.des.orison.echo.OrderType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Abilities that feed the combos and domains. Damage always goes through normal damage events (so protection plugins can
 * veto it), nothing here changes blocks, and every lasting effect is a status or a tracked task with cleanup.
 * ctx.combo() is non-null when this cast completes a combo.
 */
public final class AdvancedAbilities {
    private AdvancedAbilities() { }

    public static void registerAll(OrisonPlugin plugin, AbilityEngine engine) {
        engine.register(new MissingFrame(plugin));
        engine.register(new NotToday(plugin));
        engine.register(new FutureFracture(plugin));
        engine.register(new ReturnToSender(plugin));
        engine.register(new DebtCollector(plugin));
        engine.register(new EverythingComesBack(plugin));
        engine.register(new CollapseTheDistance(plugin));
        engine.register(new NothingRemains(plugin));
        engine.register(new OmissionForm(plugin));
        engine.register(new HuntMark(plugin));
        engine.register(new SovereignCommand(plugin));
        engine.register(new OneAuthority(plugin));
        engine.register(new DomainAbility(plugin, DomainType.KINGDOM_OF_NOTHING));
        engine.register(new DomainAbility(plugin, DomainType.THE_STILL_WORLD));
    }

    private static long ticks(AbilityContext c, double factor) { return Math.max(1L, (long) (c.def().duration() * 20 * factor)); }

    private static double reach(AbilityContext c) { return c.def().range() * c.plugin().transform().rangeMultiplier(); }

    // ---------------------------------------------------------------- I. ABSENCE

    /** I.5 MISSING FRAME - skip a frame: a short horizontal dash with a moment of immunity. */
    static final class MissingFrame implements AbilityBehavior {
        private final OrisonPlugin plugin;
        MissingFrame(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "missing_frame"; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            Player p = ctx.caster();
            boolean combo = ctx.combo() != null;
            Vector dir = p.getEyeLocation().getDirection().setY(0);
            if (dir.lengthSquared() < 1e-4) {
                double yaw = Math.toRadians(p.getLocation().getYaw());
                dir = new Vector(-Math.sin(yaw), 0, Math.cos(yaw));
            }
            Location from = p.getLocation();
            Location dest = Blink.along(p, dir, reach(ctx) * (combo ? 1.5 : 1.0), 1.0);
            if (dest == null) return AbilityResult.fail("No room to skip.");
            p.teleport(dest);
            plugin.presence().abilityMove(p, from, dest);
            plugin.statuses().start(p, "invulnerable", ticks(ctx, combo ? 2 : 1), () -> { });
            return AbilityResult.ok("MISSING FRAME");
        }
    }

    // ---------------------------------------------------------------- II. DENIAL

    /** II.5 NOT TODAY - refuse a lethal hit once, within the armed window. Handled in StatusListener. */
    static final class NotToday implements AbilityBehavior {
        private final OrisonPlugin plugin;
        NotToday(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "not_today"; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            plugin.combat().notTodayEnhanced = ctx.combo() != null;
            plugin.statuses().start(ctx.caster(), "not_today", ticks(ctx, 1), () -> plugin.combat().notTodayEnhanced = false);
            if (plugin.vfx().usable(ctx.caster())) plugin.vfxLib().ring(ctx.caster().getLocation(), 1.4f, 14);
            return AbilityResult.ok("NOT TODAY");
        }
    }

    // ---------------------------------------------------------------- IX. PERCEPTION

    /** IX.6 FUTURE FRACTURE - see hits before they land: incoming damage is halved while active. */
    static final class FutureFracture implements AbilityBehavior {
        private final OrisonPlugin plugin;
        FutureFracture(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "future_fracture"; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            plugin.statuses().start(ctx.caster(), "future_fracture", ticks(ctx, 1), () -> { });
            if (plugin.vfx().usable(ctx.caster())) plugin.vfxLib().gate(ctx.caster().getLocation(), ctx.caster().getLocation().getYaw(), 0.9f, 14);
            return AbilityResult.ok("FUTURE FRACTURE");
        }
    }

    /** IX.3 HUNT MARK - mark a target; defeating it makes it easier to claim with AWAKEN. */
    static final class HuntMark implements AbilityBehavior {
        private final OrisonPlugin plugin;
        HuntMark(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "hunt_mark"; }
        @Override public Targeting targeting() { return Targeting.ENTITY; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            plugin.combat().mark(ctx.target(), (int) ticks(ctx, 1));
            return AbilityResult.ok("HUNT MARK");
        }
    }

    // ---------------------------------------------------------------- IV. RECKONING

    /** IV.2 RETURN TO SENDER - the next hit is sent back (owner takes half). Handled in StatusListener. */
    static final class ReturnToSender implements AbilityBehavior {
        private final OrisonPlugin plugin;
        ReturnToSender(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "return_to_sender"; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            plugin.combat().returnPerfect = ctx.combo() != null;
            plugin.statuses().start(ctx.caster(), "return_to_sender", ticks(ctx, 1), () -> plugin.combat().returnPerfect = false);
            return AbilityResult.ok("RETURN TO SENDER");
        }
    }

    /** IV.1 DEBT COLLECTOR - open a ledger on a target: damage you take is recorded as its debt. */
    static final class DebtCollector implements AbilityBehavior {
        private final OrisonPlugin plugin;
        DebtCollector(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "debt_collector"; }
        @Override public Targeting targeting() { return Targeting.ENTITY; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            plugin.combat().debtTarget = ctx.target().getUniqueId();
            plugin.combat().debtLedger = 0;
            plugin.statuses().start(ctx.caster(), "debt", ticks(ctx, 1), () -> {
                plugin.combat().debtTarget = null;
                plugin.combat().debtLedger = 0;
            });
            if (plugin.vfx().usable(ctx.caster())) plugin.vfxLib().ring(ctx.target().getLocation(), 1.3f, 24);
            return AbilityResult.ok("DEBT COLLECTOR");
        }
    }

    /** IV.6 EVERYTHING COMES BACK - the ledger is paid in full, capped by the ability's damage value. */
    static final class EverythingComesBack implements AbilityBehavior {
        private final OrisonPlugin plugin;
        EverythingComesBack(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "everything_comes_back"; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            Player p = ctx.caster();
            var combat = plugin.combat();
            if (combat.debtTarget == null) return AbilityResult.fail("Nothing is owed.");
            Entity e = Bukkit.getEntity(combat.debtTarget);
            if (!(e instanceof LivingEntity t) || !t.isValid() || t.isDead()) return AbilityResult.fail("The debtor is gone.");
            if (t.getWorld() != p.getWorld() || t.getLocation().distance(p.getLocation()) > Math.max(10, reach(ctx))) return AbilityResult.fail("The debtor is out of reach.");
            double mult = ctx.combo() != null ? 1.5 : 1.0;
            double amount = Math.min(ctx.def().damage() * mult, combat.debtLedger * mult);
            if (amount < 1) return AbilityResult.fail("The ledger is empty.");
            t.damage(amount, p);
            combat.debtLedger = 0;
            plugin.statuses().end(p.getUniqueId(), "debt");
            if (plugin.vfx().usable(p)) {
                plugin.vfxLib().shock(t.getLocation(), 2.8f, 12);
                plugin.vfxLib().cut(t.getLocation().add(-1, 1, 0), t.getLocation().add(1, 1.4, 0), 8);
            }
            return AbilityResult.ok("EVERYTHING COMES BACK");
        }
    }

    /** IV.4 COLLAPSE THE DISTANCE - there is no distance between you and the target. */
    static final class CollapseTheDistance implements AbilityBehavior {
        private final OrisonPlugin plugin;
        CollapseTheDistance(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "collapse_the_distance"; }
        @Override public Targeting targeting() { return Targeting.ENTITY; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            Player p = ctx.caster();
            Location spot = Blink.adjacent(p, ctx.target());
            if (spot == null) return AbilityResult.fail("No safe place beside it.");
            Location from = p.getLocation();
            p.teleport(spot);
            plugin.presence().abilityMove(p, from, spot);
            return AbilityResult.ok("COLLAPSE THE DISTANCE");
        }
    }

    // ---------------------------------------------------------------- III. OMISSION

    /** III.7 NOTHING REMAINS - a single removal strike; stronger against the wounded, doubled in ERASURE. */
    static final class NothingRemains implements AbilityBehavior {
        private final OrisonPlugin plugin;
        NothingRemains(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "nothing_remains"; }
        @Override public Targeting targeting() { return Targeting.ENTITY; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            LivingEntity t = ctx.target();
            double hp = t.getHealth() / Math.max(1.0, t.getMaxHealth());
            double amount = ctx.def().damage() * (ctx.combo() != null ? 2.0 : 1.0) * (1.0 + 0.5 * (1.0 - hp));
            t.damage(amount, ctx.caster());
            if (plugin.vfx().usable(ctx.caster())) {
                plugin.vfxLib().rift(t.getLocation(), ctx.caster().getLocation().getYaw(), 2.4f, 20);
                plugin.vfxLib().shock(t.getLocation(), 2.0f, 10);
            }
            return AbilityResult.ok("NOTHING REMAINS");
        }
    }

    /** III.6 OMISSION: FORM - the target's form is omitted: it cannot act and is slowed and weakened. */
    static final class OmissionForm implements AbilityBehavior {
        private final OrisonPlugin plugin;
        OmissionForm(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "omission_form"; }
        @Override public Targeting targeting() { return Targeting.ENTITY; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            Player p = ctx.caster();
            LivingEntity t = ctx.target();
            boolean combo = ctx.combo() != null;
            if (combo) {
                Location behind = Blink.behind(t);
                if (behind != null) {
                    Location from = p.getLocation();
                    p.teleport(behind);
                    plugin.presence().abilityMove(p, from, behind);
                }
                t.damage(6.0, p);
            }
            plugin.combat().formless(t, (int) ticks(ctx, combo ? 1.5 : 1.0));
            if (plugin.vfx().usable(p)) plugin.vfxLib().rift(t.getLocation(), p.getLocation().getYaw() + 90f, 2.2f, 30);
            return AbilityResult.ok("OMISSION: FORM");
        }
    }

    // ---------------------------------------------------------------- VII / VIII. Legion

    /** VII.6 SOVEREIGN COMMAND - every active Echo is ordered onto one target and empowered. */
    static final class SovereignCommand implements AbilityBehavior {
        private final OrisonPlugin plugin;
        SovereignCommand(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "sovereign_command"; }
        @Override public Targeting targeting() { return Targeting.ENTITY; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            var ids = plugin.echo().activeIds();
            if (ids.isEmpty()) return AbilityResult.fail("No Echo is active.");
            plugin.echo().order(ids, OrderType.FOCUS, ctx.target());
            int t = (int) ticks(ctx, 1);
            plugin.echo().forEachActive(m -> m.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, t, 0, false, false, false)));
            plugin.combat().sovereignTarget = ctx.target().getUniqueId();
            plugin.combat().sovereignUntil = System.currentTimeMillis() + 15_000;
            return AbilityResult.ok("SOVEREIGN COMMAND");
        }
    }

    /** VIII.7 ONE AUTHORITY - the Legion acts as one: resistant and tight; after SOVEREIGN COMMAND it converges on the target. */
    static final class OneAuthority implements AbilityBehavior {
        private final OrisonPlugin plugin;
        OneAuthority(OrisonPlugin p) { plugin = p; }
        @Override public String abilityId() { return "one_authority"; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            var ids = plugin.echo().activeIds();
            if (ids.isEmpty()) return AbilityResult.fail("No Echo is active.");
            boolean combo = ctx.combo() != null;
            int t = (int) ticks(ctx, 1);
            LivingEntity target = null;
            if (combo && plugin.combat().sovereignTarget != null && System.currentTimeMillis() < plugin.combat().sovereignUntil
                    && Bukkit.getEntity(plugin.combat().sovereignTarget) instanceof LivingEntity le && le.isValid() && !le.isDead()) target = le;

            List<Mob> mobs = new ArrayList<>();
            plugin.echo().forEachActive(mobs::add);
            for (int i = 0; i < mobs.size(); i++) {
                Mob m = mobs.get(i);
                m.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, t, combo ? 1 : 0, false, false, false));
                if (combo) {
                    m.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, t, 1, false, false, false));
                    m.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, t, 1, false, false, false));
                    if (target != null) {
                        double a = Math.PI * 2 * i / mobs.size();
                        Location around = target.getLocation().clone().add(Math.cos(a) * 2.0, 0, Math.sin(a) * 2.0);
                        if (Blink.safe(around)) m.teleport(around);
                    }
                }
            }
            plugin.echo().order(ids, target != null ? OrderType.FOCUS : OrderType.PROTECT, target);
            return AbilityResult.ok("ONE AUTHORITY");
        }
    }

    // ---------------------------------------------------------------- V / IV. Domains

    /** KINGDOM OF NOTHING (V.7) and THE STILL WORLD (V.2). */
    static final class DomainAbility implements AbilityBehavior {
        private final OrisonPlugin plugin;
        private final DomainType type;
        DomainAbility(OrisonPlugin p, DomainType t) { plugin = p; type = t; }
        @Override public String abilityId() { return type.abilityId; }

        @Override public AbilityResult execute(AbilityContext ctx) {
            if (plugin.domains().active()) return AbilityResult.fail("A domain is already open.");
            boolean ok = plugin.domains().start(ctx.caster(), type, ctx.def().range(), ctx.def().duration());
            return ok ? AbilityResult.ok(type.title) : AbilityResult.fail("A domain cannot open here.");
        }
    }
}
