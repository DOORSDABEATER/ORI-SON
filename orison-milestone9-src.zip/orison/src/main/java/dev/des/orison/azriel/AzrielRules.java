package dev.des.orison.azriel;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Pure Azriel Protocol rules (unit tested). Azriel's own health bar is never rewritten; phases are enforced by clamping
 * incoming damage to a per-phase health floor, so no phase can be skipped by raw damage.
 */
public final class AzrielRules {
    private AzrielRules() { }

    /** Health fraction Azriel cannot be damaged below while in this phase. */
    public static double floorFraction(Phase p) {
        return switch (p) {
            case RECOGNITION_FAILURE -> 0.75;
            case AUTHORITY_CONFLICT, IMPOSSIBLE_RECORD -> 0.45;
            case THE_THING_THAT_NEVER_WAS -> 0.20;
            case FINAL_OMISSION -> 0.0;
        };
    }

    /** Phase to resume at when the owner (re)engages a boss at this health. phase4Reached: the final recognition already happened. */
    public static Phase initialPhase(double fraction, boolean phase4Reached) {
        if (fraction > 0.75) return Phase.RECOGNITION_FAILURE;
        if (fraction > 0.45) return Phase.AUTHORITY_CONFLICT;
        if (!phase4Reached) return Phase.IMPOSSIBLE_RECORD;
        return fraction > 0.20 ? Phase.THE_THING_THAT_NEVER_WAS : Phase.FINAL_OMISSION;
    }

    /** Damage actually allowed so health never ends below the phase floor. Phase III is fully invulnerable. */
    public static double allowedDamage(double health, double maxHealth, double damage, Phase p) {
        if (p == Phase.IMPOSSIBLE_RECORD) return 0.0;
        double floorHealth = floorFraction(p) * maxHealth;
        return Math.max(0.0, Math.min(damage, health - floorHealth));
    }

    /** True when this hit leaves Azriel at (or within a hair of) the phase floor, so the phase should advance. */
    public static boolean reachesFloor(double health, double maxHealth, double damage, Phase p) {
        if (p == Phase.FINAL_OMISSION || p == Phase.IMPOSSIBLE_RECORD) return false;
        return health - damage <= floorFraction(p) * maxHealth + 1e-6;
    }

    /** Fraction of damage Azriel's answer absorbs in phase II. Combos break it; the Legion wears it down; it never vanishes on its own. */
    public static double shieldReduction(int echoesNearby, boolean broken) {
        if (broken) return 0.0;
        return Math.max(0.30, 0.90 - 0.15 * Math.max(0, echoesNearby));
    }

    private static final Set<String> UNREADABLE = Set.of("perception", "omission", "nonexistence");

    /** Phase I: authorities that cannot read or omit Azriel always fail; everything else is sometimes resisted. */
    public static boolean resistedInPhaseOne(String authorityKey, double roll) {
        return UNREADABLE.contains(authorityKey) || roll < 0.25;
    }

    /** Phase II: Azriel answers an authority that is leaned on too hard. */
    public static final class Adaptation {
        private final long windowMillis;
        private final int limit;
        private final Map<String, Deque<Long>> uses = new HashMap<>();

        public Adaptation(long windowMillis, int limit) {
            this.windowMillis = windowMillis;
            this.limit = limit;
        }

        /** Records a non-combo cast; returns true if Azriel has already answered this authority (the cast is countered). */
        public boolean shouldCounter(String authorityKey, long now) {
            Deque<Long> d = uses.computeIfAbsent(authorityKey, k -> new ArrayDeque<>());
            while (!d.isEmpty() && now - d.peekFirst() > windowMillis) d.pollFirst();
            if (d.size() >= limit) return true;
            d.addLast(now);
            return false;
        }

        public void clear() { uses.clear(); }
    }
}
