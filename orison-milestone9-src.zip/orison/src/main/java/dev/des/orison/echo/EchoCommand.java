package dev.des.orison.echo;

import dev.des.orison.OrisonPlugin;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** /orison echo ... (owner) and /orison admin echo|awaken ... (admin). Indexes refer to /orison echo list. */
public final class EchoCommand {
    private static final int PAGE = 8;
    private final OrisonPlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public EchoCommand(OrisonPlugin plugin) { this.plugin = plugin; }

    private void send(CommandSender to, String s) { to.sendMessage(mm.deserialize(s)); }
    private String esc(String s) { return mm.escapeTags(s == null ? "" : s); }

    // ---------------------------------------------------------------- owner

    public void owner(Player p, String[] args) {
        String sub = args.length < 2 ? "list" : args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> list(p, args.length >= 3 ? parse(args[2], 1) : 1);
            case "inspect" -> withEcho(p, args, 2, r -> inspect(p, r));
            case "summon" -> withEcho(p, args, 2, r -> {
                EchoService.SummonResult s = plugin.echo().summon(r);
                send(p, s.ok() ? "<gray>" + esc(r.label()) + " emerges." : "<red>" + esc(r.label()) + ": " + esc(s.message()) + ".");
            });
            case "recall" -> recall(p, args);
            case "rename" -> rename(p, args);
            case "favourite", "favorite" -> withEcho(p, args, 2, r -> {
                r.favourite = !r.favourite;
                plugin.echoRepo().saveEcho(r);
                send(p, "<gray>" + esc(r.label()) + (r.favourite ? " is now a favourite." : " is no longer a favourite."));
            });
            case "order" -> order(p, args);
            case "formation" -> formation(p, args);
            case "group" -> group(p, args);
            case "hunts" -> hunts(p);
            default -> send(p, "<gray>/orison echo <white>list|inspect|summon|recall|rename|favourite|order|formation|group|hunts");
        }
    }

    private int parse(String s, int def) { try { return Integer.parseInt(s); } catch (NumberFormatException e) { return def; } }

    private EchoRecord byIndex(String tok) {
        int i = parse(tok, -1);
        List<EchoRecord> l = plugin.echoRepo().sorted();
        return i >= 1 && i <= l.size() ? l.get(i - 1) : null;
    }

    private void withEcho(Player p, String[] args, int idx, java.util.function.Consumer<EchoRecord> fn) {
        if (args.length <= idx) { send(p, "<gray>Give the number from /orison echo list."); return; }
        EchoRecord r = byIndex(args[idx]);
        if (r == null) { send(p, "<red>No Echo with that number."); return; }
        fn.accept(r);
    }

    private void list(Player p, int page) {
        List<EchoRecord> all = plugin.echoRepo().sorted();
        if (all.isEmpty()) { send(p, "<gray>No Echoes yet. Defeat something, then say AWAKEN."); return; }
        int pages = (all.size() + PAGE - 1) / PAGE;
        page = Math.max(1, Math.min(pages, page));
        send(p, "<white><b>LEGION</b> <gray>" + all.size() + " stored, " + plugin.echo().activeCount() + "/"
                + plugin.settings().echoActiveLimit() + " active <dark_gray>page " + page + "/" + pages);
        long now = System.currentTimeMillis();
        for (int i = (page - 1) * PAGE; i < Math.min(all.size(), page * PAGE); i++) {
            EchoRecord r = all.get(i);
            String state = plugin.echo().isActive(r.id) ? "<green>active"
                    : r.downedUntil > now ? "<red>reforming " + ((r.downedUntil - now) / 1000) + "s" : "<dark_gray>stored";
            send(p, "<gray>" + (i + 1) + ". " + (r.favourite ? "<yellow>* " : "") + "<white>" + esc(r.label())
                    + " <dark_gray>[" + r.rank() + "] <gray>" + r.integrity + "% " + r.band().label().toLowerCase(Locale.ROOT) + " " + state);
        }
    }

    private void inspect(Player p, EchoRecord r) {
        send(p, "<white><b>" + esc(r.label()) + "</b> <dark_gray>(" + esc(r.displayName) + ", " + esc(r.identity) + ")");
        send(p, "<gray>Rank <white>" + r.rank() + " <gray>XP <white>" + r.xp + " <gray>Integrity <white>" + r.integrity + "% "
                + r.band().label() + " <gray>Personality <white>" + r.personality);
        send(p, "<gray>Health <white>" + (int) r.maxHealth + " <gray>Damage <white>" + String.format(Locale.ROOT, "%.1f", r.attackDamage)
                + " <gray>Model <white>" + (r.modelId == null ? "none" : esc(r.modelId)) + " <gray>Group <white>" + r.group
                + " <gray>Reinforced <white>" + r.reinforcements + "x");
        long total = plugin.echoRepo().hunt(r.identity).map(h -> (long) h.kills).orElse(0L);
        send(p, "<gray>Defeats recorded <white>" + total + (plugin.echo().isActive(r.id) ? " <gray>Order <white>" + plugin.echo().orderOf(r.id) : ""));
    }

    private void recall(Player p, String[] args) {
        if (args.length < 3) { send(p, "<gray>Usage: /orison echo recall <number|all>"); return; }
        if (args[2].equalsIgnoreCase("all")) {
            int n = plugin.echo().activeCount();
            plugin.echo().recallAll(true);
            send(p, "<gray>Recalled " + n + " Echo(es).");
            return;
        }
        withEcho(p, args, 2, r -> {
            if (!plugin.echo().isActive(r.id)) { send(p, "<gray>" + esc(r.label()) + " is not active."); return; }
            plugin.echo().recall(r.id, true);
            send(p, "<gray>" + esc(r.label()) + " recalled.");
        });
    }

    private void rename(Player p, String[] args) {
        if (args.length < 4) { send(p, "<gray>Usage: /orison echo rename <number> <new name>"); return; }
        EchoRecord r = byIndex(args[2]);
        if (r == null) { send(p, "<red>No Echo with that number."); return; }
        String name = String.join(" ", Arrays.copyOfRange(args, 3, args.length)).trim();
        if (name.length() < 1 || name.length() > 24) { send(p, "<red>Names must be 1-24 characters."); return; }
        r.nickname = name;
        plugin.echoRepo().saveEcho(r);
        send(p, "<gray>Renamed to <white>" + esc(name) + "<gray>. The original identity is kept (" + esc(r.displayName) + ").");
    }

    private List<UUID> targets(String tok) {
        List<UUID> out = new ArrayList<>();
        if (tok.equalsIgnoreCase("all")) return new ArrayList<>(plugin.echo().activeIds());
        if (tok.toLowerCase(Locale.ROOT).startsWith("g") && tok.length() > 1) {
            int g = parse(tok.substring(1), -1);
            for (UUID id : plugin.echo().activeIds()) { EchoRecord r = plugin.echoRepo().echo(id); if (r != null && r.group == g) out.add(id); }
            return out;
        }
        EchoRecord r = byIndex(tok);
        if (r != null && plugin.echo().isActive(r.id)) out.add(r.id);
        return out;
    }

    private void order(Player p, String[] args) {
        if (args.length < 4) { send(p, "<gray>Usage: /orison echo order <number|all|gN> <" + orderNames() + ">"); return; }
        OrderType type;
        try { type = OrderType.valueOf(args[3].toUpperCase(Locale.ROOT)); }
        catch (IllegalArgumentException e) { send(p, "<red>Orders: " + orderNames()); return; }
        LivingEntity focus = null;
        if (type == OrderType.FOCUS) {
            RayTraceResult r = p.getWorld().rayTraceEntities(p.getEyeLocation(), p.getEyeLocation().getDirection(), 30, 0.3,
                    e -> e != p && e instanceof LivingEntity && !plugin.echo().isEchoEntity(e));
            if (r == null || !(r.getHitEntity() instanceof LivingEntity le)) { send(p, "<gray>Look at the target to focus."); return; }
            focus = le;
        }
        int n = plugin.echo().order(targets(args[2]), type, focus);
        send(p, n == 0 ? "<gray>No matching active Echo." : "<gray>" + n + " Echo(es): <white>" + type);
    }

    private String orderNames() {
        return String.join("|", Arrays.stream(OrderType.values()).map(o -> o.name().toLowerCase(Locale.ROOT)).toList());
    }

    private void formation(Player p, String[] args) {
        if (args.length < 3) { send(p, "<gray>Formation: <white>" + plugin.echoRepo().formation()
                + " <gray>(" + String.join("|", Arrays.stream(Formation.values()).map(f -> f.name().toLowerCase(Locale.ROOT)).toList()) + ")"); return; }
        try {
            Formation f = Formation.valueOf(args[2].toUpperCase(Locale.ROOT));
            plugin.echoRepo().setFormation(f);
            send(p, "<gray>Formation: <white>" + f);
        } catch (IllegalArgumentException e) { send(p, "<red>Unknown formation."); }
    }

    private void group(Player p, String[] args) {
        if (args.length < 4) { send(p, "<gray>Usage: /orison echo group <number> <0-9>  (0 = none)"); return; }
        EchoRecord r = byIndex(args[2]);
        int g = parse(args[3], -1);
        if (r == null || g < 0 || g > 9) { send(p, "<red>Use a valid Echo number and a group from 0 to 9."); return; }
        r.group = g;
        plugin.echoRepo().saveEcho(r);
        send(p, "<gray>" + esc(r.label()) + " assigned to group <white>" + g + "<gray>.");
    }

    private void hunts(Player p) {
        List<HuntRecord> l = new ArrayList<>(plugin.echoRepo().hunts());
        l.sort((a, b) -> Integer.compare(b.kills, a.kills));
        if (l.isEmpty()) { send(p, "<gray>No hunts recorded yet."); return; }
        send(p, "<white><b>HUNT RECORDS</b> <gray>" + l.size());
        for (int i = 0; i < Math.min(10, l.size()); i++) {
            HuntRecord h = l.get(i);
            boolean echoed = plugin.echoRepo().findByIdentity(h.identity).isPresent();
            send(p, "<gray>" + esc(h.displayName) + " <dark_gray>x" + h.kills + (echoed ? " <green>echoed" : ""));
        }
    }

    // ---------------------------------------------------------------- admin

    /** args: [admin, echo, <sub>, ...] */
    public void admin(CommandSender sender, String[] args) {
        String sub = args.length < 3 ? "list" : args[2].toLowerCase(Locale.ROOT);
        String actor = sender instanceof Player pl ? pl.getName() + "(" + pl.getUniqueId() + ")" : "CONSOLE";
        switch (sub) {
            case "list" -> send(sender, "<gray>Hunt records: <white>" + plugin.echoRepo().hunts().size()
                    + " <gray>Echoes: <white>" + plugin.echoRepo().echoes().size() + " <gray>active: <white>" + plugin.echo().activeCount());
            case "testrecord" -> {
                if (!(sender instanceof Player p)) { send(sender, "<red>Players only."); return; }
                if (args.length < 4) { send(sender, "<gray>Usage: /orison admin echo testrecord <entity type> [defeats]"); return; }
                EntityType t = ClaimService.resolveType(args[3].toLowerCase(Locale.ROOT));
                if (t == null || t.getEntityClass() == null || !org.bukkit.entity.Mob.class.isAssignableFrom(t.getEntityClass())) {
                    send(sender, "<red>Not a claimable mob type."); return;
                }
                int kills = Math.max(1, Math.min(10, args.length >= 5 ? parse(args[4], 1) : 1));
                Pending pd = new Pending();
                pd.identity = "vanilla:" + args[3].toLowerCase(Locale.ROOT);
                pd.displayName = args[3];
                pd.entityType = args[3].toLowerCase(Locale.ROOT);
                pd.maxHealth = 20; pd.attackDamage = 3; pd.moveSpeed = 0.23;
                pd.location = p.getLocation();
                pd.expiresAt = System.currentTimeMillis() + plugin.getConfig().getInt("echo.claim-window-seconds", 45) * 1000L;
                plugin.echoRepo().recordDefeat(pd, kills);
                plugin.hunts().add(pd);
                plugin.audit().record(actor, "ECHO_TESTRECORD", pd.identity + " kills=" + kills);
                send(sender, "<gray>Test record created for <white>" + esc(pd.identity) + "<gray> (" + kills + " defeat(s)). Say AWAKEN or use /orison admin awaken.");
            }
            case "remove" -> {
                EchoRecord r = args.length >= 4 ? byIndex(args[3]) : null;
                if (r == null) { send(sender, "<red>Usage: /orison admin echo remove <number from /orison echo list>"); return; }
                plugin.echo().recall(r.id, false);
                plugin.echoRepo().deleteEcho(r.id);
                plugin.audit().record(actor, "ECHO_REMOVE", r.identity + " id=" + r.id);
                send(sender, "<gray>Removed Echo <white>" + esc(r.label()) + "<gray>.");
            }
            default -> send(sender, "<gray>Usage: /orison admin echo <list|testrecord|remove>");
        }
    }

    /** Force-claims the nearest pending defeat (skips odds and required defeats; seals and irregularity still apply). */
    public void adminAwaken(CommandSender sender) {
        if (!(sender instanceof Player p)) { send(sender, "<red>Players only."); return; }
        plugin.audit().record(p.getName() + "(" + p.getUniqueId() + ")", "ADMIN_AWAKEN", "forced claim");
        plugin.claims().claim(p, true);
    }
}
