package dev.des.orison.ability.impl;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityResult;
import dev.des.orison.echo.ClaimOutcome;
import dev.des.orison.echo.ClaimService;

/** VII.1 AWAKEN - claim the nearest recent defeat as an Echo. Cost is only charged when the claim is ACCEPTED. */
public final class AwakenAbility implements AbilityBehavior {
    private final OrisonPlugin plugin;

    public AwakenAbility(OrisonPlugin plugin) { this.plugin = plugin; }

    @Override public String abilityId() { return "awaken"; }

    @Override
    public AbilityResult execute(AbilityContext ctx) {
        ClaimService.ClaimResult r = plugin.claims().claim(ctx.caster(), false);
        return r.outcome() == ClaimOutcome.ACCEPTED ? AbilityResult.ok("AWAKEN") : AbilityResult.fail("AWAKEN: " + r.outcome());
    }
}
