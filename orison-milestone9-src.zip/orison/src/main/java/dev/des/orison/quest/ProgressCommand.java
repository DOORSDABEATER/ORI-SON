package dev.des.orison.quest;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityDef;
import dev.des.orison.ability.Authority;
import dev.des.orison.mastery.MasteryMath;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.Map;

/** Owner: /orison quests|mastery|titles|title|transform.  Admin: /orison admin quest ... */
public final class ProgressCommand {
    private final OrisonPlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public ProgressCommand(OrisonPlugin plugin) { this.plugin = plugin; }

    private void send(CommandSender to, String s) { to.sendMessage(mm.deserialize(s)); }
    private String esc(String s) { return mm.escapeTags(s); }

    public void owner(Player p, String[] args) {
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "quests" -> quests(p);
            case "combos" -> combos(p);
            case "mastery" -> mastery(p);
            case "titles" -> titles(p);
            case "title" -> {
                if (args.length < 2) { send(p, "<gray>Usage: /orison title <id>  (see /orison titles)"); return; }
                send(p, plugin.quests().selectTitle(args[1].toLowerCase(Locale.ROOT))
                        ? "<gray>Title set: <white>" + Titles.display(args[1].toLowerCase(Locale.ROOT)) : "<red>You do not have that title.");
            }
            case "transform" -> {
                if (args.length >= 2 && args[1].equalsIgnoreCase("cancel")) {
                    send(p, plugin.transform().cancel(p) ? "<gray>Manifestation ended." : "<gray>Nothing to end.");
                } else {
                    int l = plugin.transform().level();
                    send(p, "<gray>Manifestation: <white>" + dev.des.orison.transform.TransformRules.name(l)
                            + (plugin.transform().contradiction() ? " <gray>+ <white>CONTRADICTION" : "") + " <dark_gray>(/orison transform cancel)");
                }
            }
            default -> { }
        }
    }

    private void quests(Player p) {
        int stage = plugin.progress().stage();
        send(p, "<white><b>" + Stages.name(stage) + "</b> <dark_gray>- " + Stages.subtitle(stage) + " <gray>(stage " + stage + "/7)");
        int hidden = 0;
        for (QuestDef d : plugin.quests().defs().values()) {
            QuestService.State s = plugin.quests().state(d.id());
            if (!plugin.quests().revealed(d)) { hidden++; continue; }
            if (s.complete) { send(p, "<green>done <gray>" + esc(d.title())); continue; }
            if (!plugin.quests().active(d)) { send(p, "<dark_gray>locked (stage " + d.minStage() + ") " + esc(d.title())); continue; }
            send(p, "<white>" + esc(d.title()) + " <dark_gray>" + QuestLogic.totalDone(d, s.counters) + "/" + QuestLogic.totalRequired(d));
            for (int i = 0; i < d.objectives().size(); i++) {
                Objective o = d.objectives().get(i);
                send(p, "<gray>  - " + esc(o.label()) + " <dark_gray>" + s.counters[i] + "/" + o.required());
            }
        }
        if (hidden > 0) send(p, "<dark_gray>" + hidden + " hidden thread(s) not yet recorded.");
    }

    private void combos(Player p) {
        send(p, "<white><b>COMBINATIONS</b> <gray>" + plugin.combos().discoveredCount() + "/" + plugin.combos().defs().size() + " discovered");
        for (dev.des.orison.combo.ComboDef c : plugin.combos().defs()) {
            if (plugin.combos().discovered(c.id())) {
                send(p, "<white>" + c.name() + " <dark_gray>" + esc(plugin.registry().get(c.first()).name()) + " -> "
                        + esc(plugin.registry().get(c.second()).name()) + " (" + (int) c.windowSeconds() + "s)");
                send(p, "<gray>  " + esc(c.effect()));
            } else {
                send(p, "<dark_gray>??? <gray>" + esc(c.hint()));
            }
        }
    }

    /** args: [admin, combo, <sub>, <id|all>] */
    public void adminCombo(CommandSender sender, String[] args) {
        String actor = sender instanceof Player pl ? pl.getName() + "(" + pl.getUniqueId() + ")" : "CONSOLE";
        String sub = args.length < 3 ? "list" : args[2].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                for (dev.des.orison.combo.ComboDef c : plugin.combos().defs()) {
                    send(sender, "<gray>" + c.id() + " <dark_gray>" + (plugin.combos().discovered(c.id()) ? "discovered" : "undiscovered")
                            + " " + c.first() + " -> " + c.second());
                }
            }
            case "unlock" -> send(sender, args.length >= 4 && plugin.combos().adminUnlock(args[3].toLowerCase(Locale.ROOT), actor)
                    ? "<gray>Combo(s) unlocked (audit-logged)." : "<red>Usage: /orison admin combo unlock <id|all>");
            case "reset" -> send(sender, args.length >= 4 && plugin.combos().adminReset(args[3].toLowerCase(Locale.ROOT), actor)
                    ? "<gray>Combo(s) reset." : "<red>Usage: /orison admin combo reset <id|all>");
            default -> send(sender, "<gray>Usage: /orison admin combo <list|unlock|reset>");
        }
    }

    private void mastery(Player p) {
        send(p, "<white><b>MASTERY</b>");
        for (Authority a : Authority.values()) {
            int sum = 0, used = 0;
            for (AbilityDef d : plugin.registry().of(a)) { int l = plugin.mastery().level(d.id()); sum += l; if (plugin.mastery().uses(d.id()) > 0) used++; }
            if (used == 0) continue;
            send(p, "<gray>" + a.roman() + " " + a.title().toUpperCase(Locale.ROOT) + " <dark_gray>level " + sum + "/35");
            for (AbilityDef d : plugin.registry().of(a)) {
                int uses = plugin.mastery().uses(d.id());
                if (uses == 0) continue;
                int next = MasteryMath.toNext(uses);
                send(p, "<gray>  " + d.name() + " <white>L" + MasteryMath.level(uses) + " <dark_gray>" + uses + " uses"
                        + (next < 0 ? " (max)" : ", " + next + " to next"));
            }
        }
    }

    private void titles(Player p) {
        send(p, "<white><b>TITLES</b>");
        for (Map.Entry<String, String> e : Titles.all().entrySet()) {
            boolean has = plugin.quests().titles().contains(e.getKey());
            String sel = e.getKey().equals(plugin.quests().selectedTitle()) ? " <yellow>(selected)" : "";
            send(p, (has ? "<white>" : "<dark_gray>") + e.getValue() + " <dark_gray>" + e.getKey() + sel);
        }
    }

    // ---------------------------------------------------------------- admin

    /** args: [admin, quest, <sub>, ...] */
    public void admin(CommandSender sender, String[] args) {
        String actor = sender instanceof Player pl ? pl.getName() + "(" + pl.getUniqueId() + ")" : "CONSOLE";
        String sub = args.length < 3 ? "list" : args[2].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                for (QuestDef d : plugin.quests().defs().values()) {
                    QuestService.State s = plugin.quests().state(d.id());
                    send(sender, "<gray>" + d.id() + " <dark_gray>" + (s.complete ? "COMPLETE" : plugin.quests().active(d) ? "ACTIVE" : "locked")
                            + " " + QuestLogic.totalDone(d, s.counters) + "/" + QuestLogic.totalRequired(d));
                }
                send(sender, "<dark_gray>story flags: " + esc(String.join(", ", plugin.quests().storyFlags())));
            }
            case "complete" -> send(sender, args.length >= 4 && plugin.quests().forceComplete(args[3].toLowerCase(Locale.ROOT), actor)
                    ? "<gray>Quest completed (audit-logged)." : "<red>Usage: /orison admin quest complete <id>");
            case "reset" -> send(sender, args.length >= 4 && plugin.quests().reset(args[3].toLowerCase(Locale.ROOT), actor)
                    ? "<gray>Quest reset." : "<red>Usage: /orison admin quest reset <id>");
            case "story" -> {
                if (args.length < 4) { send(sender, "<gray>Usage: /orison admin quest story <flag>"); return; }
                plugin.quests().setStory(args[3].toLowerCase(Locale.ROOT), actor);
                send(sender, "<gray>Story flag set: <white>" + esc(args[3].toLowerCase(Locale.ROOT)));
            }
            default -> send(sender, "<gray>Usage: /orison admin quest <list|complete|reset|story>");
        }
    }
}
