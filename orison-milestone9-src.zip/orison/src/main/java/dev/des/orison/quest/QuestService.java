package dev.des.orison.quest;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.persistence.AuditLog;
import dev.des.orison.persistence.Database;
import dev.des.orison.persistence.Tx;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Quest state, story flags and titles for the owner. Progress counts only while a quest is active (the owner has
 * reached its minimum stage), so nothing can be pre-farmed. Completing a stage quest advances the evolution stage;
 * there is deliberately no single command or XP counter that unlocks everything (admin tools are audit-logged).
 * Main thread only; persistence is batched.
 */
public final class QuestService {

    public static final class State {
        public final int[] counters;
        public boolean complete;
        boolean dirty;
        long lastNotify;
        State(int n) { counters = new int[n]; }
    }

    private final OrisonPlugin plugin;
    private final Database db;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Map<String, QuestDef> defs = new LinkedHashMap<>();
    private final Map<String, State> states = new HashMap<>();
    private final Set<String> story = new HashSet<>();
    private final Set<String> titles = new HashSet<>();
    private String selectedTitle;

    public QuestService(OrisonPlugin plugin) {
        this.plugin = plugin;
        this.db = plugin.database();
        for (QuestDef d : QuestCatalog.defaults()) {
            defs.put(d.id(), d);
            states.put(d.id(), new State(d.objectives().size()));
        }
    }

    // ------------------------------------------------------------------ persistence

    public void loadBlocking() {
        db.callBlocking(c -> {
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT quest_id, complete, counters FROM quest_progress")) {
                while (rs.next()) {
                    State st = states.get(rs.getString(1));
                    if (st == null) continue;
                    st.complete = rs.getInt(2) != 0;
                    String[] parts = rs.getString(3).isEmpty() ? new String[0] : rs.getString(3).split(",");
                    for (int i = 0; i < Math.min(parts.length, st.counters.length); i++) {
                        try { st.counters[i] = Integer.parseInt(parts[i].trim()); } catch (NumberFormatException ignored) { }
                    }
                }
            }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT flag FROM story_flag")) {
                while (rs.next()) story.add(rs.getString(1));
            }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT id, selected FROM owner_title")) {
                while (rs.next()) {
                    titles.add(rs.getString(1));
                    if (rs.getInt(2) != 0) selectedTitle = rs.getString(1);
                }
            }
            return null;
        });
    }

    private record Row(String id, boolean complete, String counters) { }

    private List<Row> drainDirty() {
        List<Row> rows = new ArrayList<>();
        for (Map.Entry<String, State> e : states.entrySet()) {
            State s = e.getValue();
            if (!s.dirty) continue;
            s.dirty = false;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.counters.length; i++) sb.append(i == 0 ? "" : ",").append(s.counters[i]);
            rows.add(new Row(e.getKey(), s.complete, sb.toString()));
        }
        return rows;
    }

    private static void writeRows(java.sql.Connection c, List<Row> rows) throws java.sql.SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT OR REPLACE INTO quest_progress (quest_id, complete, counters, updated_at) VALUES (?,?,?,?)")) {
            for (Row r : rows) {
                ps.setString(1, r.id());
                ps.setInt(2, r.complete() ? 1 : 0);
                ps.setString(3, r.counters());
                ps.setLong(4, System.currentTimeMillis());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    public void flushAsync() {
        List<Row> rows = drainDirty();
        if (rows.isEmpty()) return;
        db.submit(c -> { writeRows(c, rows); return null; });
    }

    public void flushBlocking() {
        List<Row> rows = drainDirty();
        if (rows.isEmpty()) return;
        db.callBlocking(c -> { writeRows(c, rows); return null; });
    }

    // ------------------------------------------------------------------ queries

    public Map<String, QuestDef> defs() { return defs; }
    public State state(String id) { return states.get(id); }
    public boolean isComplete(String id) { State s = states.get(id); return s != null && s.complete; }
    public boolean hasStory(String flag) { return story.contains(flag); }
    public Set<String> storyFlags() { return story; }
    public Set<String> titles() { return titles; }
    public String selectedTitle() { return selectedTitle; }

    private Player owner() {
        return plugin.owners().owner().map(Bukkit::getPlayer).orElse(null);
    }

    public boolean active(QuestDef d) {
        State s = states.get(d.id());
        return QuestLogic.isActive(d, plugin.progress().stage(), s.complete);
    }

    public boolean revealed(QuestDef d) {
        State s = states.get(d.id());
        return QuestLogic.isRevealed(d, s.counters, s.complete, story);
    }

    // ------------------------------------------------------------------ events

    public void event(ObjectiveType type, String key, int amount) {
        if (plugin.owners().owner().isEmpty()) return;
        for (QuestDef d : new ArrayList<>(defs.values())) {
            State s = states.get(d.id());
            if (!QuestLogic.isActive(d, plugin.progress().stage(), s.complete)) continue;
            boolean wasRevealed = QuestLogic.isRevealed(d, s.counters, s.complete, story);
            if (!QuestLogic.apply(d, s.counters, type, key, amount)) continue;
            s.dirty = true;
            Player o = owner();
            if (QuestLogic.isComplete(d, s.counters)) { complete(d, s, "PROGRESS"); continue; }
            if (o == null) continue;
            if (!wasRevealed && QuestLogic.isRevealed(d, s.counters, false, story)) {
                o.sendMessage(mm.deserialize("<dark_gray>Something has begun to be recorded about you..."));
            }
            long now = System.currentTimeMillis();
            if (now - s.lastNotify > 1500) {
                s.lastNotify = now;
                o.sendActionBar(mm.deserialize("<dark_gray>" + mm.escapeTags(d.hidden() && !revealed(d) ? "???" : d.title())
                        + " <gray>" + QuestLogic.totalDone(d, s.counters) + "/" + QuestLogic.totalRequired(d)));
            }
        }
    }

    /** Story beats (Azriel protocol etc.). Persisted, then offered to quests as STORY events. */
    public void setStory(String flag, String actor) {
        if (!story.add(flag)) return;
        db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO story_flag (flag, set_at) VALUES (?, ?)")) {
                ps.setString(1, flag);
                ps.setLong(2, System.currentTimeMillis());
                ps.executeUpdate();
            }
            return null;
        });
        plugin.audit().record(actor, "STORY_FLAG", flag);
        event(ObjectiveType.STORY, flag, 1);
    }

    private void complete(QuestDef d, State s, String actor) {
        if (s.complete) return;
        s.complete = true;
        s.dirty = true;
        for (int i = 0; i < s.counters.length; i++) s.counters[i] = d.objectives().get(i).required();
        flushAsync();
        plugin.audit().record(actor, "QUEST_COMPLETE", d.id());
        Player o = owner();
        if (o != null) {
            o.sendMessage(mm.deserialize("<white>QUEST COMPLETE <dark_gray>| <gray>" + mm.escapeTags(d.title())));
            plugin.audio().to(o, "ui.quest_complete", dev.des.orison.audio.AudioService.Kind.UI, 1.0f);
        }
        if (d.rewardTitle() != null) grantTitle(d.rewardTitle());
        if (d.unseals() != null) setStory("unsealed:" + d.unseals(), "QUEST:" + d.id());
        if (d.grantStage() > plugin.progress().stage()) {
            int target = d.grantStage();
            plugin.progress().setStage(target, "QUEST:" + d.id()).whenComplete((v, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
                if (err != null) { plugin.getLogger().severe("Could not advance stage: " + err); return; }
                syncTitles();
                announceStage(target);
            }));
        }
    }

    private void announceStage(int stage) {
        Player o = owner();
        if (o == null) return;
        o.showTitle(Title.title(Component.text(Stages.name(stage)), Component.text(Stages.subtitle(stage)),
                Title.Times.times(Duration.ofMillis(500), Duration.ofMillis(3000), Duration.ofMillis(1000))));
        plugin.vfxOverlay().vignette(o, 10, 40, 30);
        plugin.audio().to(o, "ui.stage_up", dev.des.orison.audio.AudioService.Kind.UI, 1.0f);
    }

    // ------------------------------------------------------------------ titles

    /** Grants every stage title up to the current stage (also covers admin-set stages). */
    public void syncTitles() {
        for (int s = 1; s <= plugin.progress().stage(); s++) grantTitle("stage_" + s);
    }

    public void grantTitle(String id) {
        if (!Titles.exists(id) || !titles.add(id)) return;
        db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO owner_title (id, unlocked_at, selected) VALUES (?, ?, 0)")) {
                ps.setString(1, id);
                ps.setLong(2, System.currentTimeMillis());
                ps.executeUpdate();
            }
            return null;
        });
        Player o = owner();
        if (o != null && !id.equals("stage_1")) {
            o.sendMessage(mm.deserialize("<gold>TITLE UNLOCKED <dark_gray>| <white>" + Titles.display(id)));
            plugin.audio().to(o, "ui.title_unlock", dev.des.orison.audio.AudioService.Kind.UI, 1.0f);
        }
    }

    public boolean selectTitle(String id) {
        if (!titles.contains(id)) return false;
        selectedTitle = id;
        db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("UPDATE owner_title SET selected = CASE WHEN id = ? THEN 1 ELSE 0 END")) {
                ps.setString(1, id);
                ps.executeUpdate();
            }
            return null;
        });
        return true;
    }

    // ------------------------------------------------------------------ admin

    public boolean forceComplete(String id, String actor) {
        QuestDef d = defs.get(id);
        if (d == null) return false;
        complete(d, states.get(id), actor);
        return true;
    }

    public boolean reset(String id, String actor) {
        QuestDef d = defs.get(id);
        if (d == null) return false;
        State s = states.get(id);
        java.util.Arrays.fill(s.counters, 0);
        s.complete = false;
        s.dirty = true;
        plugin.audit().record(actor, "QUEST_RESET", id);
        flushAsync();
        return true;
    }
}
