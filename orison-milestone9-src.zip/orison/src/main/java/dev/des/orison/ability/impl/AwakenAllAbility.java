package dev.des.orison.ability.impl;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityResult;
import dev.des.orison.echo.EchoRecord;
import org.bukkit.entity.Mob;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** VII.4 AWAKEN: ALL - summon every ready Echo, up to the active capacity (+4 and empowered in KINGDOM LEGION). */
public final class AwakenAllAbility implements AbilityBehavior {
    private final OrisonPlugin plugin;

    public AwakenAllAbility(OrisonPlugin plugin) { this.plugin = plugin; }

    @Override public String abilityId() { return "awaken_all"; }

    @Override
    public AbilityResult execute(AbilityContext ctx) {
        boolean combo = ctx.combo() != null;
        int extra = combo ? 4 : 0;
        long now = System.currentTimeMillis();
        int n = 0;
        for (EchoRecord r : plugin.echoRepo().sorted()) {
            if (plugin.echo().activeCount() >= plugin.settings().echoActiveLimit() + extra) break;
            if (plugin.echo().isActive(r.id) || r.downedUntil > now) continue;
            if (plugin.echo().summon(r, extra).ok()) {
                n++;
                if (combo) {
                    Mob m = plugin.echo().mobOf(r.id);
                    if (m != null) m.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 20 * 30, 1, false, false, false));
                }
            }
        }
        return n > 0 ? AbilityResult.ok("AWAKEN: ALL x" + n) : AbilityResult.fail("No Echo could be summoned.");
    }
}
