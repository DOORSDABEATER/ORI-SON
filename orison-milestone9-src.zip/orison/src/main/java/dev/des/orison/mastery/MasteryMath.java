package dev.des.orison.mastery;

/** Ability mastery (pure). Uses -> level 0-5; mastery makes abilities cheaper and quicker, never free. */
public final class MasteryMath {
    private MasteryMath() { }

    public static final int[] THRESHOLDS = {0, 10, 30, 75, 150, 300};
    public static final int MAX_LEVEL = 5;

    public static int level(int uses) {
        int l = 0;
        for (int i = 0; i < THRESHOLDS.length; i++) if (uses >= THRESHOLDS[i]) l = i;
        return l;
    }

    /** Uses still needed for the next level, or -1 at max. */
    public static int toNext(int uses) {
        int l = level(uses);
        return l >= MAX_LEVEL ? -1 : THRESHOLDS[l + 1] - uses;
    }

    public static double costFactor(int level) { return 1.0 - 0.03 * Math.max(0, Math.min(MAX_LEVEL, level)); }       // down to 0.85
    public static double cooldownFactor(int level) { return 1.0 - 0.04 * Math.max(0, Math.min(MAX_LEVEL, level)); }   // down to 0.80
}
