package dev.des.orison.ability;

public enum Targeting { SELF, ENTITY }
