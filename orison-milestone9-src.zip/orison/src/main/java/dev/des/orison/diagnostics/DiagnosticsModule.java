package dev.des.orison.diagnostics;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.core.OrisonModule;

public final class DiagnosticsModule implements OrisonModule {
    private final OrisonPlugin plugin;

    public DiagnosticsModule(OrisonPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "diagnostics"; }

    @Override
    public void enable() {
        plugin.getLogger().info("--- ORISON compatibility report ---");
        plugin.compat().lines().forEach(l -> plugin.getLogger().info(l));
        plugin.getLogger().info("Database schema v" + plugin.database().schemaVersion());
    }

    @Override public void disable() { }
}
