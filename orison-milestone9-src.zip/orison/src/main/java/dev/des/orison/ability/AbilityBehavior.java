package dev.des.orison.ability;

/**
 * The gameplay of one ability. Runs on the main thread. Return fail() to abort without spending
 * PARADOX or starting the cooldown; any state started here must be registered with the StatusManager
 * so it is cleaned up on expiry, death, logout and shutdown.
 */
public interface AbilityBehavior {
    String abilityId();
    default Targeting targeting() { return Targeting.SELF; }
    AbilityResult execute(AbilityContext ctx);
}
