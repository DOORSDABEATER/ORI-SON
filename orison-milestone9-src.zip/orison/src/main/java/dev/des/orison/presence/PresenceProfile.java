package dev.des.orison.presence;

/**
 * What ORISON looks like at a given evolution stage + transformation. Pure data (unit tested).
 * Transformations raise the effective stage floor, so they upgrade every facet at once.
 *
 * trailTier: 0 none, 1 Absence Trail, 2 Sovereign Trail, 3 Unwritten Trail, 4 Beyond Existence Trail.
 */
public record PresenceProfile(
        int effectiveStage,
        int transformLevel,
        int trailTier,
        int eyeLevel,
        int fragmentCount,
        int fragmentPoints,
        int outlineLevel,
        double flickerChance,
        int afterimageDelayTicks,
        int afterimageCount,
        double distortion,
        double intensityMultiplier) {

    private static final int[] TRAIL = {0, 1, 1, 2, 3, 3, 4};
    private static final int[] EYE = {0, 1, 1, 2, 2, 3, 3};
    private static final int[] FRAGMENTS = {0, 0, 2, 3, 4, 5, 6};
    private static final int[] OUTLINE = {0, 0, 1, 2, 3, 4, 5};
    private static final double[] FLICKER = {0.02, 0.05, 0.08, 0.12, 0.15, 0.18, 0.22};
    private static final int[] AFTER_DELAY = {0, 0, 0, 0, 6, 5, 3};
    private static final int[] AFTER_COUNT = {0, 0, 0, 0, 1, 1, 2};
    private static final double[] DISTORTION = {0.05, 0.10, 0.20, 0.35, 0.55, 0.75, 1.00};

    // Transformation I..IV: minimum effective stage, extra fragments, intensity multiplier.
    private static final int[] TRANSFORM_MIN_STAGE = {0, 4, 5, 6, 7};
    private static final int[] TRANSFORM_FRAGMENTS = {0, 0, 1, 2, 3};
    private static final double[] TRANSFORM_INTENSITY = {1.0, 1.1, 1.25, 1.4, 1.6};

    public static PresenceProfile forStage(int stage, int transformLevel) {
        int t = Math.max(0, Math.min(4, transformLevel));
        int s = Math.max(1, Math.min(7, stage));
        s = Math.max(s, TRANSFORM_MIN_STAGE[t]);
        int i = s - 1;

        int points = s >= 7 ? 4 : s >= 5 ? 3 : 2;   // shard -> triangle -> diamond
        if (t >= 3) points = 6;                      // octahedron
        else if (t == 2) points = Math.max(points, 4);

        return new PresenceProfile(s, t, TRAIL[i], EYE[i], FRAGMENTS[i] + TRANSFORM_FRAGMENTS[t], points,
                OUTLINE[i], FLICKER[i], AFTER_DELAY[i], AFTER_COUNT[i], DISTORTION[i], TRANSFORM_INTENSITY[t]);
    }
}
