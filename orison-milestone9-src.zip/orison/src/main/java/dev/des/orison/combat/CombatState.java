package dev.des.orison.combat;

import dev.des.orison.OrisonPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Short-lived combat flags and per-target effects for the advanced abilities. Anything that changes a mob's behaviour (formless)
 * is tracked so it is restored on expiry and on shutdown. Main thread only.
 */
public final class CombatState {
    private final OrisonPlugin plugin;

    public boolean returnPerfect;
    public boolean notTodayEnhanced;
    public UUID debtTarget;
    public double debtLedger;
    public UUID sovereignTarget;
    public long sovereignUntil;
    private UUID markTarget;
    private long markUntil;
    private final Map<UUID, BukkitTask> formless = new HashMap<>();

    public CombatState(OrisonPlugin plugin) { this.plugin = plugin; }

    // ---- HUNT MARK
    public void mark(LivingEntity target, int ticks) {
        markTarget = target.getUniqueId();
        markUntil = System.currentTimeMillis() + ticks * 50L;
        UUID id = markTarget;
        long until = markUntil;
        var owner = plugin.owners().owner().map(Bukkit::getPlayer).orElse(null);
        if (owner != null && plugin.vfx().usable(owner)) {
            // a floating shard above the target; the display removes itself when this supplier returns null
            plugin.vfxLib().shard(dev.des.orison.vfx.VfxModel.SHARD_C, () -> {
                Entity e = Bukkit.getEntity(id);
                if (e == null || !e.isValid() || System.currentTimeMillis() > until || !id.equals(markTarget)) return null;
                Location l = e.getLocation();
                return l.add(0, (e instanceof LivingEntity le ? le.getEyeHeight() : 1.0) + 0.7, 0);
            }, 0.45f, null);
        }
    }

    public boolean marked(Entity e) {
        return e != null && e.getUniqueId().equals(markTarget) && System.currentTimeMillis() < markUntil;
    }

    // ---- OMISSION: FORM
    public void formless(LivingEntity target, int ticks) {
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, 3, false, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, ticks, 1, false, false, false));
        if (!(target instanceof Mob m)) return;
        UUID id = m.getUniqueId();
        BukkitTask old = formless.remove(id);
        if (old != null) old.cancel();
        m.setAware(false);
        formless.put(id, Bukkit.getScheduler().runTaskLater(plugin, () -> {
            formless.remove(id);
            if (Bukkit.getEntity(id) instanceof Mob again && again.isValid()) again.setAware(true);
        }, ticks));
    }

    /** Restore every formless mob and clear all flags. Safe to call repeatedly. */
    public void shutdown() {
        for (Map.Entry<UUID, BukkitTask> e : formless.entrySet()) {
            e.getValue().cancel();
            if (Bukkit.getEntity(e.getKey()) instanceof Mob m && m.isValid()) m.setAware(true);
        }
        formless.clear();
        returnPerfect = false;
        notTodayEnhanced = false;
        debtTarget = null;
        debtLedger = 0;
        markTarget = null;
        sovereignTarget = null;
    }
}
