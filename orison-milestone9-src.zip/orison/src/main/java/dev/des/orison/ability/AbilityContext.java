package dev.des.orison.ability;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.combo.ComboDef;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** target is non-null only for {@link Targeting#ENTITY} abilities; combo is non-null when this cast completes a combination. */
public record AbilityContext(OrisonPlugin plugin, Player caster, AbilityDef def, LivingEntity target, ComboDef combo) { }
