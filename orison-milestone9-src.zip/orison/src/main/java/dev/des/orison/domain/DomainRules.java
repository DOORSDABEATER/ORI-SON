package dev.des.orison.domain;

/** Domain gameplay modifiers (pure). Apply only to the owner while standing inside the domain. */
public final class DomainRules {
    private DomainRules() { }

    public static final double KINGDOM_COOLDOWN = 0.7;
    public static final double KINGDOM_CLAIM_CHANCE_BONUS = 0.15;
    public static final double KINGDOM_CLAIM_WINDOW = 2.0;
    public static final double KINGDOM_PARADOX_PER_DEFEAT = 2.0;
    public static final int KINGDOM_SLOW_AMPLIFIER = 1;
    public static final int STILL_SLOW_AMPLIFIER = 5;

    public static double cooldownMultiplier(DomainType t, boolean ownerInside) {
        return t == DomainType.KINGDOM_OF_NOTHING && ownerInside ? KINGDOM_COOLDOWN : 1.0;
    }

    public static double claimChanceBonus(DomainType t, boolean ownerInside) {
        return t == DomainType.KINGDOM_OF_NOTHING && ownerInside ? KINGDOM_CLAIM_CHANCE_BONUS : 0.0;
    }

    public static double paradoxPerDefeat(DomainType t, boolean ownerInside) {
        return t == DomainType.KINGDOM_OF_NOTHING && ownerInside ? KINGDOM_PARADOX_PER_DEFEAT : 0.0;
    }

    /** Squared-distance containment test on a sphere. */
    public static boolean inside(double cx, double cy, double cz, double x, double y, double z, double radius) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        return dx * dx + dy * dy + dz * dz <= radius * radius;
    }

    /** Domain duration is kept within the configured sane window (20-45s by default). */
    public static double clampDuration(double seconds, double min, double max) { return Math.max(min, Math.min(max, seconds)); }
}
