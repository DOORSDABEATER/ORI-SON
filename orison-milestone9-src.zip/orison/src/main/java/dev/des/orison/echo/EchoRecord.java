package dev.des.orison.echo;

import java.util.UUID;

/** A persistent Echo. The id is stable; entity UUIDs are never used as identity. */
public final class EchoRecord {
    public final UUID id;
    public final String identity;
    public String displayName;
    public String nickname;
    public String entityType;
    public String mythicId;
    public String modelId;
    public String role;
    public double maxHealth, attackDamage, moveSpeed;
    public int integrity;
    public long xp;
    public Personality personality = Personality.AGGRESSIVE;
    public boolean favourite;
    public int group;
    public int reinforcements;
    public long claimedAt;
    public long downedUntil;

    public EchoRecord(UUID id, String identity) {
        this.id = id;
        this.identity = identity;
    }

    public Rank rank() { return Rank.fromIndex(EchoMath.rankIndex(xp, integrity)); }
    public IntegrityBand band() { return IntegrityBand.of(integrity); }
    public String label() { return nickname != null && !nickname.isBlank() ? nickname : displayName; }
}
