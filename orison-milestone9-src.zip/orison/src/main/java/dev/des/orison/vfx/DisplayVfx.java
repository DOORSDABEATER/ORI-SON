package dev.des.orison.vfx;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.logging.Level;

/**
 * Non-particle VFX: short-lived ItemDisplay entities that render custom 3D models from the resource pack.
 *
 * Guard rails: a hard cap on live displays, a per-second spawn cap, every display is non-persistent and
 * tagged so orphans are swept on start/stop/chunk load, and each display is hidden from players whose
 * client has not loaded the pack (they would otherwise see a missing-model cube). Main thread only.
 */
public final class DisplayVfx {

    public record Keyframe(int atTick, Transformation transform, int duration) { }

    /** Everything needed to spawn one visual. */
    public static final class Spec {
        final VfxModel model;
        final Location loc;
        Transformation start = new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(1, 1, 1), new AxisAngle4f());
        int life = 20;                 // <= 0 means persistent until kill()
        final List<Keyframe> frames = new ArrayList<>();
        Supplier<Location> follow;
        boolean glow = true;
        Player hideFrom;
        float viewRange = 0.7f;
        float spinDegPerTick;
        Vector3f spinAxis = new Vector3f(0, 1, 0);
        Vector3f baseScale = new Vector3f(1, 1, 1);

        public Spec(VfxModel model, Location loc) { this.model = model; this.loc = loc; }
        public Spec start(Transformation t) { this.start = t; return this; }
        public Spec life(int ticks) { this.life = ticks; return this; }
        public Spec frame(int at, Transformation t, int duration) { frames.add(new Keyframe(at, t, duration)); return this; }
        public Spec follow(Supplier<Location> s) { this.follow = s; return this; }
        public Spec glow(boolean g) { this.glow = g; return this; }
        public Spec hideFrom(Player p) { this.hideFrom = p; return this; }
        public Spec viewRange(float v) { this.viewRange = v; return this; }
        public Spec spin(float degPerTick, Vector3f axis, Vector3f scale) {
            this.spinDegPerTick = degPerTick;
            this.spinAxis = new Vector3f(axis).normalize();
            this.baseScale = new Vector3f(scale);
            return this;
        }
    }

    public static final class Handle {
        private final ItemDisplay entity;
        private final Spec spec;
        private int age;
        private float angle;
        private boolean dead;

        private Handle(ItemDisplay entity, Spec spec) { this.entity = entity; this.spec = spec; }

        public void kill() { dead = true; }
        public boolean alive() { return !dead && entity.isValid(); }
    }

    private static final int SPIN_STEP = 4;

    private final Plugin plugin;
    private final NamespacedKey tag;
    private final EnumMap<VfxModel, ItemStack> items = new EnumMap<>(VfxModel.class);
    private final List<Handle> live = new ArrayList<>();
    private final Set<UUID> packLoaded = new HashSet<>();
    private BukkitTask task;
    private long tickCounter;
    private int spawnsThisSecond;
    private long lastErrorLog;

    private boolean enabled = true;
    private int maxLive = 40;
    private int maxPerSecond = 60;
    private boolean assumeInstalled;

    public DisplayVfx(Plugin plugin) {
        this.plugin = plugin;
        this.tag = new NamespacedKey(plugin, "vfx");
    }

    // ------------------------------------------------------------------ lifecycle

    public void start() {
        stop();
        loadConfig();
        for (World w : Bukkit.getWorlds()) purgeOrphans(w);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public void reload() {
        loadConfig();
    }

    private void loadConfig() {
        var c = plugin.getConfig();
        enabled = c.getBoolean("vfx.models.enabled", true);
        String mode = c.getString("performance.mode", "BALANCED").toUpperCase();
        int def = switch (mode) { case "LOW" -> 16; case "HIGH" -> 80; default -> 40; };
        int explicit = c.getInt("vfx.models.max-live", 0);
        maxLive = Math.max(4, Math.min(256, explicit > 0 ? explicit : def));
        maxPerSecond = Math.max(4, Math.min(400, c.getInt("vfx.models.max-spawns-per-second", 60)));
        assumeInstalled = c.getBoolean("resourcepack.assume-installed", false);
    }

    /** Removes every live display and stops the tick. Safe to call repeatedly. */
    public void stop() {
        if (task != null) { task.cancel(); task = null; }
        removeAll();
    }

    public void removeAll() {
        for (Handle h : live) if (h.entity.isValid()) h.entity.remove();
        live.clear();
    }

    /** Removes tagged displays that this manager is not tracking (left behind by a crash or an unloaded chunk). */
    public int purgeOrphans(World world) {
        int removed = 0;
        Set<UUID> tracked = new HashSet<>();
        for (Handle h : live) tracked.add(h.entity.getUniqueId());
        for (ItemDisplay d : world.getEntitiesByClass(ItemDisplay.class)) {
            if (isVfx(d) && !tracked.contains(d.getUniqueId())) { d.remove(); removed++; }
        }
        return removed;
    }

    public boolean isVfx(Entity e) { return e.getPersistentDataContainer().has(tag, PersistentDataType.BYTE); }

    // ------------------------------------------------------------------ resource-pack status

    public void packLoaded(UUID id, boolean loaded) {
        if (loaded) packLoaded.add(id); else packLoaded.remove(id);
    }

    public boolean hasPack(Player p) { return assumeInstalled || packLoaded.contains(p.getUniqueId()); }

    /** Should model VFX be used for this owner right now? Otherwise callers fall back to particles. */
    public boolean usable(Player owner) { return enabled && hasPack(owner) && live.size() < maxLive; }

    public int liveCount() { return live.size(); }
    public int maxLive() { return maxLive; }
    public boolean enabled() { return enabled; }

    // ------------------------------------------------------------------ spawning

    private ItemStack item(VfxModel m) {
        return items.computeIfAbsent(m, k -> {
            ItemStack s = new ItemStack(Material.PAPER);
            ItemMeta meta = s.getItemMeta();
            meta.setItemModel(k.key());
            s.setItemMeta(meta);
            return s;
        });
    }

    /** Returns null when disabled or capped; callers should then fall back to particles. */
    public Handle spawn(Spec s) {
        if (!enabled || s.loc.getWorld() == null) return null;
        if (live.size() >= maxLive || spawnsThisSecond >= maxPerSecond) return null;
        ItemDisplay d;
        try {
            d = s.loc.getWorld().spawn(s.loc, ItemDisplay.class, e -> configure(e, s));
        } catch (Throwable t) {
            logOnce("Could not spawn a VFX display", t);
            return null;
        }
        if (d == null || !d.isValid()) return null;
        spawnsThisSecond++;
        for (Player v : d.getWorld().getPlayers()) {
            if (!hasPack(v) || (s.hideFrom != null && v.equals(s.hideFrom))) v.hideEntity(plugin, d);
        }
        Handle h = new Handle(d, s);
        s.frames.sort((a, b) -> Integer.compare(a.atTick(), b.atTick()));
        live.add(h);
        return h;
    }

    private void configure(ItemDisplay e, Spec s) {
        e.setItemStack(item(s.model));
        e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
        e.setBillboard(Display.Billboard.FIXED);
        e.setTransformation(s.start);
        e.setInterpolationDuration(0);
        e.setTeleportDuration(s.follow != null ? 2 : 0);
        if (s.glow) e.setBrightness(new Display.Brightness(15, 15));
        e.setViewRange(s.viewRange);
        e.setShadowRadius(0f);
        e.setPersistent(false);
        e.setGravity(false);
        e.setInvulnerable(true);
        e.setSilent(true);
        e.getPersistentDataContainer().set(tag, PersistentDataType.BYTE, (byte) 1);
        if (s.loc.getYaw() != 0 || s.loc.getPitch() != 0) e.setRotation(s.loc.getYaw(), s.loc.getPitch());
    }

    // ------------------------------------------------------------------ tick

    private void tick() {
        tickCounter++;
        if (tickCounter % 20 == 0) spawnsThisSecond = 0;
        Iterator<Handle> it = live.iterator();
        while (it.hasNext()) {
            Handle h = it.next();
            try {
                if (!h.alive()) { if (h.entity.isValid()) h.entity.remove(); it.remove(); continue; }
                h.age++;
                Spec s = h.spec;
                if (s.follow != null) {
                    Location l = s.follow.get();
                    if (l == null) { h.entity.remove(); it.remove(); continue; }
                    h.entity.teleport(l);
                }
                for (Keyframe k : s.frames) {
                    if (k.atTick() == h.age) {
                        h.entity.setInterpolationDelay(0);
                        h.entity.setInterpolationDuration(Math.max(1, k.duration()));
                        h.entity.setTransformation(k.transform());
                    }
                }
                if (s.spinDegPerTick != 0 && h.age % SPIN_STEP == 0) {
                    h.angle += s.spinDegPerTick * SPIN_STEP;
                    h.entity.setInterpolationDelay(0);
                    h.entity.setInterpolationDuration(SPIN_STEP);
                    h.entity.setTransformation(new Transformation(new Vector3f(),
                            new AxisAngle4f((float) Math.toRadians(h.angle), s.spinAxis.x, s.spinAxis.y, s.spinAxis.z),
                            s.baseScale, new AxisAngle4f()));
                }
                if (s.life > 0 && h.age >= s.life) { h.entity.remove(); it.remove(); }
            } catch (Throwable t) {
                logOnce("VFX tick failed", t);
                try { h.entity.remove(); } catch (Throwable ignored) { }
                it.remove();
            }
        }
    }

    private void logOnce(String msg, Throwable t) {
        long now = System.currentTimeMillis();
        if (now - lastErrorLog > 30_000) {
            lastErrorLog = now;
            plugin.getLogger().log(Level.WARNING, msg + " (rate-limited log)", t);
        }
    }

    public Map<VfxModel, ItemStack> debugItems() { return items; }
}
