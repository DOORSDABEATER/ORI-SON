package dev.des.orison.echo;

import dev.des.orison.OrisonPlugin;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.Random;
import java.util.UUID;

/** AWAKEN: turns a recent defeat into (or reinforces) an Echo, with an explained outcome. */
public final class ClaimService {

    public record ClaimResult(ClaimOutcome outcome, String message, EchoRecord echo) { }

    private final OrisonPlugin plugin;
    private final Random rng = new Random();
    private final MiniMessage mm = MiniMessage.miniMessage();

    public ClaimService(OrisonPlugin plugin) { this.plugin = plugin; }

    private ConfigurationSection profile(String identity) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("echo.profiles");
        return s == null ? null : s.getConfigurationSection(identity);
    }

    public int requiredKillsFor(Pending p) {
        ConfigurationSection prof = profile(p.identity);
        if (prof != null && prof.contains("min-defeats")) return Math.max(1, prof.getInt("min-defeats"));
        return ClaimRules.requiredKills(p.maxHealth);
    }

    /** Resolves a stored entity key like "zombie" to a spawnable Mob type, or null. */
    public static EntityType resolveType(String key) {
        NamespacedKey nk = NamespacedKey.minecraft(key == null ? "" : key);
        return Registry.ENTITY_TYPE.get(nk);
    }

    /** @param force admin test claim: skips the odds and the defeat requirement, never the seals or irregularity checks */
    public ClaimResult claim(Player owner, boolean force) {
        double range = plugin.getConfig().getDouble("echo.claim-range", 20);
        Pending p = plugin.hunts().nearest(owner.getLocation(), range);
        int stage = plugin.progress().stage();

        ClaimResult azriel = plugin.azriel().interceptClaim(owner);
        if (azriel != null) return done(owner, azriel);

        if (p == null) {
            return done(owner, new ClaimResult(ClaimOutcome.UNRECOGNIZED,
                    "Nothing has been defeated nearby that ORISON can record.", null));
        }

        if (p.identity.equals(dev.des.orison.azriel.AzrielService.IDENTITY)) plugin.azriel().beforeAzrielClaim(owner);
        boolean special = p.identity.equals(dev.des.orison.azriel.AzrielService.IDENTITY) && plugin.quests().hasStory("unsealed:" + p.identity);
        String sealedReason = null;
        if (plugin.getConfig().getStringList("echo.sealed").contains(p.identity) && !plugin.quests().hasStory("unsealed:" + p.identity)) {
            sealedReason = "This identity is sealed. It cannot be recorded until its story is resolved.";
        } else {
            int min = plugin.getConfig().getInt("echo.restricted-stage." + p.entityType, 0);
            if (min > stage) sealedReason = "Sealed until recognition stage " + min + ".";
        }
        EntityType type = resolveType(p.entityType);
        boolean irregular = p.irregular;
        String irregularReason = p.irregularReason;
        if (!irregular && (type == null || type.getEntityClass() == null
                || !org.bukkit.entity.Mob.class.isAssignableFrom(type.getEntityClass()) || !type.isSpawnable())) {
            irregular = true;
            irregularReason = "Its form cannot be reconstructed as a living Echo.";
        }

        ConfigurationSection prof = profile(p.identity);
        double base = (prof != null ? prof.getDouble("base-chance", 0.6) : 0.6) + (p.marked ? 0.25 : 0.0) + plugin.domains().claimBonus(owner);
        int kills = plugin.echoRepo().hunt(p.identity).map(h -> h.kills).orElse(0);
        int required = force || special ? 0 : Math.max(1, requiredKillsFor(p) - (p.marked ? 1 : 0));
        if (special) base = 1.0;
        boolean existing = plugin.echoRepo().findByIdentity(p.identity).isPresent();

        ClaimRules.Context ctx = new ClaimRules.Context(false, "", irregular, irregularReason,
                sealedReason != null, sealedReason == null ? "" : sealedReason,
                kills, required, existing, p.attempts, stage, base);
        ClaimRules.Decision d = ClaimRules.decide(ctx, force ? 0.0 : rng.nextDouble());

        switch (d.outcome()) {
            case ACCEPTED -> {
                EchoRecord r = existing ? reinforce(p, force) : create(p, prof, kills, force);
                if (!existing) plugin.quests().event(dev.des.orison.quest.ObjectiveType.ECHO_CLAIM, p.identity, 1);
                plugin.hunts().remove(p);
                String text = (existing ? "Record reinforced: " : "Awakened: ") + r.label() + " - "
                        + r.rank() + ", " + r.band().label() + " " + r.integrity + "%";
                String extra = "";
                if (plugin.getConfig().getBoolean("echo.auto-summon-on-claim", true)) {
                    EchoService.SummonResult sr = plugin.echo().summon(r);
                    extra = sr.ok() ? "" : " (not summoned: " + sr.message() + ")";
                }
                return done(owner, new ClaimResult(ClaimOutcome.ACCEPTED, text + extra, r));
            }
            case RESISTED -> {
                p.attempts++;
                return done(owner, new ClaimResult(ClaimOutcome.RESISTED, p.displayName + ": " + d.reason(), null));
            }
            default -> {
                return done(owner, new ClaimResult(d.outcome(), p.displayName + ": " + d.reason(), null));
            }
        }
    }

    private EchoRecord create(Pending p, ConfigurationSection prof, int kills, boolean perfect) {
        EchoRecord r = new EchoRecord(UUID.randomUUID(), p.identity);
        r.displayName = p.displayName;
        r.entityType = p.entityType;
        r.mythicId = p.mythicId;
        r.modelId = p.modelId;
        r.maxHealth = p.maxHealth;
        r.attackDamage = p.attackDamage;
        r.moveSpeed = p.moveSpeed;
        r.personality = prof != null ? Personality.parse(prof.getString("personality"), Personality.defaultFor(p.entityType))
                : Personality.defaultFor(p.entityType);
        r.claimedAt = System.currentTimeMillis();
        r.integrity = EchoMath.integrity(Math.max(1, kills), p.modelId != null, p.mythicId != null, 0, false);
        if (p.identity.equals(dev.des.orison.azriel.AzrielService.IDENTITY)) {   // THE EXCEPTION: a complete record that was never supposed to exist
            r.integrity = 100;
            r.role = "THE EXCEPTION";
            r.personality = Personality.INDEPENDENT;
        }
        plugin.echoRepo().putEcho(r);
        return r;
    }

    private EchoRecord reinforce(Pending p, boolean perfect) {
        EchoRecord r = plugin.echoRepo().findByIdentity(p.identity).orElseThrow();
        r.reinforcements++;
        int kills = plugin.echoRepo().hunt(p.identity).map(h -> h.kills).orElse(1);
        if (r.integrity < 100) r.integrity = EchoMath.integrity(kills, r.modelId != null, r.mythicId != null, r.reinforcements, false);
        plugin.echoRepo().saveEcho(r);
        return r;
    }

    private ClaimResult done(Player owner, ClaimResult r) {
        String color = switch (r.outcome()) {
            case ACCEPTED -> "<green>";
            case RESISTED -> "<yellow>";
            case INCOMPLETE -> "<gold>";
            case UNRECOGNIZED -> "<gray>";
            case SEALED -> "<aqua>";
            case IRREGULAR -> "<red>";
        };
        plugin.audio().claim(owner, r.outcome().name());
        owner.sendMessage(mm.deserialize("<white>AWAKEN <dark_gray>| " + color + r.outcome() + " <gray>" + mm.escapeTags(r.message())));
        return r;
    }
}
