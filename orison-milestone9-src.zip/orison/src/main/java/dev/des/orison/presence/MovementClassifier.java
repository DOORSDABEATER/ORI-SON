package dev.des.orison.presence;

/**
 * Pure movement-state classification (no Bukkit types, unit tested).
 * Vanilla has no "run" state, so RUNNING means grounded, non-sprinting movement faster than normal
 * walking (speed effects, ice, downhill momentum).
 */
public final class MovementClassifier {
    private MovementClassifier() { }

    public static final double MOVING_SPEED = 0.3;      // blocks/second
    public static final double RUNNING_SPEED = 4.8;     // blocks/second, non-sprint
    public static final double SPRINT_MIN_SPEED = 2.0;  // sprint flag with no motion is not sprinting
    public static final double JUMP_RISE = 0.2;         // blocks gained between samples while leaving the ground
    public static final double FALL_DROP = -0.08;       // blocks lost between samples

    public record Input(boolean sneaking, boolean sprinting, boolean onGround, boolean wasOnGround,
                        double horizontalSpeed, double verticalDelta,
                        boolean abilityMovement, boolean transforming, boolean wasAirborne) { }

    public static MovementState classify(Input in) {
        if (in.transforming()) return MovementState.TRANSFORMATION;
        if (in.abilityMovement()) return MovementState.ABILITY_MOVEMENT;
        if (!in.onGround()) {
            if (in.wasOnGround() && in.verticalDelta() > JUMP_RISE) return MovementState.JUMPING;
            return in.verticalDelta() < FALL_DROP ? MovementState.FALLING : MovementState.JUMPING;
        }
        if (in.wasAirborne()) return MovementState.LANDING;
        if (in.sneaking()) return MovementState.SNEAKING;
        if (in.sprinting() && in.horizontalSpeed() > SPRINT_MIN_SPEED) return MovementState.SPRINTING;
        if (in.horizontalSpeed() >= RUNNING_SPEED) return MovementState.RUNNING;
        if (in.horizontalSpeed() > MOVING_SPEED) return MovementState.WALKING;
        return MovementState.IDLE;
    }
}
