package dev.des.orison.quest;

/** The seven evolution stages and their titles. */
public final class Stages {
    private Stages() { }

    private static final String[] NAME = {"DORMANT", "RECOGNITION", "MANIFESTATION", "AWAKENING", "THE UNWRITTEN", "NONEXISTENCE",
            "THE THING THAT NEVER EXISTED"};
    private static final String[] SUBTITLE = {"THE UNRECOGNIZED", "THE FIRST ANOMALY", "THE UNNATURAL PRESENCE", "THE RECOGNIZED SOVEREIGN",
            "BEYOND THE KNOWN", "THE IMPOSSIBLE AUTHORITY", "ABSOLUTE RECOGNITION"};

    private static int i(int stage) { return Math.max(1, Math.min(7, stage)) - 1; }

    public static String name(int stage) { return NAME[i(stage)]; }
    public static String subtitle(int stage) { return SUBTITLE[i(stage)]; }
    public static String full(int stage) { return name(stage) + " - " + subtitle(stage); }
}
