package dev.des.orison.ability.impl;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityResult;

/** X.3 CONTRADICTION - temporary overcharge: longer reach, faster recovery, stronger presence. */
public final class ContradictionAbility implements AbilityBehavior {
    private final OrisonPlugin plugin;

    public ContradictionAbility(OrisonPlugin plugin) { this.plugin = plugin; }

    @Override public String abilityId() { return "contradiction"; }

    @Override
    public AbilityResult execute(AbilityContext ctx) {
        plugin.transform().startContradiction(ctx.caster(), ctx.def().duration());
        return AbilityResult.ok("CONTRADICTION");
    }
}
