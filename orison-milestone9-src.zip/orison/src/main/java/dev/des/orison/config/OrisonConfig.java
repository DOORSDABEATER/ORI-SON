package dev.des.orison.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

/** Immutable, validated snapshot of config.yml. Out-of-range values are clamped. */
public record OrisonConfig(
        String initialOwnerUuid,
        int paradoxMax,
        int echoActiveLimit,
        String performanceMode,
        int majorVfxLimit,
        double vfxIntensity,
        boolean reducedEffects,
        double audioVolume,
        int backupKeep,
        boolean debug) {

    public static OrisonConfig load(Plugin plugin) {
        FileConfiguration c = plugin.getConfig();
        String mode = c.getString("performance.mode", "BALANCED").toUpperCase();
        if (!mode.equals("LOW") && !mode.equals("BALANCED") && !mode.equals("HIGH")) mode = "BALANCED";
        return new OrisonConfig(
                c.getString("owner.initial-uuid", ""),
                clamp(c.getInt("paradox.max", 100), 1, 100_000),
                clamp(c.getInt("echo.active-limit", 12), 1, 500),
                mode,
                clamp(c.getInt("performance.major-vfx-limit", 8), 1, 64),
                clamp(c.getDouble("vfx.intensity", 1.0), 0.0, 2.0),
                c.getBoolean("vfx.reduced-effects", false),
                clamp(c.getDouble("audio.volume", 1.0), 0.0, 1.0),
                clamp(c.getInt("persistence.backup-keep", 10), 1, 100),
                c.getBoolean("debug", false));
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
}
