package dev.des.orison.status;

import dev.des.orison.OrisonPlugin;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

/** Cleanup on logout/death plus the event-driven halves of UNSEEN and INVALID. */
public final class StatusListener implements Listener {
    private final OrisonPlugin plugin;

    public StatusListener(OrisonPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { plugin.statuses().endAll(e.getPlayer().getUniqueId()); }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) { plugin.statuses().endAll(e.getPlayer().getUniqueId()); }

    /** Players joining while UNSEEN is active must not see the owner. */
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.owners().owner().ifPresent(id -> {
            if (!plugin.statuses().has(id, "unseen")) return;
            Player owner = Bukkit.getPlayer(id);
            if (owner != null && !owner.equals(e.getPlayer())) e.getPlayer().hidePlayer(plugin, owner);
        });
    }

    private static Entity source(Entity damager) {
        if (damager instanceof Projectile pr && pr.getShooter() instanceof Entity sh) return sh;
        return damager;
    }

    /**
     * Everything that can intercept a hit on the owner, in a fixed order:
     * immunity (MISSING FRAME / NOT TODAY grace) -> INVALID -> RETURN TO SENDER -> FUTURE FRACTURE -> NOT TODAY -> debt ledger.
     * Void and /kill damage are never touched.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamaged(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        UUID id = p.getUniqueId();
        if (!plugin.owners().isOwner(id)) return;
        EntityDamageEvent.DamageCause cause = e.getCause();
        if (cause == EntityDamageEvent.DamageCause.VOID || cause == EntityDamageEvent.DamageCause.KILL) return;
        var st = plugin.statuses();
        var combat = plugin.combat();

        if (st.has(id, "invulnerable")) { e.setCancelled(true); return; }

        Entity attacker = e instanceof EntityDamageByEntityEvent be ? source(be.getDamager()) : null;
        double incoming = e.getFinalDamage();
        boolean returning = st.has(id, "return_to_sender");

        if (st.has(id, "invalid")) {                       // the hit never happened
            e.setCancelled(true);
            st.end(id, "invalid");
            plugin.paradox().gain(plugin.getConfig().getDouble("paradox.gain.invalid-negate", 5));
            plugin.quests().event(dev.des.orison.quest.ObjectiveType.DAMAGE_NEGATED, "invalid", 1);
            plugin.audio().at(p.getLocation(), "ability.negate", dev.des.orison.audio.AudioService.Kind.ABILITY, 24, 1.0f);
            if (plugin.vfx().usable(p)) {
                org.bukkit.Location g = p.getLocation();
                plugin.vfxLib().shock(g, 2.6f, 10);
                plugin.vfxLib().cut(g.clone().add(-0.9, 1.0, 0), g.clone().add(0.9, 1.4, 0), 7);
            }
            p.sendActionBar(MiniMessage.miniMessage().deserialize("<white>INVALID <dark_gray>| <gray>the hit never happened"));
            if (returning && combat.returnPerfect) { reflect(p, attacker, incoming * 2); st.end(id, "return_to_sender"); }
            return;
        }

        if (returning) {                                   // RETURN TO SENDER
            boolean perfect = combat.returnPerfect;
            reflect(p, attacker, incoming * (perfect ? 2 : 1));
            st.end(id, "return_to_sender");
            if (perfect) { e.setCancelled(true); return; }
            e.setDamage(e.getDamage() * 0.5);
        }

        if (st.has(id, "future_fracture")) e.setDamage(e.getDamage() * 0.5);

        if (st.has(id, "not_today") && p.getHealth() - e.getFinalDamage() <= 0) {   // refuse a lethal hit, once
            boolean enhanced = combat.notTodayEnhanced;
            e.setCancelled(true);
            double max = p.getMaxHealth();
            p.setHealth(Math.max(1.0, Math.min(max, max * (enhanced ? 0.6 : 0.3))));
            st.end(id, "not_today");
            if (enhanced) st.start(p, "invulnerable", 40, () -> { });
            plugin.quests().event(dev.des.orison.quest.ObjectiveType.DAMAGE_NEGATED, "not_today", 1);
            plugin.audio().at(p.getLocation(), "ability.negate", dev.des.orison.audio.AudioService.Kind.ABILITY, 28, 0.8f);
            if (plugin.vfx().usable(p)) plugin.vfxLib().shock(p.getLocation(), 3.4f, 14);
            p.sendActionBar(MiniMessage.miniMessage().deserialize("<white>NOT TODAY"));
            return;
        }

        if (st.has(id, "debt")) combat.debtLedger += e.getFinalDamage();      // DEBT COLLECTOR ledger
    }

    /** Sends damage back through the normal damage pipeline next tick, so region and PvP rules still apply. */
    private void reflect(Player owner, Entity attacker, double amount) {
        if (!(attacker instanceof LivingEntity le) || amount <= 0 || !dev.des.orison.ability.Targets.canAffect(plugin, owner, le)) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!le.isValid() || le.isDead()) return;
            le.damage(amount, owner);
            if (plugin.vfx().usable(owner)) plugin.vfxLib().shock(le.getLocation(), 2.0f, 10);
        });
    }

    /** Dealing damage breaks UNSEEN. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDealt(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        UUID id = p.getUniqueId();
        if (plugin.owners().isOwner(id) && plugin.statuses().has(id, "unseen")) plugin.statuses().end(id, "unseen");
    }
}
