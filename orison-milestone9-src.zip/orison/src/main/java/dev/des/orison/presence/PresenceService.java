package dev.des.orison.presence;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.presence.PositionHistory.Sample;
import dev.des.orison.vfx.DisplayVfx;
import dev.des.orison.vfx.VfxModel;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * ORISON Movement & Presence + Sovereign Presence for the owner.
 *
 * One repeating task, owner only, particles only: no entities are ever spawned, so nothing can lag
 * behind the player or outlive them. Every effect is derived each update from the owner's real
 * position, flags and a fixed-size history buffer; the only retained visual state is a bounded list
 * of short-lived "holds" and one shockwave task, all cleared by reset()/stop().
 * Main thread only.
 */
public final class PresenceService {

    private static final Color BLACK = Color.fromRGB(8, 8, 10);
    private static final Color WHITE = Color.fromRGB(250, 250, 255);
    private static final Color SILVER = Color.fromRGB(192, 196, 204);
    private static final Color GREY = Color.fromRGB(96, 98, 104);

    private enum Vis { ALL, OTHERS }

    private static final class Hold {
        final Sample sample;
        int updatesLeft;
        Hold(Sample s, int updates) { this.sample = s; this.updatesLeft = updates; }
    }

    private final OrisonPlugin plugin;
    private final Random rng = new Random();
    private final FootstepAccumulator steps = new FootstepAccumulator();
    private final PositionHistory history = new PositionHistory(24);
    private final List<Hold> holds = new ArrayList<>();

    private PresenceSettings cfg;
    private BukkitTask task;
    private BukkitTask pulse;

    private Location prev;
    private long prevTick;
    private boolean prevOnGround = true;
    private boolean wasAirborne;
    private double maxFall;
    private MovementState state = MovementState.IDLE;
    private long abilityUntilTick;
    private long transformUntilTick;
    private long lastAbilityFxTick = -1;
    private int transformLevel;
    private Integer previewStage;
    private boolean contradiction;
    private int updateCounter;
    private final List<DisplayVfx.Handle> shards = new ArrayList<>();
    private DisplayVfx.Handle eyesHandle;
    private VfxModel shardModel;
    private double velX, velZ; // blocks per tick, for leading follow-displays
    private long lastErrorLog;

    public PresenceService(OrisonPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------------ lifecycle

    public void start() {
        stop();
        cfg = PresenceSettings.load(plugin, plugin.settings());
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, cfg.intervalTicks());
    }

    public void reload() { start(); }

    /** Cancels everything and clears all retained visual state. Safe to call repeatedly. */
    public void stop() {
        if (task != null) { task.cancel(); task = null; }
        cancelPulse();
        reset();
    }

    public void reset() {
        killDisplays();
        steps.reset();
        history.clear();
        holds.clear();
        prev = null;
        wasAirborne = false;
        prevOnGround = true;
        maxFall = 0;
        state = MovementState.IDLE;
    }

    private void killDisplays() {
        for (DisplayVfx.Handle h : shards) h.kill();
        shards.clear();
        if (eyesHandle != null) { eyesHandle.kill(); eyesHandle = null; }
        shardModel = null;
    }

    private boolean models(Player p) { return plugin.vfx().usable(p); }

    private void cancelPulse() {
        if (pulse != null) { pulse.cancel(); pulse = null; }
    }

    // ------------------------------------------------------------------ public controls

    public void setPreviewStage(Integer stage) { this.previewStage = stage; }

    public void setContradiction(boolean on) { this.contradiction = on; }

    public int transformLevel() { return transformLevel; }

    /** Called by the transformation system (and /orison admin vfx transform for testing). */
    public void setTransformation(int level) {
        int newLevel = Math.max(0, Math.min(4, level));
        if (newLevel == transformLevel) return;
        int old = transformLevel;
        transformLevel = newLevel;
        holds.clear();
        cancelPulse();
        if (newLevel > old) {
            transformUntilTick = Bukkit.getCurrentTick() + 20;
            startPulse(newLevel);
        } else {
            transformUntilTick = 0;
        }
    }

    public MovementState state() { return state; }

    public List<String> describe() {
        int stage = effectiveBaseStage();
        PresenceProfile pf = PresenceProfile.forStage(Math.max(1, stage), transformLevel);
        List<String> out = new ArrayList<>();
        out.add("State: " + state + "  Stage: " + stage + (previewStage != null ? " (preview)" : "")
                + "  Transform: " + transformLevel);
        out.add("Effective stage " + pf.effectiveStage() + ", trail tier " + pf.trailTier() + ", eyes " + pf.eyeLevel()
                + ", fragments " + pf.fragmentCount() + "x" + pf.fragmentPoints() + "pt, outline " + pf.outlineLevel()
                + ", afterimages " + pf.afterimageCount());
        out.add("Interval " + cfg.intervalTicks() + "t, budget " + cfg.maxParticles() + " particles/update, view "
                + cfg.viewDistance() + ", reduced=" + cfg.reduced() + ", holds=" + holds.size());
        return out;
    }

    /** Ability systems call this when they move the owner so presence neither double-renders nor trails a teleport. */
    public void abilityMove(Player p, Location from, Location to) {
        long now = Bukkit.getCurrentTick();
        abilityUntilTick = now + 6;
        steps.reset();
        history.clear();
        prev = to.clone();
        prevTick = now;
        wasAirborne = false;
        maxFall = 0;
        if (cfg == null || !cfg.enabled() || now == lastAbilityFxTick) return; // one visual per tick, whoever triggers it
        if (!plugin.owners().isOwner(p.getUniqueId()) || plugin.statuses().has(p.getUniqueId(), "unseen")) return;
        lastAbilityFxTick = now;

        Emitter em = emitter(p, 40);
        if (from.getWorld() != to.getWorld()) return; // cross-world moves get no cut line
        plugin.audio().at(from, "ability.cut", dev.des.orison.audio.AudioService.Kind.ABILITY, 24, 1.0f);
        plugin.audio().at(to, "ability.cut", dev.des.orison.audio.AudioService.Kind.ABILITY, 24, 1.25f);
        if (models(p)) {
            plugin.vfxLib().cut(at(from, 0.9), at(to, 0.9), 9);
            plugin.vfxLib().gate(from, from.getYaw(), 0.9f, 14);
            plugin.vfxLib().ring(to, 1.2f, 10);
            plugin.vfxLib().silhouette(from, from.getYaw(), 16, cfg.bodyToOwner() ? null : p);
            return;
        }
        int pts = (int) Math.min(24, Math.max(2, from.distance(to) * 2));
        for (int i = 0; i <= pts; i++) {
            double f = i / (double) pts;
            Location l = new Location(from.getWorld(), from.getX() + (to.getX() - from.getX()) * f,
                    from.getY() + (to.getY() - from.getY()) * f + 0.9, from.getZ() + (to.getZ() - from.getZ()) * f);
            em.dust(l, i % 3 == 0 ? BLACK : WHITE, 0.55f, Vis.ALL);
        }
        addHold(new Sample(from.getX(), from.getY(), from.getZ(), from.getYaw(), false), 5);
    }

    // ------------------------------------------------------------------ tick

    private void tick() {
        try {
            update();
        } catch (Throwable t) {
            long now = System.currentTimeMillis();
            if (now - lastErrorLog > 30_000) {
                lastErrorLog = now;
                plugin.getLogger().log(java.util.logging.Level.WARNING, "Presence update failed (rate-limited log)", t);
            }
        }
    }

    private int effectiveBaseStage() {
        return previewStage != null ? previewStage : plugin.progress().stage();
    }

    private void update() {
        if (!cfg.enabled()) return;
        UUID id = plugin.owners().owner().orElse(null);
        Player p = id == null ? null : Bukkit.getPlayer(id);
        if (p == null || !p.isOnline() || p.isDead() || p.getGameMode() == GameMode.SPECTATOR) { reset(); return; }

        long now = Bukkit.getCurrentTick();
        updateCounter++;
        Location cur = p.getLocation();
        boolean onGround = p.isOnGround();

        // ---- kinematics from real movement
        boolean teleported = prev == null || prev.getWorld() != cur.getWorld() || prev.distanceSquared(cur) > 64;
        double dx = 0, dy = 0, dz = 0;
        if (!teleported) { dx = cur.getX() - prev.getX(); dy = cur.getY() - prev.getY(); dz = cur.getZ() - prev.getZ(); }
        double dt = Math.max(1, now - prevTick) / 20.0;
        double hdist = Math.hypot(dx, dz);
        double speed = hdist / dt;
        velX = dx / Math.max(1, now - prevTick);
        velZ = dz / Math.max(1, now - prevTick);
        prev = cur.clone();
        prevTick = now;
        if (teleported) {
            steps.reset();
            history.clear();
            wasAirborne = false;
            maxFall = 0;
            prevOnGround = onGround;
            return;
        }
        if (!onGround) maxFall = Math.max(maxFall, p.getFallDistance());

        MovementState s = MovementClassifier.classify(new MovementClassifier.Input(
                p.isSneaking(), p.isSprinting(), onGround, prevOnGround, speed, dy,
                now < abilityUntilTick, now < transformUntilTick, wasAirborne));
        boolean justJumped = s == MovementState.JUMPING && prevOnGround;
        boolean justLanded = s == MovementState.LANDING;
        double landedFall = justLanded ? maxFall : 0;
        state = s;
        wasAirborne = !onGround;
        prevOnGround = onGround;
        if (onGround) maxFall = 0;
        history.add(new Sample(cur.getX(), cur.getY(), cur.getZ(), cur.getYaw(), p.isSneaking()));

        // ---- stay hidden when the owner is hidden, or in states where particles make no sense
        if (plugin.statuses().has(p.getUniqueId(), "unseen")) { holds.clear(); killDisplays(); return; }
        if (p.isInsideVehicle() || p.isGliding() || p.isSwimming() || p.isFlying()) { killDisplays(); return; }

        int stage = effectiveBaseStage();
        if (stage <= 0) return; // no recorded progression yet
        PresenceProfile pf = PresenceProfile.forStage(stage, transformLevel);

        double base = cfg.intensity() * pf.intensityMultiplier() * (cfg.reduced() ? 0.5 : 1.0) * (contradiction ? 1.25 : 1.0);
        double ms = base * cfg.movementIntensity();
        double ss = base * cfg.sovereignIntensity();
        Emitter em = emitter(p, cfg.maxParticles());
        boolean sneaking = s == MovementState.SNEAKING;

        // ---- Movement trail
        double hx = 0, hz = 0;
        if (hdist > 1e-4) { hx = dx / hdist; hz = dz / hdist; }
        boolean grounded = s == MovementState.WALKING || s == MovementState.RUNNING || s == MovementState.SPRINTING;
        if (cfg.trail() && pf.trailTier() > 0 && grounded && hdist > 1e-4) {
            double stride = s == MovementState.SPRINTING ? 1.15 : s == MovementState.RUNNING ? 1.0 : 0.85;
            int n = steps.advance(hdist, stride);
            boolean left = steps.leftFoot();
            for (int i = 0; i < n; i++) {
                footstep(em, p, cur, hx, hz, pf, s, ms, left);
                left = !left;
            }
        } else if (!grounded) {
            steps.reset();
        }

        // ---- Jump / landing
        boolean useModels = models(p);
        if (justJumped && pf.trailTier() > 0) {
            if (useModels) plugin.vfxLib().ring(ground(cur), 0.7f + 0.15f * pf.trailTier(), 10);
            else ring(em, ground(cur), 0.3 + 0.05 * pf.trailTier(), 6, Vis.ALL);
            if (pf.trailTier() >= 3) addHold(sampleOf(cur, p), 3);
        }
        if (justLanded && pf.trailTier() > 0) {
            double strength = Math.min(2.0, 0.5 + landedFall * 0.15 + transformLevel * 0.1);
            plugin.audio().land(cur, strength);
            Location g = ground(cur);
            if (useModels) {
                plugin.vfxLib().shock(g, (float) (1.2 * strength + 0.6), 12);
                plugin.vfxLib().fracture(g, (float) (1.0 + 0.5 * strength), 28);
                if (pf.trailTier() >= 3) plugin.vfxLib().ring(g, (float) (2.0 * strength + 0.8), 16);
            } else {
                ring(em, g, 0.5 * strength + 0.3, 8 + pf.trailTier() * 2, Vis.ALL);
                fracture(em, g, n(2 + pf.trailTier(), ms), 0.4 * strength);
                if (pf.trailTier() >= 3) ring(em, g, 0.9 * strength + 0.3, 10 + pf.trailTier() * 2, Vis.ALL);
            }
        }

        // ---- Held silhouettes (jump takeoff, ability origins)
        for (int i = holds.size() - 1; i >= 0; i--) {
            Hold h = holds.get(i);
            if (useModels && h.updatesLeft == 3) silhouetteModel(p, h.sample, 14);
            else if (!useModels) silhouette(em, h.sample, GREY, Vis.OTHERS);
            if (--h.updatesLeft <= 0) holds.remove(i);
        }

        // ---- Delayed afterimage while moving
        if (cfg.afterimage() && pf.afterimageCount() > 0 && speed > 1.2 && !sneaking) {
            int delay = Math.max(1, pf.afterimageDelayTicks() / cfg.intervalTicks());
            for (int i = 0; i < pf.afterimageCount(); i++) {
                Sample smp = history.get(delay * (i == 0 ? 1 : 3));
                if (smp == null) continue;
                double ddx = smp.x() - cur.getX(), ddz = smp.z() - cur.getZ();
                if (ddx * ddx + ddz * ddz < 0.3) continue; // too close to read as a separate image
                if (useModels) { if (updateCounter % 2 == 0) silhouetteModel(p, smp, 6); }
                else silhouette(em, smp, i == 0 ? GREY : SILVER, Vis.OTHERS);
            }
        }

        // ---- Sovereign Presence
        if (cfg.fragments() && pf.fragmentCount() > 0) {
            if (useModels) syncShards(p, pf, ss, sneaking);
            else { killShards(); fragments(em, cur, pf, ss, sneaking); }
        } else killShards();
        boolean wantEyes = cfg.eyes() && pf.eyeLevel() > 0 && (!sneaking || pf.eyeLevel() >= 2);
        if (useModels) syncEyes(p, pf, wantEyes);
        else {
            if (eyesHandle != null) { eyesHandle.kill(); eyesHandle = null; }
            if (wantEyes && updateCounter % (pf.eyeLevel() == 1 ? 4 : 3) == 0) eyes(em, p, pf);
        }
        if (cfg.outline() && pf.outlineLevel() > 0 && !sneaking && updateCounter % 2 == 0) outline(em, cur, pf, ss);
        if (s == MovementState.IDLE) idle(em, cur, pf, ss);
    }

    // ------------------------------------------------------------------ model-based pieces

    private static Location at(Location l, double dy) { return new Location(l.getWorld(), l.getX(), l.getY() + dy, l.getZ()); }

    private void footstepModels(Player p, Location cur, double hx, double hz, PresenceProfile pf, MovementState st, boolean left) {
        var lib = plugin.vfxLib();
        double sx = -hz, sz = hx, off = left ? -0.15 : 0.15;
        Location base = new Location(cur.getWorld(), cur.getX() - hx * 0.1 + sx * off, cur.getY() + 0.03, cur.getZ() - hz * 0.1 + sz * off);
        boolean fast = st == MovementState.SPRINTING || st == MovementState.RUNNING;
        float[] size = {0, 0.9f, 1.1f, 1.4f, 1.7f};
        int tier = Math.max(1, Math.min(4, pf.trailTier()));
        float scale = size[tier] * (fast ? 1.2f : 1f) * (float) Math.max(0.6, cfg.intensity() * cfg.movementIntensity() * pf.intensityMultiplier());
        lib.fracture(base, scale, 20 + tier * 6);
        if (tier >= 2 && fast) { // sprint: spatial cut across the stride
            Location a = base.clone().add(sx * 0.7 - hx * 0.3, 0.7, sz * 0.7 - hz * 0.3);
            Location b = base.clone().add(-sx * 0.7 - hx * 0.3, 0.9, -sz * 0.7 - hz * 0.3);
            lib.cut(a, b, 7);
        }
        if (tier >= 3) lib.ring(base, 0.55f + (fast ? 0.2f : 0f), 12);          // gap in space under the step
        if (tier >= 4) lib.rift(base.clone().add(-hx * 0.35, 0, -hz * 0.35), (float) Math.toDegrees(Math.atan2(-hx, hz)), 1.9f, 22);
    }

    private void silhouetteModel(Player p, Sample s, int life) {
        plugin.vfxLib().silhouette(new Location(p.getWorld(), s.x(), s.y(), s.z()), s.yaw(), life, cfg.bodyToOwner() ? null : p);
    }

    private void killShards() {
        if (shards.isEmpty()) return;
        for (DisplayVfx.Handle h : shards) h.kill();
        shards.clear();
        shardModel = null;
    }

    /** Keeps exactly the right number of orbiting shard displays alive; their motion is computed every tick. */
    private void syncShards(Player p, PresenceProfile pf, double ss, boolean sneaking) {
        int n = pf.fragmentCount();
        if (cfg.reduced()) n = Math.min(n, 2);
        if (sneaking) n = Math.min(n, 1);
        n = Math.max(0, (int) Math.round(n * Math.min(1.0, 0.5 + ss * 0.5)));
        VfxModel model = switch (pf.fragmentPoints()) {
            case 2 -> VfxModel.SHARD_A;
            case 3 -> VfxModel.SHARD_B;
            case 4 -> VfxModel.SHARD_C;
            default -> VfxModel.SHARD_D;
        };
        shards.removeIf(h -> !h.alive());
        if (shardModel != model) { for (DisplayVfx.Handle h : shards) h.kill(); shards.clear(); shardModel = model; }
        while (shards.size() > n) shards.remove(shards.size() - 1).kill();
        float size = (float) (0.30 * (1 + 0.1 * pf.transformLevel()) * (1 + 0.04 * pf.effectiveStage()));
        UUID id = p.getUniqueId();
        while (shards.size() < n) {
            int i = shards.size(), count = Math.max(1, n);
            DisplayVfx.Handle h = plugin.vfxLib().shard(model, orbit(id, i, count, pf), size, null);
            if (h == null) break;
            shards.add(h);
        }
    }

    /** Position of shard i, recomputed each tick from the owner's live location (so it never lags behind). */
    private Supplier<Location> orbit(UUID id, int i, int n, PresenceProfile pf) {
        return () -> {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline()) return null;
            Location b = p.getLocation();
            double t = Bukkit.getCurrentTick();
            double dir = i % 2 == 0 ? 1 : -1;
            double a = i * (Math.PI * 2 / n) + i * 0.7 + t * (0.026 + 0.0065 * i) * dir;
            double r = 0.9 + 0.25 * Math.sin(i * 1.7) + 0.15 * pf.distortion();
            double y = 0.5 + 1.0 * ((i * 0.37) % 1.0) + 0.12 * Math.sin(t * 0.05 + i) + 0.25 * Math.sin(a * 0.5 + i);
            return new Location(b.getWorld(), b.getX() + Math.cos(a) * r + velX * 2, b.getY() + y, b.getZ() + Math.sin(a) * r + velZ * 2);
        };
    }

    private void syncEyes(Player p, PresenceProfile pf, boolean want) {
        if (!want) {
            if (eyesHandle != null) { eyesHandle.kill(); eyesHandle = null; }
            return;
        }
        if (eyesHandle != null && eyesHandle.alive()) return;
        float size = (float) (0.9 + 0.2 * pf.eyeLevel() + 0.08 * pf.transformLevel());
        eyesHandle = plugin.vfxLib().eyes(p, size, cfg.bodyToOwner() ? null : p);
    }

    // ------------------------------------------------------------------ trail pieces

    private void footstep(Emitter em, Player p, Location cur, double hx, double hz, PresenceProfile pf,
                          MovementState st, double ms, boolean left) {
        plugin.audio().step(cur, pf.trailTier());
        if (models(p)) { footstepModels(p, cur, hx, hz, pf, st, left); return; }
        double sx = -hz, sz = hx;
        double off = left ? -0.15 : 0.15;
        Location base = new Location(cur.getWorld(), cur.getX() - hx * 0.1 + sx * off, cur.getY() + 0.03,
                cur.getZ() - hz * 0.1 + sz * off);
        boolean fast = st == MovementState.SPRINTING || st == MovementState.RUNNING;
        int extra = fast ? 1 : 0;

        switch (pf.trailTier()) {
            case 1 -> { // Absence Trail: subtle, erased backwards
                fracture(em, base, n(2 + extra, ms), 0.25);
                em.drift(Particle.WHITE_ASH, base, -hx * 0.03, 0.01, -hz * 0.03, Vis.ALL);
            }
            case 2 -> { // Sovereign Trail: fragments + silver markings, sprint cuts
                fracture(em, base, n(3 + extra, ms), 0.35);
                floaters(em, base, hx, hz, n(2, ms), SILVER);
                em.drift(Particle.END_ROD, base.clone().add(0, 0.4, 0), -hx * 0.02, 0.005, -hz * 0.02, Vis.ALL);
                if (fast) cutLine(em, base, sx, sz, 0.6, 5, WHITE);
            }
            case 3 -> { // Unwritten Trail: gaps in space, floating bits, stronger when fast
                fracture(em, base, n(4 + extra, ms), fast ? 0.55 : 0.45);
                ring(em, base, 0.35, 6, Vis.ALL);
                floaters(em, base, hx, hz, n(3, ms), SILVER);
                if (fast) {
                    cutLine(em, base, sx, sz, 0.7, 6, WHITE);
                    cutLine(em, base.clone().add(-hx * 0.2, 0.0, -hz * 0.2), sx, sz, 0.5, 5, BLACK);
                }
            }
            default -> { // Beyond Existence: space splits behind each step, progressively erased
                fracture(em, base, n(5 + extra, ms), 0.6);
                rift(em, base, hx, hz, sx, sz);
                ring(em, base, 0.4, 8, Vis.ALL);
                floaters(em, base, hx, hz, n(3, ms), SILVER);
                em.drift(Particle.END_ROD, base.clone().add(0, 0.3, 0), -hx * 0.06, 0.004, -hz * 0.06, Vis.ALL);
                em.drift(Particle.WHITE_ASH, base.clone().add(0, 0.1, 0), -hx * 0.05, 0.01, -hz * 0.05, Vis.ALL);
            }
        }
    }

    private void fracture(Emitter em, Location base, int lines, double len) {
        for (int i = 0; i < lines; i++) {
            double a = rng.nextDouble() * Math.PI * 2;
            for (int k = 1; k <= 3; k++) {
                Location pt = base.clone().add(Math.cos(a) * len * k / 3, 0, Math.sin(a) * len * k / 3);
                em.dust(pt, k == 2 && rng.nextDouble() < 0.6 ? WHITE : BLACK, 0.5f, Vis.ALL);
            }
        }
    }

    private void floaters(Emitter em, Location base, double hx, double hz, int count, Color c) {
        for (int i = 0; i < count; i++) {
            double back = 0.3 + rng.nextDouble() * 0.7;
            Location l = base.clone().add(-hx * back, 0.3 + rng.nextDouble() * 0.8, -hz * back);
            em.dust(l, c, 0.6f, Vis.ALL);
        }
    }

    private void cutLine(Emitter em, Location base, double sx, double sz, double half, int pts, Color c) {
        for (int i = 0; i < pts; i++) {
            double f = pts == 1 ? 0 : -half + (2 * half) * i / (pts - 1);
            em.dust(base.clone().add(sx * f, 0.08, sz * f), c, 0.45f, Vis.ALL);
        }
    }

    private void rift(Emitter em, Location base, double hx, double hz, double sx, double sz) {
        double[] ys = {0.1, 0.5, 0.9, 1.3, 1.7};
        for (double y : ys) {
            em.dust(base.clone().add(-hx * 0.35 + sx * 0.1, y, -hz * 0.35 + sz * 0.1), WHITE, 0.4f, Vis.ALL);
            em.dust(base.clone().add(-hx * 0.35 - sx * 0.1, y, -hz * 0.35 - sz * 0.1), BLACK, 0.4f, Vis.ALL);
        }
    }

    private void ring(Emitter em, Location center, double radius, int pts, Vis vis) {
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2 * i / pts;
            em.dust(center.clone().add(Math.cos(a) * radius, 0.05, Math.sin(a) * radius), i % 2 == 0 ? BLACK : WHITE, 0.5f, vis);
        }
    }

    // ------------------------------------------------------------------ sovereign presence pieces

    /** Orbiting shards on tilted, differently-paced paths. Emitted in staggered pulses to avoid a smeared ring. */
    private void fragments(Emitter em, Location cur, PresenceProfile pf, double ss, boolean sneaking) {
        int n = pf.fragmentCount();
        if (cfg.reduced()) n = Math.min(n, 2);
        if (sneaking) n = Math.min(n, 1);
        n = Math.max(0, (int) Math.round(n * Math.min(1.0, 0.5 + ss * 0.5)));
        for (int i = 0; i < n; i++) {
            if ((updateCounter + i) % 3 != 0) continue;
            double dir = i % 2 == 0 ? 1 : -1;
            double a = i * (Math.PI * 2 / Math.max(1, n)) + i * 0.7 + updateCounter * (0.05 + 0.013 * i) * dir;
            double r = 0.9 + 0.25 * Math.sin(i * 1.7) + 0.15 * pf.distortion();
            double frac = (i * 0.37) % 1.0;
            double y = 0.4 + 1.1 * frac + 0.12 * Math.sin(updateCounter * 0.1 + i) + 0.25 * Math.sin(a * 0.5 + i);
            double cx = cur.getX() + Math.cos(a) * r, cz = cur.getZ() + Math.sin(a) * r, cy = cur.getY() + y;
            shard(em, cur.getWorld(), cx, cy, cz, a, pf.fragmentPoints());
        }
    }

    private void shard(Emitter em, org.bukkit.World w, double x, double y, double z, double angle, int points) {
        double[][] shape = switch (points) {
            case 2 -> new double[][]{{0, 0, 0}, {0.06, 0.10, 0}};
            case 3 -> new double[][]{{0, 0.08, 0}, {-0.07, -0.05, 0}, {0.07, -0.05, 0}};
            case 4 -> new double[][]{{0, 0.10, 0}, {0.07, 0, 0}, {0, -0.10, 0}, {-0.07, 0, 0}};
            default -> new double[][]{{0.09, 0, 0}, {-0.09, 0, 0}, {0, 0.09, 0}, {0, -0.09, 0}, {0, 0, 0.09}, {0, 0, -0.09}};
        };
        double ca = Math.cos(angle), sa = Math.sin(angle);
        for (int k = 0; k < shape.length; k++) {
            double ox = shape[k][0] * ca - shape[k][2] * sa, oz = shape[k][0] * sa + shape[k][2] * ca;
            em.dust(new Location(w, x + ox, y + shape[k][1], z + oz), k % 2 == 0 ? SILVER : BLACK, 0.5f, Vis.ALL);
        }
    }

    /** The recognised gaze: two small white points at the eyes. Hidden from the owner's own screen by default. */
    private void eyes(Emitter em, Player p, PresenceProfile pf) {
        Location eye = p.getEyeLocation();
        Vector d = eye.getDirection();
        double yaw = Math.toRadians(eye.getYaw());
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        float size = (float) ((0.3 + 0.08 * pf.eyeLevel()) * (1 + 0.1 * pf.transformLevel()));
        for (int side = -1; side <= 1; side += 2) {
            Location l = eye.clone().add(d.getX() * 0.27 + rx * 0.12 * side, d.getY() * 0.27 - 0.03, d.getZ() * 0.27 + rz * 0.12 * side);
            em.dust(l, WHITE, size, Vis.OTHERS);
        }
    }

    /** Displaced shell of dark/light points around the body. At high stages an offset "disconnected" copy appears. */
    private void outline(Emitter em, Location cur, PresenceProfile pf, double ss) {
        int n = n(pf.outlineLevel() * 1.5, ss);
        double d = pf.distortion() * 0.18;
        for (int i = 0; i < n; i++) {
            double a = rng.nextDouble() * Math.PI * 2, r = 0.42 + rng.nextDouble() * 0.1;
            double h = 0.15 + rng.nextDouble() * 1.6;
            double jx = (rng.nextDouble() - 0.5) * 2 * d, jz = (rng.nextDouble() - 0.5) * 2 * d;
            Color c = switch (rng.nextInt(3)) { case 0 -> BLACK; case 1 -> WHITE; default -> GREY; };
            em.dust(cur.clone().add(Math.cos(a) * r + jx, h, Math.sin(a) * r + jz), c, 0.4f, Vis.OTHERS);
        }
        if (pf.effectiveStage() >= 6 && rng.nextDouble() < 0.5) {
            double yaw = Math.toRadians(cur.getYaw());
            double ox = -Math.cos(yaw) * 0.28, oz = -Math.sin(yaw) * 0.28;
            for (int k = 0; k < 3; k++) em.dust(cur.clone().add(ox, 0.35 + 0.5 * k, oz), k == 1 ? WHITE : GREY, 0.45f, Vis.OTHERS);
        }
    }

    private void idle(Emitter em, Location cur, PresenceProfile pf, double ss) {
        if (rng.nextDouble() < pf.flickerChance() * ss) {
            double a = rng.nextDouble() * Math.PI * 2, r = 0.3 + rng.nextDouble() * 0.5;
            Location l = cur.clone().add(Math.cos(a) * r, 0.2 + rng.nextDouble() * 1.5, Math.sin(a) * r);
            em.dust(l, WHITE, 0.5f, Vis.ALL);
            em.dust(l.clone().add(0.07, 0.03, 0), BLACK, 0.5f, Vis.ALL);
            if (rng.nextDouble() < 0.25) plugin.audio().at(l, "presence.idle", dev.des.orison.audio.AudioService.Kind.PRESENCE, 10, 1.0f);
        }
        if (rng.nextDouble() < pf.flickerChance() * 0.15 * ss) {
            em.drift(Particle.END_ROD, cur.clone().add((rng.nextDouble() - 0.5) * 1.2, 0.3 + rng.nextDouble(), (rng.nextDouble() - 0.5) * 1.2),
                    0, 0.012, 0, Vis.ALL);
        }
        if (pf.effectiveStage() >= 5 && rng.nextDouble() < 0.1 * pf.distortion()) {
            silhouette(em, new Sample(cur.getX() + (rng.nextDouble() - 0.5) * 0.6, cur.getY(), cur.getZ() + (rng.nextDouble() - 0.5) * 0.6,
                    cur.getYaw(), false), GREY, Vis.OTHERS);
        }
    }

    private void silhouette(Emitter em, Sample s, Color body, Vis vis) {
        org.bukkit.World w = em.world;
        double k = s.sneaking() ? 0.85 : 1.0;
        double yaw = Math.toRadians(s.yaw());
        double rx = -Math.cos(yaw) * 0.22, rz = -Math.sin(yaw) * 0.22;
        double[] ys = {0.05, 0.45, 0.85, 1.25};
        for (double y : ys) em.dust(new Location(w, s.x(), s.y() + y * k, s.z()), body, 0.6f, vis);
        em.dust(new Location(w, s.x() + rx, s.y() + 1.3 * k, s.z() + rz), body, 0.5f, vis);
        em.dust(new Location(w, s.x() - rx, s.y() + 1.3 * k, s.z() - rz), body, 0.5f, vis);
        em.dust(new Location(w, s.x(), s.y() + 1.62 * k, s.z()), WHITE, 0.5f, vis);
    }

    // ------------------------------------------------------------------ transformation pulse

    private void startPulse(int level) {
        final int[] step = {0};
        pulse = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            Player p = plugin.owners().owner().map(Bukkit::getPlayer).orElse(null);
            if (p == null || !p.isOnline() || step[0] >= 10) { cancelPulse(); return; }
            Location g = ground(p.getLocation());
            if (step[0] == 0) plugin.audio().transformation(p.getLocation(), level); // plays whether or not model VFX are available
            if (models(p)) {
                int st = step[0];
                if (st == 0) {
                    plugin.vfxLib().gate(g, p.getLocation().getYaw(), 1.0f, 18);
                    if (level >= 3) plugin.vfxLib().beam(g, 5f + level, 22);
                    if (level >= 4) plugin.vfxOverlay().whiteout(p, 1, 2, 10);
                }
                if (st == 0 || st == 3 || st == 6) plugin.vfxLib().shock(g, 2.5f + st * 0.8f + level * 0.6f, 14);
                if (st == 1 && level >= 2) plugin.vfxLib().fracture(g, 2.2f + level * 0.4f, 34);
            } else {
                Emitter em = emitter(p, 64);
                double r = 0.5 + step[0] * 0.5;
                ring(em, g, r, 16, Vis.ALL);
                if (level >= 3 && step[0] >= 2) ring(em, g, r * 0.5, 10, Vis.ALL);
            }
            step[0]++;
        }, 0L, 1L);
    }

    // ------------------------------------------------------------------ helpers

    private int n(double base, double scale) { return (int) Math.floor(base * scale + rng.nextDouble()); }

    private Location ground(Location l) { return new Location(l.getWorld(), l.getX(), l.getY() + 0.03, l.getZ()); }

    private Sample sampleOf(Location l, Player p) { return new Sample(l.getX(), l.getY(), l.getZ(), l.getYaw(), p.isSneaking()); }

    private void addHold(Sample s, int updates) {
        if (holds.size() >= 4) holds.remove(0);
        holds.add(new Hold(s, updates));
    }

    private Emitter emitter(Player owner, int budget) {
        List<Player> others = new ArrayList<>();
        double vd = cfg.viewDistance();
        for (Player v : owner.getWorld().getNearbyPlayers(owner.getLocation(), vd)) {
            if (!v.equals(owner)) others.add(v);
        }
        List<Player> all = new ArrayList<>(others);
        all.add(owner);
        return new Emitter(owner.getWorld(), others, all, new ParticleBudget(budget));
    }

    private final class Emitter {
        final org.bukkit.World world;
        private final List<Player> others;
        private final List<Player> all;
        private final ParticleBudget budget;

        Emitter(org.bukkit.World world, List<Player> others, List<Player> all, ParticleBudget budget) {
            this.world = world;
            this.others = others;
            this.all = all;
            this.budget = budget;
        }

        private List<Player> targets(Vis vis) { return vis == Vis.ALL || cfg.bodyToOwner() ? all : others; }

        void dust(Location l, Color c, float size, Vis vis) {
            List<Player> t = targets(vis);
            if (t.isEmpty() || !budget.take(1)) return;
            Particle.DustOptions o = new Particle.DustOptions(c, size);
            for (Player v : t) v.spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, o);
        }

        /** Directional particle: count 0 makes offset the velocity. */
        void drift(Particle type, Location l, double vx, double vy, double vz, Vis vis) {
            List<Player> t = targets(vis);
            if (t.isEmpty() || !budget.take(1)) return;
            for (Player v : t) v.spawnParticle(type, l.getX(), l.getY(), l.getZ(), 0, vx, vy, vz, 1.0);
        }
    }
}
