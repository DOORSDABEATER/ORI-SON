package dev.des.orison.echo;

public enum Rank {
    TRACE, FRAGMENT, REPLICA, RECONSTITUTED, SOVEREIGN, ABSOLUTE;

    public static Rank fromIndex(int i) { return values()[Math.max(0, Math.min(values().length - 1, i))]; }
}
