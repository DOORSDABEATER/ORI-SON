package dev.des.orison.ability.impl;

import dev.des.orison.OrisonPlugin;
import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityResult;

/**
 * II.1 INVALID - for the duration, the next hit against the owner is declared invalid and cancelled,
 * which also grants PARADOX. The negation itself is handled in StatusListener. Void/kill damage is
 * never negated. Requires no world modification.
 */
public final class InvalidAbility implements AbilityBehavior {
    private final OrisonPlugin plugin;

    public InvalidAbility(OrisonPlugin plugin) { this.plugin = plugin; }

    @Override public String abilityId() { return "invalid"; }

    @Override
    public AbilityResult execute(AbilityContext ctx) {
        var shield = plugin.vfx().usable(ctx.caster()) ? plugin.vfxLib().shield(ctx.caster(), 1.15f) : null;
        plugin.statuses().start(ctx.caster(), "invalid", (long) (ctx.def().duration() * 20), () -> {
            if (shield != null) shield.kill();
        });
        return AbilityResult.ok("INVALID");
    }
}
