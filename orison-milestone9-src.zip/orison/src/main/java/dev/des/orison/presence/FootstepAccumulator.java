package dev.des.orison.presence;

/** Turns travelled distance into discrete, alternating footstep events (at most 2 per call). */
public final class FootstepAccumulator {
    private double carry;
    private boolean left;

    public int advance(double distance, double stride) {
        if (distance <= 0 || stride <= 0) return 0;
        carry += distance;
        int steps = 0;
        while (carry >= stride && steps < 2) {
            carry -= stride;
            steps++;
            left = !left;
        }
        if (carry >= stride) carry = 0; // dropped a long jump rather than spawning a burst later
        return steps;
    }

    /** Foot of the most recent step. */
    public boolean leftFoot() { return left; }

    public void reset() { carry = 0; }
}
