package dev.des.orison.presence;

import dev.des.orison.config.OrisonConfig;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

/** Validated snapshot of the presence: section of config.yml. */
public record PresenceSettings(
        boolean enabled, int intervalTicks, double intensity, double movementIntensity, double sovereignIntensity,
        boolean bodyToOwner, boolean eyes, boolean outline, boolean fragments, boolean afterimage, boolean trail,
        int maxParticles, int viewDistance, boolean reduced) {

    public static PresenceSettings load(Plugin plugin, OrisonConfig oc) {
        FileConfiguration c = plugin.getConfig();
        String p = "presence.";
        int explicitMax = c.getInt(p + "max-particles-per-update", 0);
        int max = explicitMax > 0 ? explicitMax : switch (oc.performanceMode()) {
            case "LOW" -> 14;
            case "HIGH" -> 72;
            default -> 36;
        };
        boolean reduced = oc.reducedEffects();
        if (reduced) max = Math.max(6, max / 2);
        return new PresenceSettings(
                c.getBoolean(p + "enabled", true),
                (int) clamp(c.getInt(p + "update-interval-ticks", 2), 1, 10),
                clamp(c.getDouble(p + "intensity", 1.0), 0, 2),
                clamp(c.getDouble(p + "movement-intensity", 1.0), 0, 2),
                clamp(c.getDouble(p + "sovereign-intensity", 1.0), 0, 2),
                c.getBoolean(p + "show-body-effects-to-owner", false),
                c.getBoolean(p + "eyes", true),
                c.getBoolean(p + "outline", true) && !reduced,
                c.getBoolean(p + "fragments", true),
                c.getBoolean(p + "afterimage", true) && !reduced,
                c.getBoolean(p + "trail", true),
                Math.min(max, 512),
                (int) clamp(c.getInt(p + "view-distance", 32), 8, 96),
                reduced);
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
}
