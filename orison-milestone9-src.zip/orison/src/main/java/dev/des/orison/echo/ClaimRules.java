package dev.des.orison.echo;

/** The decision logic behind AWAKEN. Pure and unit tested; the service gathers the facts. */
public final class ClaimRules {
    private ClaimRules() { }

    public record Context(boolean unrecognized, String unrecognizedReason,
                          boolean irregular, String irregularReason,
                          boolean sealed, String sealedReason,
                          int kills, int requiredKills,
                          boolean alreadyEchoed, int attempts, int ownerStage, double baseChance) { }

    public record Decision(ClaimOutcome outcome, String reason) { }

    /** Stronger entities need more recorded defeats before they can be claimed. */
    public static int requiredKills(double maxHealth) {
        return Math.max(1, Math.min(6, (int) Math.ceil(maxHealth / 60.0)));
    }

    public static double chance(Context c) {
        double v = c.baseChance() + 0.08 * (c.ownerStage() - 4) + 0.15 * c.attempts()
                + 0.05 * Math.max(0, c.kills() - c.requiredKills());
        return Math.max(0.05, Math.min(0.95, v));
    }

    /** Order matters: nothing to claim, then irregular, sealed, incomplete, then the roll. roll is in [0,1). */
    public static Decision decide(Context c, double roll) {
        if (c.unrecognized()) return new Decision(ClaimOutcome.UNRECOGNIZED, c.unrecognizedReason());
        if (c.irregular()) return new Decision(ClaimOutcome.IRREGULAR, c.irregularReason());
        if (c.sealed()) return new Decision(ClaimOutcome.SEALED, c.sealedReason());
        if (c.kills() < c.requiredKills()) {
            return new Decision(ClaimOutcome.INCOMPLETE, "Record " + c.kills() + "/" + c.requiredKills()
                    + ". Defeat it " + (c.requiredKills() - c.kills()) + " more time(s).");
        }
        if (c.alreadyEchoed()) return new Decision(ClaimOutcome.ACCEPTED, "The existing record was reinforced.");
        if (roll < chance(c)) return new Decision(ClaimOutcome.ACCEPTED, "The record took hold.");
        return new Decision(ClaimOutcome.RESISTED, "The record held back. It may yield on another attempt.");
    }
}
