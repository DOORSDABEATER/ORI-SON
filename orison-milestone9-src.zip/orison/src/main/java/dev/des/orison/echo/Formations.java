package dev.des.orison.echo;

/**
 * Slot offsets relative to the owner: forward (+ = ahead), right (+ = owner's right), in blocks.
 * Deterministic, collision-spaced and bounded; world placement rotates these by the owner's yaw.
 */
public final class Formations {
    private Formations() { }

    public record Slot(double forward, double right) { }

    public static final double MAX_RADIUS = 10.0;

    public static Slot slot(Formation f, int index, int count) {
        int n = Math.max(1, count);
        int i = Math.max(0, index);
        switch (f) {
            case VEIL: { // back arc, second row when crowded
                int row = n > 6 ? i % 2 : 0;
                int perRow = n > 6 ? (n + 1) / 2 : n;
                int col = n > 6 ? i / 2 : i;
                double spread = Math.min(Math.PI * 0.9, 0.55 * perRow);
                double step = perRow > 1 ? spread / (perRow - 1) : 0;
                double theta = Math.PI + (col - (perRow - 1) / 2.0) * step;
                double r = 3.5 + 1.4 * row;
                return new Slot(Math.cos(theta) * r, Math.sin(theta) * r);
            }
            case HUNT: { // forward wedge
                int rank = i / 2;
                double side = i % 2 == 0 ? -1 : 1;
                return new Slot(2.0 + rank * 1.0, side * (1.0 + rank * 0.9));
            }
            case WALL: { // line ahead, new row every 6
                int row = i / 6, col = i % 6;
                int cols = Math.min(6, n - row * 6);
                return new Slot(3.5 + row * 1.6, (col - (cols - 1) / 2.0) * 1.6);
            }
            case EXECUTION: { // surround
                double theta = 2 * Math.PI * i / n;
                double r = 4.5 + (n > 8 ? (i % 2) * 1.5 : 0);
                return new Slot(Math.cos(theta) * r, Math.sin(theta) * r);
            }
            case SCATTER: { // golden-angle spiral
                double theta = i * 2.39996323;
                double r = 3.0 + 4.0 * Math.sqrt((i + 0.5) / n);
                return new Slot(Math.cos(theta) * r, Math.sin(theta) * r);
            }
            default: { // SOVEREIGN: honour guard flanking behind
                int rank = i / 2;
                double side = i % 2 == 0 ? -1 : 1;
                return new Slot(-0.5 - rank * 1.5, side * 2.0);
            }
        }
    }
}
