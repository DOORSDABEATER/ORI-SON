package dev.des.orison.echo;

import dev.des.orison.persistence.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/** In-memory cache of hunt records and Echoes, written through to SQLite on the database thread. */
public final class EchoRepository {
    private final Database db;
    private final Map<String, HuntRecord> hunts = new ConcurrentHashMap<>();
    private final Map<UUID, EchoRecord> echoes = new ConcurrentHashMap<>();
    private final Set<UUID> dirty = ConcurrentHashMap.newKeySet();
    private volatile Formation formation = Formation.VEIL;

    public EchoRepository(Database db) { this.db = db; }

    public void loadBlocking() {
        db.callBlocking(c -> {
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM hunt_record")) {
                while (rs.next()) {
                    HuntRecord h = new HuntRecord(rs.getString("identity"));
                    h.displayName = rs.getString("display_name");
                    h.entityType = rs.getString("entity_type");
                    h.mythicId = rs.getString("mythic_id");
                    h.modelId = rs.getString("model_id");
                    h.maxHealth = rs.getDouble("max_health");
                    h.attackDamage = rs.getDouble("attack_damage");
                    h.moveSpeed = rs.getDouble("move_speed");
                    h.kills = rs.getInt("kills");
                    h.firstDefeat = rs.getLong("first_defeat");
                    h.lastDefeat = rs.getLong("last_defeat");
                    hunts.put(h.identity, h);
                }
            }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM echo_record")) {
                while (rs.next()) {
                    EchoRecord r = new EchoRecord(UUID.fromString(rs.getString("id")), rs.getString("identity"));
                    r.displayName = rs.getString("display_name");
                    r.nickname = rs.getString("nickname");
                    r.entityType = rs.getString("entity_type");
                    r.mythicId = rs.getString("mythic_id");
                    r.modelId = rs.getString("model_id");
                    r.maxHealth = rs.getDouble("max_health");
                    r.attackDamage = rs.getDouble("attack_damage");
                    r.moveSpeed = rs.getDouble("move_speed");
                    r.integrity = rs.getInt("integrity");
                    r.xp = rs.getLong("xp");
                    r.personality = Personality.parse(rs.getString("personality"), Personality.AGGRESSIVE);
                    r.role = rs.getString("role");
                    r.favourite = rs.getInt("favourite") != 0;
                    r.group = rs.getInt("grp");
                    r.reinforcements = rs.getInt("reinforcements");
                    r.claimedAt = rs.getLong("claimed_at");
                    r.downedUntil = rs.getLong("downed_until");
                    echoes.put(r.id, r);
                }
            }
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT formation FROM legion_state WHERE id = 1")) {
                if (rs.next()) {
                    try { formation = Formation.valueOf(rs.getString(1)); } catch (IllegalArgumentException ignored) { }
                }
            }
            return null;
        });
    }

    // ---- hunts
    public Optional<HuntRecord> hunt(String identity) { return Optional.ofNullable(hunts.get(identity)); }
    public Collection<HuntRecord> hunts() { return hunts.values(); }

    public HuntRecord recordDefeat(Pending p, int extraKills) {
        long now = System.currentTimeMillis();
        HuntRecord h = hunts.computeIfAbsent(p.identity, HuntRecord::new);
        if (h.kills == 0) h.firstDefeat = now;
        h.kills += Math.max(1, extraKills);
        h.lastDefeat = now;
        h.displayName = p.displayName;
        h.entityType = p.entityType;
        if (p.mythicId != null) h.mythicId = p.mythicId;
        if (p.modelId != null) h.modelId = p.modelId;
        h.maxHealth = p.maxHealth;
        h.attackDamage = p.attackDamage;
        h.moveSpeed = p.moveSpeed;
        saveHunt(h);
        // a better-known identity makes an existing Echo more faithful
        findByIdentity(p.identity).ifPresent(e -> {
            if (e.integrity < 100) {
                e.integrity = EchoMath.integrity(h.kills, e.modelId != null, e.mythicId != null, e.reinforcements, false);
                markDirty(e.id);
            }
        });
        return h;
    }

    private void saveHunt(HuntRecord h) {
        HuntRecord copy = new HuntRecord(h.identity);
        copy.displayName = h.displayName; copy.entityType = h.entityType; copy.mythicId = h.mythicId; copy.modelId = h.modelId;
        copy.maxHealth = h.maxHealth; copy.attackDamage = h.attackDamage; copy.moveSpeed = h.moveSpeed;
        copy.kills = h.kills; copy.firstDefeat = h.firstDefeat; copy.lastDefeat = h.lastDefeat;
        db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("INSERT OR REPLACE INTO hunt_record (identity, display_name, entity_type, mythic_id, model_id, max_health, attack_damage, move_speed, kills, first_defeat, last_defeat) VALUES (?,?,?,?,?,?,?,?,?,?,?)")) {
                ps.setString(1, copy.identity); ps.setString(2, copy.displayName); ps.setString(3, copy.entityType);
                ps.setString(4, copy.mythicId); ps.setString(5, copy.modelId);
                ps.setDouble(6, copy.maxHealth); ps.setDouble(7, copy.attackDamage); ps.setDouble(8, copy.moveSpeed);
                ps.setInt(9, copy.kills); ps.setLong(10, copy.firstDefeat); ps.setLong(11, copy.lastDefeat);
                ps.executeUpdate();
            }
            return null;
        });
    }

    // ---- echoes
    public Collection<EchoRecord> echoes() { return echoes.values(); }
    public EchoRecord echo(UUID id) { return echoes.get(id); }
    public Optional<EchoRecord> findByIdentity(String identity) {
        return echoes.values().stream().filter(e -> e.identity.equals(identity)).findFirst();
    }

    /** Favourites first, then rank, integrity, name: the order shown in /orison echo list. */
    public List<EchoRecord> sorted() {
        List<EchoRecord> l = new ArrayList<>(echoes.values());
        l.sort((a, b) -> {
            if (a.favourite != b.favourite) return a.favourite ? -1 : 1;
            int r = Integer.compare(b.rank().ordinal(), a.rank().ordinal());
            if (r != 0) return r;
            int i = Integer.compare(b.integrity, a.integrity);
            if (i != 0) return i;
            return a.label().compareToIgnoreCase(b.label());
        });
        return l;
    }

    public void putEcho(EchoRecord r) {
        echoes.put(r.id, r);
        saveEcho(r);
    }

    public void markDirty(UUID id) { dirty.add(id); }

    public CompletableFuture<Void> saveEcho(EchoRecord r) {
        return db.submit(c -> { upsertEcho(c, snapshot(r)); return null; }).thenAccept(v -> { });
    }

    private static EchoRecord snapshot(EchoRecord r) {
        EchoRecord s = new EchoRecord(r.id, r.identity);
        s.displayName = r.displayName; s.nickname = r.nickname; s.entityType = r.entityType; s.mythicId = r.mythicId;
        s.modelId = r.modelId; s.role = r.role; s.maxHealth = r.maxHealth; s.attackDamage = r.attackDamage; s.moveSpeed = r.moveSpeed;
        s.integrity = r.integrity; s.xp = r.xp; s.personality = r.personality; s.favourite = r.favourite; s.group = r.group;
        s.reinforcements = r.reinforcements; s.claimedAt = r.claimedAt; s.downedUntil = r.downedUntil;
        return s;
    }

    private static void upsertEcho(Connection c, EchoRecord r) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT OR REPLACE INTO echo_record (id, identity, display_name, nickname, entity_type, mythic_id, model_id, max_health, attack_damage, move_speed, integrity, xp, personality, role, favourite, grp, reinforcements, claimed_at, downed_until) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")) {
            ps.setString(1, r.id.toString()); ps.setString(2, r.identity); ps.setString(3, r.displayName); ps.setString(4, r.nickname);
            ps.setString(5, r.entityType); ps.setString(6, r.mythicId); ps.setString(7, r.modelId);
            ps.setDouble(8, r.maxHealth); ps.setDouble(9, r.attackDamage); ps.setDouble(10, r.moveSpeed);
            ps.setInt(11, r.integrity); ps.setLong(12, r.xp); ps.setString(13, r.personality.name()); ps.setString(14, r.role);
            ps.setInt(15, r.favourite ? 1 : 0); ps.setInt(16, r.group); ps.setInt(17, r.reinforcements);
            ps.setLong(18, r.claimedAt); ps.setLong(19, r.downedUntil);
            ps.executeUpdate();
        }
    }

    public CompletableFuture<Void> deleteEcho(UUID id) {
        echoes.remove(id);
        dirty.remove(id);
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM echo_record WHERE id = ?")) {
                ps.setString(1, id.toString());
                ps.executeUpdate();
            }
            return null;
        }).thenAccept(v -> { });
    }

    private List<EchoRecord> drainDirty() {
        List<EchoRecord> out = new ArrayList<>();
        for (UUID id : new ArrayList<>(dirty)) {
            dirty.remove(id);
            EchoRecord r = echoes.get(id);
            if (r != null) out.add(snapshot(r));
        }
        return out;
    }

    public void flushDirtyAsync() {
        List<EchoRecord> batch = drainDirty();
        if (batch.isEmpty()) return;
        db.submit(c -> { for (EchoRecord r : batch) upsertEcho(c, r); return null; });
    }

    public void flushDirtyBlocking() {
        List<EchoRecord> batch = drainDirty();
        if (batch.isEmpty()) return;
        db.callBlocking(c -> { for (EchoRecord r : batch) upsertEcho(c, r); return null; });
    }

    // ---- formation
    public Formation formation() { return formation; }

    public void setFormation(Formation f) {
        formation = f;
        db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("UPDATE legion_state SET formation = ? WHERE id = 1")) {
                ps.setString(1, f.name());
                ps.executeUpdate();
            }
            return null;
        });
    }
}
