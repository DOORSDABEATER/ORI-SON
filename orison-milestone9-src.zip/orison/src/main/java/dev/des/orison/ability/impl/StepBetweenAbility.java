package dev.des.orison.ability.impl;

import dev.des.orison.ability.AbilityBehavior;
import dev.des.orison.ability.AbilityContext;
import dev.des.orison.ability.AbilityResult;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/**
 * I.2 STEP BETWEEN - blink along the line of sight, stopping before solid blocks. Only lands on a
 * location that is passable, dry, inside the world border and has ground within 5 blocks that is not
 * lava or magma. Limitation: this is a plain teleport; region plugins that only guard block/entity
 * events will not stop it.
 */
public final class StepBetweenAbility implements AbilityBehavior {

    @Override public String abilityId() { return "step_between"; }

    @Override
    public AbilityResult execute(AbilityContext ctx) {
        Player p = ctx.caster();
        Location from = p.getLocation();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        double range = ctx.def().range() * ctx.plugin().transform().rangeMultiplier();

        RayTraceResult hit = p.getWorld().rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        double reach = hit == null ? range : Math.max(0, hit.getHitPosition().distance(eye.toVector()) - 0.6);

        for (double d = reach; d >= 1.0; d -= 0.5) {
            Location feet = eye.clone().add(dir.clone().multiply(d)).subtract(0, p.getEyeHeight(), 0);
            if (!safe(feet)) continue;
            feet.setYaw(eye.getYaw());
            feet.setPitch(eye.getPitch());
            p.teleport(feet);
            ctx.plugin().presence().abilityMove(p, from, feet);
            return AbilityResult.ok("STEP BETWEEN");
        }
        return AbilityResult.fail("No safe space ahead.");
    }

    private static boolean safe(Location feet) {
        if (!feet.getWorld().getWorldBorder().isInside(feet)) return false;
        Block f = feet.getBlock();
        Block h = f.getRelative(0, 1, 0);
        if (!f.isPassable() || !h.isPassable() || f.isLiquid() || h.isLiquid()) return false;
        Block g = f;
        for (int i = 0; i < 5; i++) {
            g = g.getRelative(0, -1, 0);
            if (!g.isPassable() || g.isLiquid()) {
                Material m = g.getType();
                return m != Material.LAVA && m != Material.MAGMA_BLOCK;
            }
        }
        return false;
    }
}
