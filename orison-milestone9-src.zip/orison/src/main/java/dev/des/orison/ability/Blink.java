package dev.des.orison.ability;

import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Safe-destination finding shared by movement abilities. A plain teleport: region plugins that only guard block/entity events will not stop it. */
public final class Blink {
    private Blink() { }

    public static boolean safe(Location feet) {
        if (feet.getWorld() == null || !feet.getWorld().getWorldBorder().isInside(feet)) return false;
        Block f = feet.getBlock();
        Block h = f.getRelative(0, 1, 0);
        if (!f.isPassable() || !h.isPassable() || f.isLiquid() || h.isLiquid()) return false;
        Block g = f;
        for (int i = 0; i < 5; i++) {
            g = g.getRelative(0, -1, 0);
            if (!g.isPassable() || g.isLiquid()) {
                Material m = g.getType();
                return m != Material.LAVA && m != Material.MAGMA_BLOCK;
            }
        }
        return false;
    }

    /** Furthest safe spot along dir (from the player's eyes), stopping before solid blocks; null if none at least minDist away. */
    public static Location along(Player p, Vector dir, double reach, double minDist) {
        Location eye = p.getEyeLocation();
        Vector d = dir.clone().normalize();
        RayTraceResult hit = p.getWorld().rayTraceBlocks(eye, d, reach, FluidCollisionMode.NEVER, true);
        double r = hit == null ? reach : Math.max(0, hit.getHitPosition().distance(eye.toVector()) - 0.6);
        for (double t = r; t >= minDist; t -= 0.5) {
            Location feet = eye.clone().add(d.clone().multiply(t)).subtract(0, p.getEyeHeight(), 0);
            if (!safe(feet)) continue;
            feet.setYaw(eye.getYaw());
            feet.setPitch(eye.getPitch());
            return feet;
        }
        return null;
    }

    /** A safe spot next to the target on the owner's side, facing it. */
    public static Location adjacent(Player p, LivingEntity target) {
        Vector toOwner = p.getLocation().toVector().subtract(target.getLocation().toVector()).setY(0);
        if (toOwner.lengthSquared() < 1e-4) toOwner = new Vector(1, 0, 0);
        toOwner.normalize();
        for (double dist : new double[]{1.8, 1.4, 1.0, -1.8, -1.4}) {
            Location c = target.getLocation().clone().add(toOwner.clone().multiply(dist));
            if (safe(c)) { face(c, target.getLocation()); return c; }
        }
        return null;
    }

    /** A safe spot behind the target (relative to where it faces). */
    public static Location behind(LivingEntity target) {
        Vector dir = target.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 1e-4) return null;
        dir.normalize();
        for (double dist : new double[]{1.6, 1.2, 1.0}) {
            Location c = target.getLocation().clone().subtract(dir.clone().multiply(dist));
            if (safe(c)) { face(c, target.getLocation()); return c; }
        }
        return null;
    }

    private static void face(Location from, Location to) {
        Vector v = to.toVector().subtract(from.toVector());
        from.setDirection(v);
    }
}
