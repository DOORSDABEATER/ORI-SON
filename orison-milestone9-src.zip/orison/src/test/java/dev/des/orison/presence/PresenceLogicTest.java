package dev.des.orison.presence;

import dev.des.orison.presence.MovementClassifier.Input;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PresenceLogicTest {

    private static Input in(boolean sneak, boolean sprint, boolean ground, boolean wasGround, double speed, double dy,
                            boolean ability, boolean transforming, boolean wasAir) {
        return new Input(sneak, sprint, ground, wasGround, speed, dy, ability, transforming, wasAir);
    }

    @Test void idleWhenStill() {
        assertEquals(MovementState.IDLE, MovementClassifier.classify(in(false, false, true, true, 0.0, 0, false, false, false)));
    }
    @Test void walking() {
        assertEquals(MovementState.WALKING, MovementClassifier.classify(in(false, false, true, true, 4.3, 0, false, false, false)));
    }
    @Test void runningIsFastNonSprint() {
        assertEquals(MovementState.RUNNING, MovementClassifier.classify(in(false, false, true, true, 6.0, 0, false, false, false)));
    }
    @Test void sprinting() {
        assertEquals(MovementState.SPRINTING, MovementClassifier.classify(in(false, true, true, true, 5.6, 0, false, false, false)));
    }
    @Test void sprintFlagWithoutMotionIsNotSprinting() {
        assertEquals(MovementState.IDLE, MovementClassifier.classify(in(false, true, true, true, 0.0, 0, false, false, false)));
    }
    @Test void sneakingEvenWhenStill() {
        assertEquals(MovementState.SNEAKING, MovementClassifier.classify(in(true, false, true, true, 0.0, 0, false, false, false)));
        assertEquals(MovementState.SNEAKING, MovementClassifier.classify(in(true, false, true, true, 1.3, 0, false, false, false)));
    }
    @Test void jumpingOnTakeoffAndWhileRising() {
        assertEquals(MovementState.JUMPING, MovementClassifier.classify(in(false, false, false, true, 0.0, 0.75, false, false, false)));
        assertEquals(MovementState.JUMPING, MovementClassifier.classify(in(false, false, false, false, 0.0, 0.1, false, false, true)));
    }
    @Test void fallingWhenDropping() {
        assertEquals(MovementState.FALLING, MovementClassifier.classify(in(false, false, false, false, 0.0, -0.5, false, false, true)));
        assertEquals(MovementState.FALLING, MovementClassifier.classify(in(false, false, false, true, 1.0, -0.3, false, false, false)));
    }
    @Test void landingOnceAfterAirborne() {
        assertEquals(MovementState.LANDING, MovementClassifier.classify(in(false, false, true, false, 0.0, -0.2, false, false, true)));
        assertEquals(MovementState.IDLE, MovementClassifier.classify(in(false, false, true, true, 0.0, 0, false, false, false)));
    }
    @Test void abilityAndTransformationOverride() {
        assertEquals(MovementState.ABILITY_MOVEMENT, MovementClassifier.classify(in(false, true, true, true, 9.0, 0, true, false, false)));
        assertEquals(MovementState.TRANSFORMATION, MovementClassifier.classify(in(false, true, true, true, 9.0, 0, true, true, false)));
    }

    @Test void footstepsAccumulateAndAlternate() {
        FootstepAccumulator f = new FootstepAccumulator();
        assertEquals(0, f.advance(0.5, 0.85));
        assertEquals(1, f.advance(0.4, 0.85));
        boolean first = f.leftFoot();
        assertEquals(1, f.advance(0.9, 0.85));
        assertNotEquals(first, f.leftFoot());
    }
    @Test void footstepsCappedAtTwoPerCall() {
        FootstepAccumulator f = new FootstepAccumulator();
        assertEquals(2, f.advance(10.0, 0.85));
        assertEquals(0, f.advance(0.1, 0.85)); // leftover dropped, no later burst
    }
    @Test void footstepsReset() {
        FootstepAccumulator f = new FootstepAccumulator();
        f.advance(0.8, 0.85);
        f.reset();
        assertEquals(0, f.advance(0.1, 0.85));
    }

    @Test void historyRingAndBounds() {
        PositionHistory h = new PositionHistory(3);
        assertNull(h.get(0));
        for (int i = 1; i <= 5; i++) h.add(new PositionHistory.Sample(i, 0, 0, 0f, false));
        assertEquals(3, h.size());
        assertEquals(5.0, h.get(0).x(), 1e-9);
        assertEquals(3.0, h.get(2).x(), 1e-9);
        assertNull(h.get(3));
        assertNull(h.get(-1));
        h.clear();
        assertEquals(0, h.size());
        assertNull(h.get(0));
    }

    @Test void budgetNeverGoesNegative() {
        ParticleBudget b = new ParticleBudget(3);
        assertTrue(b.take(2));
        assertTrue(b.take(1));
        assertFalse(b.take(1));
        assertEquals(0, b.remaining());
    }

    @Test void profileGrowsWithStage() {
        PresenceProfile prev = PresenceProfile.forStage(1, 0);
        for (int s = 2; s <= 7; s++) {
            PresenceProfile p = PresenceProfile.forStage(s, 0);
            assertTrue(p.trailTier() >= prev.trailTier(), "trail " + s);
            assertTrue(p.eyeLevel() >= prev.eyeLevel(), "eye " + s);
            assertTrue(p.fragmentCount() >= prev.fragmentCount(), "frag " + s);
            assertTrue(p.outlineLevel() >= prev.outlineLevel(), "outline " + s);
            assertTrue(p.distortion() >= prev.distortion(), "distortion " + s);
            prev = p;
        }
    }
    @Test void dormantIsAlmostImperceptible() {
        PresenceProfile p = PresenceProfile.forStage(1, 0);
        assertEquals(0, p.trailTier());
        assertEquals(0, p.eyeLevel());
        assertEquals(0, p.fragmentCount());
        assertEquals(0, p.outlineLevel());
        assertEquals(0, p.afterimageCount());
    }
    @Test void trailTiersMapToSpec() {
        assertEquals(1, PresenceProfile.forStage(2, 0).trailTier());  // Absence
        assertEquals(2, PresenceProfile.forStage(4, 0).trailTier());  // Sovereign
        assertEquals(3, PresenceProfile.forStage(5, 0).trailTier());  // Unwritten
        assertEquals(4, PresenceProfile.forStage(7, 0).trailTier());  // Beyond Existence
    }
    @Test void afterimageAppearsLateAndGetsTighter() {
        assertEquals(0, PresenceProfile.forStage(4, 0).afterimageCount());
        assertTrue(PresenceProfile.forStage(5, 0).afterimageCount() >= 1);
        assertTrue(PresenceProfile.forStage(7, 0).afterimageDelayTicks() < PresenceProfile.forStage(5, 0).afterimageDelayTicks());
        assertEquals(2, PresenceProfile.forStage(7, 0).afterimageCount());
    }
    @Test void transformationsUpgradeEverything() {
        PresenceProfile base = PresenceProfile.forStage(2, 0);
        PresenceProfile t4 = PresenceProfile.forStage(2, 4);
        assertEquals(7, t4.effectiveStage());
        assertEquals(4, t4.trailTier());
        assertTrue(t4.fragmentCount() > base.fragmentCount());
        assertTrue(t4.intensityMultiplier() > base.intensityMultiplier());
        assertEquals(6, t4.fragmentPoints());
        assertTrue(PresenceProfile.forStage(7, 4).fragmentCount() > PresenceProfile.forStage(7, 0).fragmentCount());
    }
    @Test void transformationNeverLowersStage() {
        assertEquals(7, PresenceProfile.forStage(7, 1).effectiveStage());
        assertEquals(4, PresenceProfile.forStage(1, 1).effectiveStage());
    }
    @Test void outOfRangeInputsAreClamped() {
        assertEquals(1, PresenceProfile.forStage(-5, -2).effectiveStage());
        assertEquals(7, PresenceProfile.forStage(99, 99).effectiveStage());
        assertEquals(4, PresenceProfile.forStage(0, 99).transformLevel());
    }
}
