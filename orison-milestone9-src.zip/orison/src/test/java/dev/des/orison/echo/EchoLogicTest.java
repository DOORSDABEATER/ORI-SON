package dev.des.orison.echo;

import dev.des.orison.echo.ClaimRules.Context;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EchoLogicTest {

    @Test void integrityBandsMatchSpec() {
        assertEquals(IntegrityBand.UNSTABLE, IntegrityBand.of(0));
        assertEquals(IntegrityBand.UNSTABLE, IntegrityBand.of(24));
        assertEquals(IntegrityBand.PARTIAL, IntegrityBand.of(25));
        assertEquals(IntegrityBand.PARTIAL, IntegrityBand.of(49));
        assertEquals(IntegrityBand.RECOGNIZABLE, IntegrityBand.of(50));
        assertEquals(IntegrityBand.RECOGNIZABLE, IntegrityBand.of(74));
        assertEquals(IntegrityBand.HIGH_FIDELITY, IntegrityBand.of(75));
        assertEquals(IntegrityBand.HIGH_FIDELITY, IntegrityBand.of(89));
        assertEquals(IntegrityBand.NEAR_PERFECT, IntegrityBand.of(90));
        assertEquals(IntegrityBand.NEAR_PERFECT, IntegrityBand.of(99));
        assertEquals(IntegrityBand.COMPLETE, IntegrityBand.of(100));
    }

    @Test void completeOnlyViaPerfectRecord() {
        assertEquals(99, EchoMath.integrity(50, true, true, 50, false));
        assertEquals(100, EchoMath.integrity(0, false, false, 0, true));
    }

    @Test void integrityGrowsWithFidelity() {
        int plain = EchoMath.integrity(1, false, false, 0, false);
        assertTrue(EchoMath.integrity(3, false, false, 0, false) > plain);
        assertTrue(EchoMath.integrity(1, true, false, 0, false) > plain);
        assertTrue(EchoMath.integrity(1, false, true, 0, false) > plain);
        assertTrue(EchoMath.integrity(1, false, false, 2, false) > plain);
        assertEquals(30, plain);
    }

    @Test void rankNeedsBothXpAndIntegrity() {
        assertEquals(0, EchoMath.rankIndex(0, 0));
        assertEquals(0, EchoMath.rankIndex(10000, 24));      // lots of xp, unstable record -> still TRACE
        assertEquals(1, EchoMath.rankIndex(100, 25));
        assertEquals(1, EchoMath.rankIndex(100000, 49));
        assertEquals(2, EchoMath.rankIndex(400, 50));
        assertEquals(3, EchoMath.rankIndex(1200, 75));
        assertEquals(4, EchoMath.rankIndex(3500, 90));
        assertEquals(4, EchoMath.rankIndex(100000, 99));     // ABSOLUTE needs a COMPLETE record
        assertEquals(5, EchoMath.rankIndex(10000, 100));
        assertEquals(Rank.ABSOLUTE, Rank.fromIndex(99));
        assertEquals(Rank.TRACE, Rank.fromIndex(-3));
    }

    @Test void statScaleIsMonotonicAndCapped() {
        double prev = 0;
        for (int r = 0; r <= 5; r++) {
            double s = EchoMath.statScale(r, 100);
            assertTrue(s > prev);
            prev = s;
        }
        assertTrue(EchoMath.statScale(5, 100) <= 1.1000001);
        assertTrue(EchoMath.statScale(0, 0) >= 0.35);
        assertTrue(EchoMath.statScale(0, 100) > EchoMath.statScale(0, 0));
    }

    @Test void xpForKillScalesWithVictim() {
        assertTrue(EchoMath.xpForKill(200) > EchoMath.xpForKill(20));
        assertEquals(1, EchoMath.xpForKill(0));
    }

    private static Context ctx(boolean unrec, boolean irr, boolean sealed, int kills, int req, boolean echoed, int attempts, int stage, double base) {
        return new Context(unrec, "u", irr, "i", sealed, "s", kills, req, echoed, attempts, stage, base);
    }

    @Test void decisionOrder() {
        assertEquals(ClaimOutcome.UNRECOGNIZED, ClaimRules.decide(ctx(true, true, true, 0, 5, false, 0, 4, 0.6), 0.0).outcome());
        assertEquals(ClaimOutcome.IRREGULAR, ClaimRules.decide(ctx(false, true, true, 0, 5, false, 0, 4, 0.6), 0.0).outcome());
        assertEquals(ClaimOutcome.SEALED, ClaimRules.decide(ctx(false, false, true, 0, 5, false, 0, 4, 0.6), 0.0).outcome());
        assertEquals(ClaimOutcome.INCOMPLETE, ClaimRules.decide(ctx(false, false, false, 1, 3, false, 0, 4, 0.6), 0.0).outcome());
    }

    @Test void incompleteExplainsHowMany() {
        String reason = ClaimRules.decide(ctx(false, false, false, 1, 3, false, 0, 4, 0.6), 0.0).reason();
        assertTrue(reason.contains("1/3"));
        assertTrue(reason.contains("2 more"));
    }

    @Test void rollDecidesAcceptedVsResisted() {
        Context c = ctx(false, false, false, 1, 1, false, 0, 4, 0.6);
        assertEquals(ClaimOutcome.ACCEPTED, ClaimRules.decide(c, 0.59).outcome());
        assertEquals(ClaimOutcome.RESISTED, ClaimRules.decide(c, 0.61).outcome());
    }

    @Test void retriesImproveTheOdds() {
        Context first = ctx(false, false, false, 1, 1, false, 0, 4, 0.6);
        Context third = ctx(false, false, false, 1, 1, false, 2, 4, 0.6);
        assertTrue(ClaimRules.chance(third) > ClaimRules.chance(first));
    }

    @Test void chanceIsClamped() {
        assertTrue(ClaimRules.chance(ctx(false, false, false, 1, 1, false, 99, 7, 0.9)) <= 0.95);
        assertTrue(ClaimRules.chance(ctx(false, false, false, 1, 1, false, 0, 1, 0.0)) >= 0.05);
    }

    @Test void existingEchoIsReinforcedWithoutRoll() {
        Context c = ctx(false, false, false, 2, 1, true, 0, 4, 0.0);
        assertEquals(ClaimOutcome.ACCEPTED, ClaimRules.decide(c, 0.99).outcome());
    }

    @Test void requiredKillsScaleWithHealth() {
        assertEquals(1, ClaimRules.requiredKills(20));
        assertEquals(2, ClaimRules.requiredKills(100));
        assertEquals(4, ClaimRules.requiredKills(200));
        assertEquals(6, ClaimRules.requiredKills(5000));
        assertEquals(1, ClaimRules.requiredKills(0));
    }

    @Test void personalityDefaults() {
        assertEquals(Personality.TACTICAL, Personality.defaultFor("skeleton"));
        assertEquals(Personality.GUARDIAN, Personality.defaultFor("iron_golem"));
        assertEquals(Personality.AGGRESSIVE, Personality.defaultFor("zombie"));
        assertEquals(Personality.AGGRESSIVE, Personality.defaultFor(null));
        assertEquals(Personality.SUPPORT, Personality.parse("support", Personality.AGGRESSIVE));
        assertEquals(Personality.AGGRESSIVE, Personality.parse("nonsense", Personality.AGGRESSIVE));
    }

    @Test void everyFormationKeepsEchoesApartAndNearby() {
        for (Formation f : Formation.values()) {
            for (int n = 1; n <= 12; n++) {
                for (int a = 0; a < n; a++) {
                    Formations.Slot sa = Formations.slot(f, a, n);
                    double radius = Math.hypot(sa.forward(), sa.right());
                    assertTrue(radius <= Formations.MAX_RADIUS, f + " n=" + n + " i=" + a + " radius " + radius);
                    for (int b = a + 1; b < n; b++) {
                        Formations.Slot sb = Formations.slot(f, b, n);
                        double d = Math.hypot(sa.forward() - sb.forward(), sa.right() - sb.right());
                        assertTrue(d >= 0.8, f + " n=" + n + " slots " + a + "," + b + " only " + d + " apart");
                    }
                }
            }
        }
    }

    @Test void formationsAreDeterministic() {
        for (Formation f : Formation.values()) {
            assertEquals(Formations.slot(f, 3, 8), Formations.slot(f, 3, 8));
        }
    }

    @Test void formationsHaveDistinctCharacter() {
        // VEIL sits behind the owner, HUNT and WALL ahead, SOVEREIGN flanks behind.
        assertTrue(Formations.slot(Formation.VEIL, 0, 1).forward() < 0);
        assertTrue(Formations.slot(Formation.HUNT, 0, 4).forward() > 0);
        assertTrue(Formations.slot(Formation.WALL, 0, 4).forward() > 0);
        assertTrue(Formations.slot(Formation.SOVEREIGN, 0, 4).forward() < 0);
        assertNotEquals(Formations.slot(Formation.EXECUTION, 1, 6), Formations.slot(Formation.SCATTER, 1, 6));
    }
}
