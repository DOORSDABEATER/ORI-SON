package dev.des.orison.quest;

import dev.des.orison.mastery.MasteryMath;
import dev.des.orison.transform.TransformRules;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class ProgressionLogicTest {

    private static QuestDef def(String id) {
        return QuestCatalog.defaults().stream().filter(q -> q.id().equals(id)).findFirst().orElseThrow();
    }

    @Test void stageQuestsFormAStrictChain() {
        List<QuestDef> stageQuests = QuestCatalog.defaults().stream().filter(q -> q.grantStage() > 0).toList();
        Set<Integer> granted = new HashSet<>();
        for (QuestDef q : stageQuests) {
            assertTrue(granted.add(q.grantStage()), "stage granted twice: " + q.grantStage());
            assertEquals(q.grantStage() - 1, q.minStage());       // cannot skip a stage
        }
        for (int s = 2; s <= 7; s++) assertTrue(granted.contains(s), "no quest grants stage " + s);
    }

    @Test void questIdsAreUniqueAndTitlesExist() {
        Set<String> ids = new HashSet<>();
        for (QuestDef q : QuestCatalog.defaults()) {
            assertTrue(ids.add(q.id()));
            assertTrue(Titles.exists(q.rewardTitle()), "unknown title " + q.rewardTitle());
            assertFalse(q.objectives().isEmpty());
        }
    }

    @Test void thereAreHiddenQuests() {
        assertTrue(def("first_anomaly").hidden());
        assertTrue(def("final_recognition").hidden());
        assertTrue(def("the_exception").hidden());
    }

    @Test void theExceptionUnsealsAzriel() {
        assertEquals("mythic:azriel", def("the_exception").unseals());
        assertEquals(0, def("the_exception").grantStage());
    }

    @Test void countersAccumulateAndCap() {
        QuestDef d = def("first_anomaly");
        int[] c = new int[1];
        assertTrue(QuestLogic.apply(d, c, ObjectiveType.DEFEAT_HOSTILE, "vanilla:zombie", 1));
        assertEquals(1, c[0]);
        QuestLogic.apply(d, c, ObjectiveType.DEFEAT_HOSTILE, "vanilla:zombie", 100);
        assertEquals(15, c[0]);
        assertTrue(QuestLogic.isComplete(d, c));
    }

    @Test void wrongEventsDoNothing() {
        QuestDef d = def("first_anomaly");
        int[] c = new int[1];
        assertFalse(QuestLogic.apply(d, c, ObjectiveType.ABILITY_USE, "unseen", 1));
        assertFalse(QuestLogic.apply(d, c, ObjectiveType.DEFEAT_HOSTILE, "x", 0));
        assertEquals(0, c[0]);
    }

    @Test void specificKeysMustMatch() {
        QuestDef d = def("recognized_sovereign");
        int[] c = new int[3];
        QuestLogic.apply(d, c, ObjectiveType.ABILITY_USE, "step_between", 1);
        QuestLogic.apply(d, c, ObjectiveType.ABILITY_USE, "unseen", 2);
        QuestLogic.apply(d, c, ObjectiveType.ABILITY_USE, "invalid", 5);   // not an objective
        assertEquals(1, c[0]);
        assertEquals(2, c[1]);
        assertEquals(0, c[2]);
        assertFalse(QuestLogic.isComplete(d, c));
    }

    @Test void wildcardCountsEverything() {
        QuestDef d = def("unnatural_presence");
        int[] c = new int[2];
        QuestLogic.apply(d, c, ObjectiveType.ABILITY_USE, "anything", 3);
        assertEquals(3, c[0]);
    }

    @Test void rankObjectiveKeepsTheMaximum() {
        QuestDef d = def("impossible_authority");
        int[] c = new int[3];
        QuestLogic.apply(d, c, ObjectiveType.ECHO_RANK, "", 1);
        QuestLogic.apply(d, c, ObjectiveType.ECHO_RANK, "", 0);   // a lower value never reduces it
        assertEquals(1, c[0]);
        QuestLogic.apply(d, c, ObjectiveType.ECHO_RANK, "", 5);
        assertEquals(2, c[0]);                                      // capped at the requirement
    }

    @Test void completionNeedsEveryObjective() {
        QuestDef d = def("the_exception");
        int[] c = new int[2];
        QuestLogic.apply(d, c, ObjectiveType.STORY, "azriel_defeated", 1);
        assertFalse(QuestLogic.isComplete(d, c));
        QuestLogic.apply(d, c, ObjectiveType.STORY, "exception_acknowledged", 1);
        assertTrue(QuestLogic.isComplete(d, c));
    }

    @Test void questsDoNotPreFarm() {
        QuestDef d = def("unnatural_presence");               // needs stage 2
        assertFalse(QuestLogic.isActive(d, 1, false));
        assertTrue(QuestLogic.isActive(d, 2, false));
        assertTrue(QuestLogic.isActive(d, 5, false));
        assertFalse(QuestLogic.isActive(d, 2, true));         // complete quests stop counting
    }

    @Test void hiddenQuestsRevealByProgressOrFlag() {
        QuestDef d = def("the_exception");
        int[] none = new int[2];
        assertFalse(QuestLogic.isRevealed(d, none, false, Set.of()));
        assertTrue(QuestLogic.isRevealed(d, none, false, Set.of("azriel_defeated")));
        assertTrue(QuestLogic.isRevealed(d, new int[]{1, 0}, false, Set.of()));
        assertTrue(QuestLogic.isRevealed(d, none, true, Set.of()));
        assertTrue(QuestLogic.isRevealed(def("unnatural_presence"), new int[2], false, Set.of()));   // not hidden
    }

    @Test void progressTotals() {
        QuestDef d = def("unnatural_presence");
        int[] c = {5, 40};
        assertEquals(55, QuestLogic.totalRequired(d));
        assertEquals(45, QuestLogic.totalDone(d, c));
    }

    @Test void stageNamesCoverAllSeven() {
        for (int s = 1; s <= 7; s++) { assertFalse(Stages.name(s).isEmpty()); assertFalse(Stages.subtitle(s).isEmpty()); }
        assertEquals("DORMANT", Stages.name(1));
        assertEquals("ABSOLUTE RECOGNITION", Stages.subtitle(7));
        assertEquals("DORMANT", Stages.name(-3));
        assertEquals("THE THING THAT NEVER EXISTED", Stages.name(99));
        for (int s = 1; s <= 7; s++) assertTrue(Titles.exists("stage_" + s));
    }

    @Test void masteryLevels() {
        assertEquals(0, MasteryMath.level(0));
        assertEquals(0, MasteryMath.level(9));
        assertEquals(1, MasteryMath.level(10));
        assertEquals(3, MasteryMath.level(75));
        assertEquals(5, MasteryMath.level(300));
        assertEquals(5, MasteryMath.level(99999));
        assertEquals(10, MasteryMath.toNext(0));
        assertEquals(-1, MasteryMath.toNext(300));
    }

    @Test void masteryHelpsButNeverMakesThingsFree() {
        assertEquals(1.0, MasteryMath.costFactor(0), 1e-9);
        assertTrue(MasteryMath.costFactor(5) < MasteryMath.costFactor(1));
        assertTrue(MasteryMath.costFactor(5) >= 0.85 - 1e-9);
        assertTrue(MasteryMath.cooldownFactor(5) >= 0.80 - 1e-9);
        assertEquals(MasteryMath.costFactor(5), MasteryMath.costFactor(50), 1e-9);
    }

    @Test void transformationsEscalate() {
        for (int l = 1; l <= 4; l++) {
            assertTrue(TransformRules.rangeFactor(l) > TransformRules.rangeFactor(l - 1));
            assertTrue(TransformRules.cooldownFactor(l) < TransformRules.cooldownFactor(l - 1));
            assertTrue(TransformRules.costFactor(l) < TransformRules.costFactor(l - 1));
            assertTrue(TransformRules.MIN_STAGE[l] > TransformRules.MIN_STAGE[l - 1]);
        }
        assertEquals(1.0, TransformRules.rangeFactor(0), 1e-9);
        assertEquals(7, TransformRules.MIN_STAGE[4]);
    }

    @Test void transformationAbilityMapping() {
        assertEquals(1, TransformRules.levelOf("first_recognition"));
        assertEquals(2, TransformRules.levelOf("fractured_ascension"));
        assertEquals(3, TransformRules.levelOf("absolute_manifestation"));
        assertEquals(4, TransformRules.levelOf("beyond_existence"));
        assertEquals(0, TransformRules.levelOf("unseen"));
        assertEquals(-1, TransformRules.speedAmplifier(1));
        assertEquals("BEYOND EXISTENCE", TransformRules.name(4));
        assertEquals("NONE", TransformRules.name(-7));
    }
}
