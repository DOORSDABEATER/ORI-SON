package dev.des.orison.azriel;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AzrielRulesTest {

    @Test void fivePhasesInOrder() {
        assertEquals(5, Phase.values().length);
        assertEquals(Phase.AUTHORITY_CONFLICT, Phase.RECOGNITION_FAILURE.next());
        assertEquals(Phase.IMPOSSIBLE_RECORD, Phase.AUTHORITY_CONFLICT.next());
        assertEquals(Phase.THE_THING_THAT_NEVER_WAS, Phase.IMPOSSIBLE_RECORD.next());
        assertEquals(Phase.FINAL_OMISSION, Phase.THE_THING_THAT_NEVER_WAS.next());
        assertEquals(Phase.FINAL_OMISSION, Phase.FINAL_OMISSION.next());
        assertEquals(Phase.RECOGNITION_FAILURE, Phase.of(-3));
        assertEquals(Phase.FINAL_OMISSION, Phase.of(99));
        assertEquals("THE THING THAT NEVER WAS", Phase.of(4).title);
    }

    @Test void floorsRiseThenFall() {
        assertEquals(0.75, AzrielRules.floorFraction(Phase.RECOGNITION_FAILURE), 1e-9);
        assertEquals(0.45, AzrielRules.floorFraction(Phase.AUTHORITY_CONFLICT), 1e-9);
        assertEquals(0.45, AzrielRules.floorFraction(Phase.IMPOSSIBLE_RECORD), 1e-9);
        assertEquals(0.20, AzrielRules.floorFraction(Phase.THE_THING_THAT_NEVER_WAS), 1e-9);
        assertEquals(0.0, AzrielRules.floorFraction(Phase.FINAL_OMISSION), 1e-9);
    }

    @Test void noPhaseCanBeSkippedByRawDamage() {
        // 600 max health: a huge hit stops exactly at each phase's floor
        assertEquals(150.0, AzrielRules.allowedDamage(600, 600, 10_000, Phase.RECOGNITION_FAILURE), 1e-9);   // 600 -> 450 (75%)
        assertEquals(180.0, AzrielRules.allowedDamage(450, 600, 10_000, Phase.AUTHORITY_CONFLICT), 1e-9);    // 450 -> 270 (45%)
        assertEquals(150.0, AzrielRules.allowedDamage(270, 600, 10_000, Phase.THE_THING_THAT_NEVER_WAS), 1e-9); // 270 -> 120 (20%)
    }

    @Test void damageNeverNegativeAndNeverRaisesHealth() {
        assertEquals(0.0, AzrielRules.allowedDamage(100, 600, 50, Phase.RECOGNITION_FAILURE), 1e-9);   // already below the floor
        assertEquals(30.0, AzrielRules.allowedDamage(600, 600, 30, Phase.RECOGNITION_FAILURE), 1e-9);  // small hit passes unchanged
    }

    @Test void phaseThreeIsInvulnerable() {
        assertEquals(0.0, AzrielRules.allowedDamage(270, 600, 500, Phase.IMPOSSIBLE_RECORD), 1e-9);
    }

    @Test void finalPhaseCanFinishIt() {
        assertEquals(100.0, AzrielRules.allowedDamage(100, 600, 1000, Phase.FINAL_OMISSION), 1e-9);
    }

    @Test void floorAdvancesThePhase() {
        assertTrue(AzrielRules.reachesFloor(600, 600, 150, Phase.RECOGNITION_FAILURE));
        assertTrue(AzrielRules.reachesFloor(600, 600, 9999, Phase.RECOGNITION_FAILURE));
        assertFalse(AzrielRules.reachesFloor(600, 600, 100, Phase.RECOGNITION_FAILURE));
        assertFalse(AzrielRules.reachesFloor(270, 600, 9999, Phase.IMPOSSIBLE_RECORD));
        assertFalse(AzrielRules.reachesFloor(100, 600, 9999, Phase.FINAL_OMISSION));
    }

    @Test void resumingPicksTheRightPhase() {
        assertEquals(Phase.RECOGNITION_FAILURE, AzrielRules.initialPhase(1.0, false));
        assertEquals(Phase.AUTHORITY_CONFLICT, AzrielRules.initialPhase(0.6, false));
        assertEquals(Phase.IMPOSSIBLE_RECORD, AzrielRules.initialPhase(0.45, false));
        assertEquals(Phase.IMPOSSIBLE_RECORD, AzrielRules.initialPhase(0.3, false));    // never got to the final recognition
        assertEquals(Phase.THE_THING_THAT_NEVER_WAS, AzrielRules.initialPhase(0.3, true));
        assertEquals(Phase.FINAL_OMISSION, AzrielRules.initialPhase(0.2, true));
    }

    @Test void shieldIsBrokenByCombosAndWornByTheLegion() {
        assertEquals(0.9, AzrielRules.shieldReduction(0, false), 1e-9);
        assertTrue(AzrielRules.shieldReduction(2, false) < AzrielRules.shieldReduction(0, false));
        assertEquals(0.30, AzrielRules.shieldReduction(50, false), 1e-9);         // never below 30%
        assertEquals(0.0, AzrielRules.shieldReduction(0, true), 1e-9);
        assertEquals(0.9, AzrielRules.shieldReduction(-4, false), 1e-9);
    }

    @Test void phaseOneResistance() {
        assertTrue(AzrielRules.resistedInPhaseOne("perception", 0.99));
        assertTrue(AzrielRules.resistedInPhaseOne("omission", 0.99));
        assertTrue(AzrielRules.resistedInPhaseOne("nonexistence", 0.99));
        assertTrue(AzrielRules.resistedInPhaseOne("absence", 0.10));
        assertFalse(AzrielRules.resistedInPhaseOne("absence", 0.50));
    }

    @Test void adaptationCountersRepetitionOnly() {
        AzrielRules.Adaptation a = new AzrielRules.Adaptation(20_000, 3);
        assertFalse(a.shouldCounter("absence", 1000));
        assertFalse(a.shouldCounter("absence", 2000));
        assertFalse(a.shouldCounter("absence", 3000));
        assertTrue(a.shouldCounter("absence", 4000));            // fourth use inside the window is answered
        assertFalse(a.shouldCounter("denial", 4000));            // a different authority is fine
    }

    @Test void adaptationForgetsAfterTheWindow() {
        AzrielRules.Adaptation a = new AzrielRules.Adaptation(20_000, 3);
        for (int i = 0; i < 3; i++) a.shouldCounter("absence", i * 1000L);
        assertTrue(a.shouldCounter("absence", 5000));
        assertFalse(a.shouldCounter("absence", 30_000));         // the window has passed
        a.clear();
        assertFalse(a.shouldCounter("absence", 31_000));
    }
}
