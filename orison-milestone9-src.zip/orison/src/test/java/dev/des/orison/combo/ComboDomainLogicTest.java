package dev.des.orison.combo;

import dev.des.orison.domain.DomainRules;
import dev.des.orison.domain.DomainType;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ComboDomainLogicTest {
    private final List<ComboDef> combos = ComboCatalog.defaults();

    private static ComboLogic.Cast cast(String id, long at, UUID t) { return new ComboLogic.Cast(id, at, t); }

    @Test void allTenRequiredCombosExist() {
        assertEquals(10, combos.size());
        Set<String> pairs = new HashSet<>();
        for (ComboDef c : combos) pairs.add(c.first() + "+" + c.second());
        for (String p : List.of("step_between+omission_form", "invalid+return_to_sender", "collapse_the_distance+nothing_remains",
                "unseen+missing_frame", "hunt_mark+awaken", "kingdom_of_nothing+awaken_all", "debt_collector+everything_comes_back",
                "future_fracture+not_today", "sovereign_command+one_authority", "contradiction+beyond_existence")) {
            assertTrue(pairs.contains(p), "missing combo " + p);
        }
    }

    @Test void idsUniqueAndEachSecondAbilityOnce() {
        Set<String> ids = new HashSet<>(), seconds = new HashSet<>();
        for (ComboDef c : combos) { assertTrue(ids.add(c.id())); assertTrue(seconds.add(c.second()), "second ability reused: " + c.second()); }
    }

    @Test void matchesInOrderWithinWindow() {
        List<ComboLogic.Cast> h = new ArrayList<>(List.of(cast("invalid", 1000, null)));
        ComboDef c = ComboLogic.find(combos, h, "return_to_sender", null, 4000);
        assertNotNull(c);
        assertEquals("perfect_return", c.id());
    }

    @Test void noMatchWhenTooLate() {
        List<ComboLogic.Cast> h = new ArrayList<>(List.of(cast("invalid", 1000, null)));
        assertNull(ComboLogic.find(combos, h, "return_to_sender", null, 7001));    // window is 6s
        assertNotNull(ComboLogic.find(combos, h, "return_to_sender", null, 7000));
    }

    @Test void orderMatters() {
        List<ComboLogic.Cast> h = new ArrayList<>(List.of(cast("return_to_sender", 1000, null)));
        assertNull(ComboLogic.find(combos, h, "invalid", null, 2000));
    }

    @Test void sameTargetRequiredWhereSpecified() {
        UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        List<ComboLogic.Cast> h = new ArrayList<>(List.of(cast("collapse_the_distance", 1000, a)));
        assertNotNull(ComboLogic.find(combos, h, "nothing_remains", a, 2000));
        assertNull(ComboLogic.find(combos, h, "nothing_remains", b, 2000));
        assertNull(ComboLogic.find(combos, h, "nothing_remains", null, 2000));
    }

    @Test void targetIsIgnoredWhereNotRequired() {
        List<ComboLogic.Cast> h = new ArrayList<>(List.of(cast("step_between", 1000, null)));
        assertNotNull(ComboLogic.find(combos, h, "omission_form", UUID.randomUUID(), 2000));
    }

    @Test void unrelatedCastsDoNotMatch() {
        List<ComboLogic.Cast> h = new ArrayList<>(List.of(cast("unseen", 1000, null)));
        assertNull(ComboLogic.find(combos, h, "nothing_remains", null, 1500));
        assertNull(ComboLogic.find(combos, new ArrayList<>(), "missing_frame", null, 1500));
    }

    @Test void newestFirstCastIsTheOneChecked() {
        List<ComboLogic.Cast> h = new ArrayList<>(List.of(cast("unseen", 0, null), cast("unseen", 9000, null)));
        assertNotNull(ComboLogic.find(combos, h, "missing_frame", null, 10000));   // old one is stale, newest is fresh
    }

    @Test void historyPrunes() {
        List<ComboLogic.Cast> h = new ArrayList<>();
        for (int i = 0; i < 50; i++) h.add(cast("x", i * 1000L, null));
        ComboLogic.prune(h, 50_000, 30_000, 16);
        assertTrue(h.size() <= 16);
        assertTrue(h.stream().allMatch(c -> 50_000 - c.atMillis() <= 30_000));
    }

    @Test void windowsAreReasonable() {
        for (ComboDef c : combos) { assertTrue(c.windowSeconds() >= 3 && c.windowSeconds() <= 30, c.id()); assertFalse(c.hint().isEmpty()); }
    }

    @Test void kingdomModifiersOnlyApplyInsideAndOnlyToKingdom() {
        assertEquals(0.7, DomainRules.cooldownMultiplier(DomainType.KINGDOM_OF_NOTHING, true), 1e-9);
        assertEquals(1.0, DomainRules.cooldownMultiplier(DomainType.KINGDOM_OF_NOTHING, false), 1e-9);
        assertEquals(1.0, DomainRules.cooldownMultiplier(DomainType.THE_STILL_WORLD, true), 1e-9);
        assertTrue(DomainRules.claimChanceBonus(DomainType.KINGDOM_OF_NOTHING, true) > 0);
        assertEquals(0.0, DomainRules.claimChanceBonus(DomainType.KINGDOM_OF_NOTHING, false), 1e-9);
        assertEquals(0.0, DomainRules.paradoxPerDefeat(DomainType.THE_STILL_WORLD, true), 1e-9);
    }

    @Test void domainContainmentIsASphere() {
        assertTrue(DomainRules.inside(0, 64, 0, 10, 64, 0, 18));
        assertTrue(DomainRules.inside(0, 64, 0, 18, 64, 0, 18));
        assertFalse(DomainRules.inside(0, 64, 0, 18.1, 64, 0, 18));
        assertFalse(DomainRules.inside(0, 64, 0, 12, 76, 0, 15));       // 12 across + 12 up is ~17 away
    }

    @Test void domainDurationClamped() {
        assertEquals(20, DomainRules.clampDuration(5, 20, 45), 1e-9);
        assertEquals(45, DomainRules.clampDuration(300, 20, 45), 1e-9);
        assertEquals(30, DomainRules.clampDuration(30, 20, 45), 1e-9);
    }

    @Test void domainTypesMapToAbilities() {
        assertEquals(DomainType.KINGDOM_OF_NOTHING, DomainType.ofAbility("kingdom_of_nothing"));
        assertEquals(DomainType.THE_STILL_WORLD, DomainType.ofAbility("the_still_world"));
        assertNull(DomainType.ofAbility("unseen"));
    }
}
