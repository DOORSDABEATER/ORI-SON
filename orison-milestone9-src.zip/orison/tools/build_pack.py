#!/usr/bin/env python3
"""
Generates the ORISON VFX resource pack (textures, 3D models, item-model definitions, overlay font).
Usage:  python3 tools/build_pack.py [outdir]     (needs Pillow + numpy)
All art is procedural and deterministic (fixed seeds). Alpha is strictly binary (0/255) with ordered
dithering for soft edges, so it renders correctly whether item displays use cutout or translucent layers.
Palette: absolute black, pure white, silver.
"""
import json, math, os, random, shutil, sys, zipfile
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sounds
from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "resourcepack"
NS = "orison"
BLACK, WHITE, SILVER, GREY = (8, 8, 10), (250, 250, 255), (192, 196, 204), (96, 98, 104)
BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0

def bayer_mask(h, w):
    return np.tile(BAYER, (h // 4 + 1, w // 4 + 1))[:h, :w]

def dither(alpha_float):
    """alpha in [0,1] -> binary alpha using an ordered dither."""
    h, w = alpha_float.shape
    return (alpha_float > bayer_mask(h, w)).astype(np.uint8) * 255

def canvas(w, h):
    return Image.new("RGBA", (w, h), (0, 0, 0, 0))

def binarize(img):
    a = np.array(img)
    a[..., 3] = np.where(a[..., 3] > 127, 255, 0)
    return Image.fromarray(a, "RGBA")

def save(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    binarize(img).save(path)

def paint(w, h, color_fn):
    """color_fn(x_grid, y_grid) -> (rgb array HxWx3, alpha float HxW in [0,1])"""
    ys, xs = np.mgrid[0:h, 0:w].astype(float)
    rgb, a = color_fn(xs, ys)
    out = np.zeros((h, w, 4), np.uint8)
    out[..., :3] = rgb.astype(np.uint8)
    out[..., 3] = dither(np.clip(a, 0, 1))
    return Image.fromarray(out, "RGBA")

# ------------------------------------------------------------------ textures
def tex_fracture(path):
    rnd = random.Random(7)
    img = canvas(128, 128)
    d = ImageDraw.Draw(img)
    segs = []
    def crack(x, y, ang, length, depth):
        for _ in range(length):
            step = rnd.uniform(5, 10)
            ang += rnd.uniform(-0.55, 0.55)
            nx, ny = x + math.cos(ang) * step, y + math.sin(ang) * step
            segs.append(((x, y), (nx, ny), max(1, 5 - depth * 2)))
            if depth < 2 and rnd.random() < 0.22:
                crack(nx, ny, ang + rnd.choice([-1, 1]) * rnd.uniform(0.5, 1.1), rnd.randint(2, 5), depth + 1)
            x, y = nx, ny
            if not (4 < x < 124 and 4 < y < 124):
                break
    for i in range(8):
        crack(64, 64, i * math.pi / 4 + rnd.uniform(-0.25, 0.25), rnd.randint(5, 8), 0)
    for a, b, w in segs: d.line([a, b], fill=BLACK + (255,), width=w + 2)
    for a, b, w in segs: d.line([a, b], fill=WHITE + (255,), width=max(1, w - 2))
    for _ in range(14):  # chipped fragments
        cx, cy = rnd.uniform(14, 114), rnd.uniform(14, 114)
        r = rnd.uniform(1.5, 3.5)
        d.polygon([(cx + r * math.cos(t), cy + r * math.sin(t)) for t in (0.2, 1.9, 3.6, 5.0)],
                  fill=(SILVER if rnd.random() < 0.5 else BLACK) + (255,))
    save(img, path)

def tex_ring(path):
    def fn(x, y):
        r = np.hypot(x - 63.5, y - 63.5) / 64.0
        ang = np.arctan2(y - 63.5, x - 63.5)
        gaps = (np.sin(ang * 5 + 1.3) + np.sin(ang * 11)) > 1.55          # fractured breaks
        a = np.zeros_like(r)
        rgb = np.zeros(r.shape + (3,))
        black = (r > 0.74) & (r < 0.94)
        white = (r > 0.82) & (r < 0.87)
        glow = (r >= 0.94) & (r < 1.0)
        a[black] = 1; rgb[black] = BLACK
        a[white] = 1; rgb[white] = WHITE
        a[glow] = (1.0 - (r[glow] - 0.94) / 0.06) * 0.8; rgb[glow] = SILVER
        a[gaps & (r > 0.7)] = 0
        return rgb, a
    save(paint(128, 128, fn), path)

def tex_shock(path):
    rnd = np.random.RandomState(3)
    wob = rnd.rand(360) * 0.04
    def fn(x, y):
        r = np.hypot(x - 63.5, y - 63.5) / 64.0
        ang = np.arctan2(y - 63.5, x - 63.5)
        idx = ((ang + np.pi) / (2 * np.pi) * 359).astype(int)
        r = r + wob[idx] - 0.02
        a = np.zeros_like(r); rgb = np.zeros(r.shape + (3,))
        trail = (r > 0.55) & (r < 0.93)
        a[trail] = ((r[trail] - 0.55) / 0.38) ** 2 * 0.85; rgb[trail] = SILVER
        edge = (r >= 0.93) & (r < 0.97)
        a[edge] = 1; rgb[edge] = WHITE
        out = (r >= 0.97) & (r < 1.0)
        a[out] = 1; rgb[out] = BLACK
        return rgb, a
    save(paint(128, 128, fn), path)

def tex_rift(path):
    W, H = 64, 256
    rnd = np.random.RandomState(11)
    centre = 32 + np.cumsum(rnd.randn(H)) * 0.9
    centre = np.clip(centre - (centre.mean() - 32), 20, 44)
    def fn(x, y):
        yy = y.astype(int)
        taper = np.clip(np.minimum(y, H - 1 - y) / 55.0, 0, 1)
        dist = np.abs(x - centre[yy])
        half = 11 * taper
        a = np.zeros_like(x); rgb = np.zeros(x.shape + (3,))
        glow = (dist < half + 9 * taper)
        a[glow] = np.clip(1 - (dist[glow] - half[glow]) / (9 * taper[glow] + 1e-3), 0, 1) * 0.7; rgb[glow] = SILVER
        edge = dist < half
        a[edge] = 1; rgb[edge] = BLACK
        core = dist < half * 0.35
        rgb[core] = WHITE
        return rgb, a
    save(paint(W, H, fn), path)

def tex_cut(path):
    W, H = 256, 64
    def fn(x, y):
        u = (x - 127.5) / 128.0
        taper = np.clip(1 - np.abs(u) ** 1.6, 0, 1)
        half = 14 * taper
        dist = np.abs(y - 31.5 - u * 6)
        a = np.zeros_like(x); rgb = np.zeros(x.shape + (3,))
        glow = dist < half + 8 * taper
        a[glow] = np.clip(1 - (dist[glow] - half[glow]) / (8 * taper[glow] + 1e-3), 0, 1) * 0.6; rgb[glow] = SILVER
        edge = dist < half
        a[edge] = 1; rgb[edge] = BLACK
        core = dist < half * 0.3
        rgb[core] = WHITE
        return rgb, a
    save(paint(W, H, fn), path)

def tex_gate(path):
    def fn(x, y):
        nx, ny = (x - 63.5) / 64.0 / 0.62, (y - 63.5) / 64.0 / 0.96
        r = np.hypot(nx, ny)
        ang = np.arctan2(ny, nx)
        a = np.zeros_like(r); rgb = np.zeros(r.shape + (3,))
        inner = r < 0.86
        a[inner] = 0.55; rgb[inner] = BLACK                                    # void interior (dithered)
        swirl = inner & (np.sin(ang * 3 + r * 14) > 0.8)
        a[swirl] = 1; rgb[swirl] = WHITE
        rim = (r >= 0.86) & (r < 1.0)
        a[rim] = 1; rgb[rim] = BLACK
        rimw = (r >= 0.92) & (r < 0.96)
        rgb[rimw] = WHITE
        return rgb, a
    save(paint(128, 128, fn), path)

def tex_beam(path):
    W, H = 64, 128
    def fn(x, y):
        dx = np.abs(x - 31.5) / 32.0
        fade = np.clip(y / H, 0, 1)                   # transparent toward the top (y=0)
        a = np.zeros_like(x); rgb = np.zeros(x.shape + (3,))
        glow = dx < 0.9 * (0.4 + 0.6 * fade)
        a[glow] = (1 - dx[glow]) * fade[glow] * 0.8; rgb[glow] = SILVER
        core = dx < 0.16 * (0.4 + 0.6 * fade)
        a[core] = fade[core]; rgb[core] = WHITE
        edge = (dx > 0.14) & (dx < 0.26) & (fade > 0.3)
        a[edge] = np.maximum(a[edge], 0.9 * fade[edge]); rgb[edge] = BLACK
        return rgb, a
    save(paint(W, H, fn), path)

def tex_shield(path):
    def fn(x, y):
        # hex lattice
        s = 16.0
        px, py = x / s, y / (s * 0.866)
        row = np.floor(py)
        off = (row % 2) * 0.5
        fx, fy = (px + off) % 1.0 - 0.5, (py % 1.0) - 0.5
        hexd = np.maximum(np.abs(fx) * 0.866 + np.abs(fy) * 0.5, np.abs(fy))
        a = np.zeros_like(x); rgb = np.zeros(x.shape + (3,))
        line = hexd > 0.40
        a[line] = 1; rgb[line] = BLACK
        inner = hexd > 0.44
        rgb[inner] = WHITE
        fill = ~line
        a[fill] = 0.18; rgb[fill] = SILVER
        edge = np.hypot(x - 63.5, y - 63.5) / 64.0
        rim = (np.minimum(np.minimum(x, 127 - x), np.minimum(y, 127 - y)) < 4)
        a[rim] = 1; rgb[rim] = WHITE
        return rgb, a
    save(paint(128, 128, fn), path)

def tex_shard(path):
    img = canvas(32, 32)
    d = ImageDraw.Draw(img)
    pal = [SILVER, (30, 30, 36), WHITE, GREY]
    rnd = random.Random(5)
    for i in range(0, 32, 8):
        for j in range(0, 32, 8):
            c = pal[rnd.randrange(len(pal))]
            d.polygon([(i, j), (i + 8, j), (i, j + 8)], fill=c + (255,))
            d.polygon([(i + 8, j + 8), (i + 8, j), (i, j + 8)], fill=pal[(rnd.randrange(len(pal)))] + (255,))
    d.rectangle([0, 0, 31, 31], outline=WHITE + (255,))
    save(img, path)

def tex_silhouette(path):
    W = H = 32
    def fn(x, y):
        checker = ((x.astype(int) + y.astype(int)) % 2 == 0)
        scan = (y.astype(int) % 6 == 0)
        a = np.where(checker | scan, 1.0, 0.0)
        rgb = np.zeros(x.shape + (3,))
        rgb[:] = (22, 22, 26)
        rgb[scan] = SILVER
        return rgb, a
    img = paint(W, H, fn)
    arr = np.array(img); arr[..., 3] = np.where(arr[..., 3] > 0, 255, 0)
    # dither() already produced binary alpha; recompute explicitly from the pattern for crispness
    ys, xs = np.mgrid[0:H, 0:W]
    keep = ((xs + ys) % 2 == 0) | (ys % 6 == 0)
    arr[..., 3] = np.where(keep, 255, 0)
    save(Image.fromarray(arr, "RGBA"), path)

def tex_eye(path):
    def fn(x, y):
        nx, ny = (x - 15.5) / 16.0, (y - 7.5) / 8.0
        r = np.hypot(nx, ny)
        a = np.clip(1.3 - r * 1.3, 0, 1)
        a = np.where(r < 0.55, 1.0, a)
        rgb = np.zeros(x.shape + (3,)); rgb[:] = WHITE
        return rgb, a
    save(paint(32, 16, fn), path)

def tex_overlay_white(path):
    save(Image.new("RGBA", (256, 256), WHITE + (255,)), path)

def tex_overlay_vignette(path):
    def fn(x, y):
        r = np.hypot(x - 127.5, y - 127.5) / 181.0
        a = np.clip((r - 0.55) / 0.45, 0, 1) ** 1.2
        rgb = np.zeros(x.shape + (3,)); rgb[:] = BLACK
        return rgb, a
    img = paint(256, 256, fn)
    # the screen overlay can use real alpha, so rebuild it smooth
    ys, xs = np.mgrid[0:256, 0:256].astype(float)
    r = np.hypot(xs - 127.5, ys - 127.5) / 181.0
    a = (np.clip((r - 0.55) / 0.45, 0, 1) ** 1.2 * 255).astype(np.uint8)
    out = np.zeros((256, 256, 4), np.uint8); out[..., :3] = BLACK; out[..., 3] = a
    os.makedirs(os.path.dirname(path), exist_ok=True)
    Image.fromarray(out, "RGBA").save(path)

# ------------------------------------------------------------------ models
def face(tex="#0"): return {"uv": [0, 0, 16, 16], "texture": tex}
def box(frm, to, rot=None, faces=("north", "south", "east", "west", "up", "down")):
    e = {"from": frm, "to": to, "faces": {f: face() for f in faces}}
    if rot: e["rotation"] = {"origin": [8, 8, 8], "axis": rot[0], "angle": rot[1]}
    return e
def hplane(): return {"from": [0, 8, 0], "to": [16, 8, 16], "faces": {"up": face(), "down": face()}}
def vplane(rot=None):
    e = {"from": [0, 0, 8], "to": [16, 16, 8], "faces": {"north": face(), "south": face()}}
    if rot: e["rotation"] = {"origin": [8, 8, 8], "axis": "y", "angle": rot}
    return e
def xplane(): return {"from": [8, 0, 0], "to": [8, 16, 16], "faces": {"east": face(), "west": face()}}
def model(tex, elements): return {"textures": {"0": f"{NS}:vfx/{tex}", "particle": f"{NS}:vfx/{tex}"}, "elements": elements}

MODELS = {
    "fracture": ("fracture", [hplane()]),
    "ring": ("ring", [hplane()]),
    "shock": ("shock", [hplane()]),
    "rift": ("rift", [vplane()]),
    "cut": ("cut", [vplane()]),
    "gate": ("gate", [vplane()]),
    "beam": ("beam", [vplane(), xplane()]),
    "shield": ("shield", [vplane(45), vplane(-45), hplane()]),
    "shard_a": ("shard", [box([7, 1, 7.2], [9, 15, 8.8], ("z", 22.5))]),
    "shard_b": ("shard", [box([6.5, 0, 7.6], [9.5, 16, 8.4], ("y", 45)), box([6.5, 0, 7.6], [9.5, 16, 8.4], ("y", -45))]),
    "shard_c": ("shard", [box([4, 4, 4], [12, 12, 12], ("z", 45)), box([4, 4, 4], [12, 12, 12], ("x", 45))]),
    "shard_d": ("shard", [box([7, 0, 7], [9, 16, 9], ("z", 22.5)), box([7, 2, 7], [9, 14, 9], ("z", -22.5)), box([7.4, 3, 7.4], [8.6, 13, 8.6])]),
    # Standing figure: feet at model y=-8 (anchor the display at feet + 1.0 block).
    "silhouette": ("silhouette", [
        box([4, 16, 4], [12, 24, 12]), box([4, 4, 6], [12, 16, 10]),
        box([0, 4, 6], [4, 16, 10]), box([12, 4, 6], [16, 16, 10]),
        box([4, -8, 6], [8, 4, 10]), box([8, -8, 6], [12, 4, 10])]),
    # Two small bars; plane normal is the display's facing axis. Double sided.
    "eyes": ("eye", [
        {"from": [5, 8, 8], "to": [7.2, 9.6, 8], "faces": {"north": face(), "south": face()}},
        {"from": [8.8, 8, 8], "to": [11, 9.6, 8], "faces": {"north": face(), "south": face()}}]),
}

def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f: json.dump(obj, f, indent=1)

def build():
    if os.path.exists(OUT): shutil.rmtree(OUT)
    a = f"{OUT}/assets/{NS}"
    t = f"{a}/textures/vfx"
    tex_fracture(f"{t}/fracture.png"); tex_ring(f"{t}/ring.png"); tex_shock(f"{t}/shock.png")
    tex_rift(f"{t}/rift.png"); tex_cut(f"{t}/cut.png"); tex_gate(f"{t}/gate.png"); tex_beam(f"{t}/beam.png")
    tex_shield(f"{t}/shield.png"); tex_shard(f"{t}/shard.png"); tex_silhouette(f"{t}/silhouette.png"); tex_eye(f"{t}/eye.png")
    tex_overlay_white(f"{a}/textures/font/whiteout.png"); tex_overlay_vignette(f"{a}/textures/font/vignette.png")

    for name, (tex, elements) in MODELS.items():
        write_json(f"{a}/models/vfx/{name}.json", model(tex, elements))
        write_json(f"{a}/items/{name}.json", {"model": {"type": "minecraft:model", "model": f"{NS}:vfx/{name}"}})

    # Screen overlays: used as huge title glyphs. EXPERIMENTAL sizing: tune height/ascent to your GUI scale.
    write_json(f"{a}/font/overlay.json", {"providers": [
        {"type": "bitmap", "file": f"{NS}:font/whiteout.png", "ascent": 700, "height": 1400, "chars": ["\ue000"]},
        {"type": "bitmap", "file": f"{NS}:font/vignette.png", "ascent": 700, "height": 1400, "chars": ["\ue001"]}]})

    n_sounds = sounds.build(OUT, NS)

    write_json(f"{OUT}/pack.mcmeta", {"pack": {
        "description": "ORISON - The Thing That Never Existed (VFX)",
        "min_format": [88, 0], "max_format": [88, 0]}})
    with open(f"{OUT}/README.txt", "w") as f:
        f.write("ORISON VFX pack. Generated by tools/build_pack.py - edit the script, not the files.\n"
                "pack.mcmeta targets Minecraft 26.2 (format 88).\n")

    zpath = f"{OUT}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(OUT):
            for fn in sorted(files):
                full = os.path.join(root, fn)
                z.write(full, os.path.relpath(full, OUT))
    print("built", zpath, "with", len(MODELS), "models and", n_sounds, "sounds")

if __name__ == "__main__":
    build()
