#!/usr/bin/env python3
"""Decodes every shipped sound and checks it: mono 44.1k, sane duration, not silent, no clipping, no edge clicks.
Also checks sounds.json <-> files <-> lang subtitles. Exit 1 on any problem."""
import json, os, subprocess, sys
import numpy as np
root = sys.argv[1] if len(sys.argv) > 1 else "resourcepack"
ns = "orison"
base = f"{root}/assets/{ns}"
errors, rows = [], []

def decode(path):
    p = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", path, "-f", "f32le", "-ac", "1", "-ar", "44100", "-"], capture_output=True, check=True)
    return np.frombuffer(p.stdout, dtype=np.float32)

def info(path):
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=channels,sample_rate,codec_name", "-of", "json", path], capture_output=True, check=True)
    return json.loads(p.stdout)["streams"][0]

events = json.load(open(f"{base}/sounds.json"))
lang = json.load(open(f"{base}/lang/en_us.json"))
used = set()
for ev, d in events.items():
    if d.get("subtitle", "").replace("subtitles.", "subtitles.") not in lang: errors.append(f"{ev}: subtitle key missing in lang")
    for s in d["sounds"]:
        rel = s["name"].split(":")[1]
        path = f"{base}/sounds/{rel}.ogg"
        used.add(os.path.abspath(path))
        if not os.path.exists(path): errors.append(f"{ev}: missing file {rel}.ogg"); continue
        st = info(path)
        if st["codec_name"] != "vorbis" or st["channels"] != 1 or int(st["sample_rate"]) != 44100:
            errors.append(f"{rel}: expected mono 44.1k vorbis, got {st}")
        x = decode(path)
        dur = len(x) / 44100
        peak = 20 * np.log10(np.max(np.abs(x)) + 1e-9)
        rms = 20 * np.log10(np.sqrt(np.mean(x ** 2)) + 1e-9)
        edge = max(abs(float(x[0])), abs(float(x[-1])))
        rows.append((ev, dur, peak, rms))
        quiet_ok = ev.startswith("presence.idle") or ev.startswith("claim.unrecognized")
        if dur < 0.05 or dur > 12: errors.append(f"{ev}: duration {dur:.2f}s out of range")
        if peak > -0.5: errors.append(f"{ev}: clips (peak {peak:.1f} dBFS)")
        if rms < (-50 if quiet_ok else -38): errors.append(f"{ev}: too quiet (rms {rms:.1f} dBFS)")
        if edge > 0.02: errors.append(f"{ev}: edge click risk ({edge:.3f})")
        if not np.isfinite(x).all(): errors.append(f"{ev}: non-finite samples")
for r, _, fs in os.walk(f"{base}/sounds"):
    for f in fs:
        if os.path.abspath(os.path.join(r, f)) not in used: errors.append(f"orphan sound file {f}")
for k in lang:
    if k.replace("subtitles.orison.", "") not in events: errors.append(f"lang key without event: {k}")

print(f"{'event':32s} {'dur':>6s} {'peak':>7s} {'rms':>7s}")
for ev, dur, peak, rms in sorted(rows): print(f"{ev:32s} {dur:6.2f} {peak:7.1f} {rms:7.1f}")
print(f"\n{len(rows)} sounds audited")
print("AUDIO OK" if not errors else "AUDIO PROBLEMS")
for e in errors: print(" -", e)
sys.exit(1 if errors else 0)
