#!/usr/bin/env python3
"""Validates the ORISON pack: JSON parses, every reference resolves, textures are RGBA with binary alpha, no orphans."""
import json, os, sys
from PIL import Image
import numpy as np
root = sys.argv[1] if len(sys.argv) > 1 else "resourcepack"
errors, ns = [], "orison"
def j(p):
    try: return json.load(open(p))
    except Exception as e: errors.append(f"bad json {p}: {e}"); return None
mc = j(f"{root}/pack.mcmeta")
if mc and not ("min_format" in mc["pack"] and "max_format" in mc["pack"]): errors.append("pack.mcmeta missing min/max_format")
textures = {os.path.splitext(f)[0] for _, _, fs in os.walk(f"{root}/assets/{ns}/textures/vfx") for f in fs}
used_tex, used_models = set(), set()
for f in os.listdir(f"{root}/assets/{ns}/models/vfx"):
    m = j(f"{root}/assets/{ns}/models/vfx/{f}")
    if not m: continue
    for k, v in m["textures"].items():
        n = v.split("/")[-1]; used_tex.add(n)
        if n not in textures: errors.append(f"{f}: missing texture {v}")
    for e in m["elements"]:
        for fc in e["faces"].values():
            if fc["texture"].lstrip("#") not in m["textures"]: errors.append(f"{f}: face uses undefined texture {fc['texture']}")
        for a, b in zip(e["from"], e["to"]):
            if not (-16 <= a <= 32 and -16 <= b <= 32): errors.append(f"{f}: element outside -16..32")
        r = e.get("rotation")
        if r and (r["angle"] not in (-45, -22.5, 0, 22.5, 45) or r["axis"] not in "xyz"): errors.append(f"{f}: invalid rotation {r}")
for f in os.listdir(f"{root}/assets/{ns}/items"):
    it = j(f"{root}/assets/{ns}/items/{f}")
    if not it: continue
    ref = it["model"]["model"]
    path = f"{root}/assets/{ns}/models/{ref.split(':')[1]}.json"
    used_models.add(path)
    if not os.path.exists(path): errors.append(f"{f}: missing model {ref}")
for fnt in ("overlay",):
    d = j(f"{root}/assets/{ns}/font/{fnt}.json")
    for p in (d or {}).get("providers", []):
        if not os.path.exists(f"{root}/assets/{ns}/textures/{p['file'].split(':')[1].replace('font/','font/')}"):
            errors.append(f"font: missing {p['file']}")
for r, _, fs in os.walk(f"{root}/assets/{ns}/textures"):
    for f in fs:
        im = Image.open(os.path.join(r, f))
        if im.mode != "RGBA": errors.append(f"{f}: not RGBA")
        if "font" not in r:
            a = np.array(im)[..., 3]
            if not np.isin(a, (0, 255)).all(): errors.append(f"{f}: non-binary alpha")
            if a.max() == 0: errors.append(f"{f}: fully transparent")
for t in textures - used_tex: errors.append(f"orphan texture {t}")
print("PACK VALID" if not errors else "PACK INVALID")
for e in errors: print(" -", e)
sys.exit(1 if errors else 0)
