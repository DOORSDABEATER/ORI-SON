#!/usr/bin/env python3
"""
Procedural sound design for ORISON. Deterministic (fixed seeds). Palette: cold, glassy, sub-bass, reversed swells, detuned
drones, no melodic-fantasy timbres. Each Authority has its own signature recipe. Output: mono 44.1 kHz Ogg Vorbis.
Needs numpy, scipy and ffmpeg (libvorbis).
"""
import json, os, subprocess, tempfile
import numpy as np
import scipy.signal as sg
import scipy.io.wavfile as wf

SR = 44100
TAU = 2 * np.pi

def N(d): return int(d * SR)
def rs(seed): return np.random.RandomState(seed)
def noise(d, seed): return rs(seed).randn(N(d))
def _sos(kind, fc, order=4):
    fc = np.clip(fc, 20, SR * 0.45)
    return sg.butter(order, fc, btype=kind, fs=SR, output="sos")
def lp(x, fc, order=4): return sg.sosfilt(_sos("lowpass", fc, order), x)
def hp(x, fc, order=4): return sg.sosfilt(_sos("highpass", fc, order), x)
def bp(x, lo, hi, order=2): return sg.sosfilt(sg.butter(order, [max(20, lo), min(hi, SR * 0.45)], btype="bandpass", fs=SR, output="sos"), x)
def T(n): return np.arange(n) / SR

def env_exp(n, tau, attack=0.002):
    t = T(n)
    return np.exp(-t / tau) * np.minimum(1.0, t / max(attack, 1e-4))
def swell(n, curve=2.0): return np.linspace(0, 1, n) ** curve
def tone(f, d, phase0=0.0):
    n = N(d)
    f = np.full(n, float(f)) if np.isscalar(f) else np.asarray(f, float)
    return np.sin(phase0 + TAU * np.cumsum(f) / SR)
def sweep(f0, f1, d, power=1.0):
    n = N(d)
    return f0 + (f1 - f0) * (np.arange(n) / n) ** power
def saw(f, d):
    n = N(d)
    f = np.full(n, float(f)) if np.isscalar(f) else np.asarray(f, float)
    return sg.sawtooth(TAU * np.cumsum(f) / SR)
def fm(f, ratio, index, d, tau):
    n = N(d); t = T(n); e = np.exp(-t / tau)
    return np.sin(TAU * f * t + index * e * np.sin(TAU * f * ratio * t)) * e
def reverse(x): return x[::-1].copy()

def reverb(x, rt=0.8, wet=0.3, seed=1):
    ir = noise(rt, seed) * np.exp(-T(N(rt)) / (rt / 4.0))
    ir = lp(ir, 6000) / (np.sqrt(np.sum(ir ** 2)) + 1e-9)
    y = sg.fftconvolve(x, ir)
    out = np.zeros(len(y)); out[:len(x)] += x * (1 - wet)
    return out + y * wet * 2.0

def bitcrush(x, bits=6, hold=4):
    y = np.repeat(x[::hold], hold)[:len(x)]
    q = 2 ** (bits - 1)
    return np.round(y * q) / q

def mix(parts, total=None):
    total = total or max(int(o * SR) + len(x) for x, o, g in parts)
    out = np.zeros(total)
    for x, off, g in parts:
        s = int(off * SR)
        e = min(total, s + len(x))
        if e > s: out[s:e] += x[:e - s] * g
    return out

def finish(x, peak_db=-3.0, fade_in=0.003, fade_out=0.03):
    x = np.nan_to_num(np.asarray(x, float))
    x = x - np.mean(x)
    p = np.max(np.abs(x)) + 1e-9
    x = x / p * (10 ** (peak_db / 20))
    fi, fo = max(1, N(fade_in)), min(len(x) // 2, max(1, N(fade_out)))
    x[:fi] *= np.linspace(0, 1, fi)
    x[-fo:] *= np.linspace(1, 0, fo)
    return x.astype(np.float32)

# ------------------------------------------------------------------ recipes
def step(tier):
    if tier == 1:   # absence: dry tick that is erased backwards
        tick = bp(noise(0.12, 1), 1800, 5200) * env_exp(N(0.12), 0.02)
        ghost = reverse(bp(noise(0.12, 2), 800, 3000) * env_exp(N(0.12), 0.03)) * 0.25
        return finish(mix([(tick, 0.0, 1), (ghost, 0.0, 1), (tone(90, 0.1) * env_exp(N(0.1), 0.03), 0, 0.5)]), -12)
    if tier == 2:   # sovereign: glassy ping + tick
        ping = tone(2350, 0.25) * env_exp(N(0.25), 0.07)
        return finish(mix([(ping, 0, 0.5), (bp(noise(0.1, 3), 2500, 7000) * env_exp(N(0.1), 0.015), 0, 0.8)]), -11)
    if tier == 3:   # unwritten: reversed swell into a click
        sw = reverse(bp(noise(0.22, 4), 600, 4000) * env_exp(N(0.22), 0.06))
        return finish(mix([(sw, 0, 0.7), (tone(60, 0.2) * env_exp(N(0.2), 0.05), 0.12, 0.6),
                           (hp(noise(0.05, 5), 3000) * env_exp(N(0.05), 0.01), 0.2, 0.8)]), -10)
    x = hp(noise(0.3, 6), 1500) * env_exp(N(0.3), 0.04)   # beyond existence: a crack in space
    return finish(reverb(mix([(x, 0, 0.9), (tone(sweep(110, 40, 0.3, 0.5), 0.3) * env_exp(N(0.3), 0.1), 0, 0.8),
                              (tone(3100, 0.4) * env_exp(N(0.4), 0.1), 0.02, 0.18)]), 0.5, 0.35, 7), -9)

def land():
    return finish(reverb(mix([(tone(sweep(90, 38, 0.4, 0.4), 0.4) * env_exp(N(0.4), 0.12), 0, 1),
                              (hp(noise(0.25, 8), 1200) * env_exp(N(0.25), 0.04), 0, 0.5),
                              (reverse(tone(2800, 0.3) * env_exp(N(0.3), 0.08)), 0.0, 0.25)]), 0.6, 0.3, 9), -6)

def idle():
    s = (tone(3200, 0.7) + tone(3217, 0.7)) * np.sin(TAU * 9 * T(N(0.7)))
    return finish(s * np.sin(np.pi * np.linspace(0, 1, N(0.7))) ** 2, -22)

def cut():
    sw = bp(noise(0.28, 10), 800, 9000)
    sw = sw * np.sin(np.pi * np.linspace(0, 1, len(sw))) ** 1.5
    ring = tone(3100, 0.5) * env_exp(N(0.5), 0.12) + 0.5 * tone(4650, 0.5) * env_exp(N(0.5), 0.09)
    return finish(mix([(sw, 0, 1), (ring, 0.12, 0.4)]), -5)

def negate():
    shards = hp(noise(0.5, 11), 3500) * env_exp(N(0.5), 0.07)
    pings = sum(tone(f, 0.6) * env_exp(N(0.6), 0.15) for f in (2093, 2793, 3729, 5000))
    return finish(reverb(mix([(shards, 0, 1), (pings, 0.01, 0.15), (tone(70, 0.3) * env_exp(N(0.3), 0.08), 0, 0.5)]), 0.5, 0.3, 12), -5)

def fail():
    return finish(mix([(tone(sweep(120, 70, 0.25), 0.25) * env_exp(N(0.25), 0.07), 0, 1),
                       (lp(noise(0.2, 13), 700) * env_exp(N(0.2), 0.05), 0, 0.5)]), -12)

# --- Authorities: one signature each
def auth_absence():   # a presence being withdrawn
    sw = reverse(bp(noise(1.0, 20), 300, 6000) * env_exp(N(1.0), 0.25))
    drop = tone(sweep(2400, 300, 0.9, 0.5), 0.9) * np.linspace(1, 0, N(0.9)) ** 2
    return finish(reverb(mix([(sw, 0, 0.8), (drop, 0.1, 0.35)]), 0.9, 0.35, 21), -5)

def auth_denial():    # a hard refusal: click, buzz, cut-off
    buzz = (saw(147, 0.35) + saw(207.65, 0.35)) * 0.4
    cutoff = np.ones(len(buzz)); fade = N(0.05); cutoff[-fade:] = np.linspace(1, 0, fade)
    buzz = lp(buzz, 2500) * cutoff
    click = hp(noise(0.02, 22), 2000) * env_exp(N(0.02), 0.004)
    return finish(mix([(click, 0, 1), (buzz, 0.01, 0.6)]), -5)

def auth_omission():  # something drains away
    n = lp(noise(1.1, 23), 6000) * np.linspace(1, 0, N(1.1)) ** 1.5
    n = sg.sosfilt(_sos("lowpass", 800), n)
    return finish(mix([(n, 0, 1), (tone(sweep(520, 70, 1.0, 0.7), 1.0) * np.linspace(1, 0, N(1.0)), 0, 0.5)]), -5)

def auth_reckoning(): # a debt returned: bell, delayed echoes coming back louder
    b = fm(330, 1.41, 3.0, 0.9, 0.35)
    return finish(mix([(b, 0, 0.6), (b, 0.28, 0.5), (b, 0.52, 0.7), (reverse(lp(b, 2000)), 0.0, 0.2)]), -5)

def auth_unwritten(): # whiteout: wash then reversed reverb tail
    wash = hp(noise(1.2, 24), 500) * swell(N(1.2), 3.0)
    tail = reverse(reverb(np.concatenate([bp(noise(0.3, 25), 800, 7000) * env_exp(N(0.3), 0.08), np.zeros(N(0.1))]), 0.8, 0.9, 26))
    return finish(mix([(wash, 0, 0.5), (tail, 0.55, 0.8)]), -5)

def auth_nonexistence(): # sub drop, a gap of silence, a faint tone that should not be there
    drop = tone(sweep(120, 28, 0.7, 0.6), 0.7) * env_exp(N(0.7), 0.35)
    ghost = tone(5200, 0.8) * np.sin(np.pi * np.linspace(0, 1, N(0.8))) ** 3
    return finish(mix([(drop, 0, 1), (ghost, 1.0, 0.12)]), -5)

def auth_reclamation(): # detuned pad swell: something coming back
    f = 110.0
    pad = sum(saw(f * r * (1 + d), 1.4) for r, d in [(1, 0), (1, 0.006), (1.5, -0.004), (2, 0.003), (2.52, 0.008)])
    tailenv = np.ones(len(pad)); tailenv[-N(0.2):] = np.linspace(1, 0, N(0.2))
    pad = lp(pad, 1800) * swell(len(pad), 1.6) * tailenv
    return finish(reverb(pad, 1.0, 0.3, 27), -5)

def auth_dominion():  # a low command: slow stacked unison
    f = 73.4
    horn = sum(saw(f * (1 + d), 1.2) for d in (0, 0.004, -0.004, 0.009))
    horn = lp(horn, 900) * np.minimum(1, T(N(1.2)) / 0.35) * np.exp(-T(N(1.2)) / 0.9)
    return finish(mix([(horn, 0, 1), (hp(noise(0.05, 28), 1500) * env_exp(N(0.05), 0.01), 0, 0.5)]), -5)

def auth_perception(): # sonar ping and shimmer
    ping = tone(1760, 0.8) * env_exp(N(0.8), 0.18)
    shim = sum(tone(f, 1.0) * env_exp(N(1.0), 0.4) for f in (3520, 4435, 5274)) * np.sin(TAU * 7 * T(N(1.0)))
    return finish(reverb(mix([(ping, 0, 0.8), (shim, 0.15, 0.12)]), 0.9, 0.35, 29), -5)

def auth_transcendence(): # layered rising drone, long
    d = 1.8
    drone = (tone(sweep(55, 110, d, 2.0), d) + 0.5 * tone(sweep(110, 220, d, 2.0), d)) * swell(N(d), 1.5)
    sh = hp(noise(d, 30), 4000) * swell(N(d), 2.5) * 0.4
    hit = tone(sweep(90, 35, 0.5, 0.5), 0.5) * env_exp(N(0.5), 0.2)
    return finish(reverb(mix([(drone, 0, 0.8), (sh, 0, 0.5), (hit, d - 0.05, 1.0)]), 1.2, 0.35, 31), -4)

AUTHORITY = {"absence": auth_absence, "denial": auth_denial, "omission": auth_omission, "reckoning": auth_reckoning,
             "the_unwritten": auth_unwritten, "nonexistence": auth_nonexistence, "reclamation": auth_reclamation,
             "dominion": auth_dominion, "perception": auth_perception, "transcendence": auth_transcendence}

def transform(level):
    d = [0, 1.6, 2.4, 3.2, 4.2][level]
    layers = [(tone(sweep(50 + 10 * level, 100 + 40 * level, d, 2.0), d) * swell(N(d), 1.6), 0, 0.7),
              (hp(noise(d, 40 + level), 3000 + 800 * level) * swell(N(d), 2.5), 0, 0.35)]
    for k in range(level):   # more shimmer voices at higher levels
        f = 880 * (1.5 ** k)
        layers.append((tone(f, d * 0.7) * swell(N(d * 0.7), 2.0) * np.sin(TAU * (5 + k) * T(N(d * 0.7))) ** 2, d * 0.3, 0.12))
    hit = mix([(tone(sweep(100, 32, 0.8, 0.5), 0.8) * env_exp(N(0.8), 0.3), 0, 1.0),
               (hp(noise(0.3, 50 + level), 800) * env_exp(N(0.3), 0.08), 0, 0.5)])
    layers.append((hit, d - 0.1, 0.9 + 0.1 * level))
    if level == 4:
        layers.append((reverse(reverb(tone(440, 0.4) * env_exp(N(0.4), 0.1), 1.0, 0.9, 51)), d - 1.0, 0.3))
    return finish(reverb(mix(layers), 1.0, 0.25, 52), -3)

def transform_end():
    return finish(reverse(reverb(tone(sweep(200, 60, 0.5, 0.5), 0.5) * env_exp(N(0.5), 0.15), 0.9, 0.5, 53)), -8)

def contradiction():
    a = tone(220, 1.2) + tone(227.5, 1.2) + 0.5 * tone(311.1, 1.2)
    gate = (np.sin(TAU * 11 * T(N(1.2))) > -0.2).astype(float)
    return finish(mix([(a * gate * np.minimum(1, T(N(1.2)) / 0.15) * np.exp(-T(N(1.2)) / 0.8), 0, 0.6),
                       (hp(noise(0.3, 54), 2000) * env_exp(N(0.3), 0.08), 0, 0.5)]), -6)

def echo_emerge():
    sw = reverse(lp(noise(0.9, 60), 2500) * env_exp(N(0.9), 0.3))
    boom = tone(sweep(130, 45, 0.7, 0.5), 0.7) * env_exp(N(0.7), 0.3)
    choir = lp(sum(saw(220 * (1 + d), 1.3) for d in (0, 0.007, -0.006)), 1400) * np.sin(np.pi * np.linspace(0, 1, N(1.3))) ** 2
    return finish(reverb(mix([(sw, 0, 0.7), (boom, 0.85, 1.0), (choir, 0.6, 0.25)]), 1.0, 0.3, 61), -4)

def echo_recall():
    return finish(reverb(mix([(tone(sweep(900, 90, 0.8, 0.6), 0.8) * env_exp(N(0.8), 0.5), 0, 0.6),
                              (reverse(bp(noise(0.7, 62), 500, 5000) * env_exp(N(0.7), 0.2)), 0.1, 0.5)]), 0.8, 0.3, 63), -6)

def echo_down():
    return finish(reverb(mix([(sum(saw(f, 0.9) for f in (82.4, 83.0, 61.7)) * 0.4 * env_exp(N(0.9), 0.4), 0, 0.5),
                              (tone(sweep(200, 40, 0.8, 0.6), 0.8) * env_exp(N(0.8), 0.3), 0, 0.8)]), 0.8, 0.3, 64), -6)

def claim_accepted():
    return finish(reverb(mix([(fm(523, 2.0, 2.0, 0.9, 0.35), 0, 0.6), (fm(784, 2.0, 2.0, 1.0, 0.4), 0.18, 0.6),
                              (lp(saw(130.8, 1.2), 1200) * np.sin(np.pi * np.linspace(0, 1, N(1.2))) ** 2, 0, 0.25)]), 1.0, 0.3, 65), -4)

def claim_resisted():
    return finish(mix([(tone(sweep(440, 330, 0.7, 1.0), 0.7) * env_exp(N(0.7), 0.25), 0, 0.6),
                       (lp(noise(0.5, 66), 1200) * env_exp(N(0.5), 0.1), 0, 0.5)]), -7)

def claim_incomplete(): return finish(fm(392, 2.0, 1.5, 0.6, 0.18), -9)
def claim_sealed():
    return finish(reverb(mix([(fm(110, 1.5, 4.0, 1.4, 0.6), 0, 0.8), (hp(noise(0.02, 67), 2500) * env_exp(N(0.02), 0.004), 0.3, 0.8)]), 1.0, 0.3, 68), -5)
def claim_irregular():
    g = bitcrush(tone(sweep(300, 1200, 0.5, 2.0), 0.5), 4, 6) * (np.sin(TAU * 17 * T(N(0.5))) > 0)
    return finish(g * env_exp(N(0.5), 0.4), -8)
def claim_unrecognized():
    return finish(lp(noise(0.5, 69), 1500) * np.sin(np.pi * np.linspace(0, 1, N(0.5))) ** 2, -16)

def quest_complete():
    notes = [392, 494, 587, 784]
    return finish(reverb(mix([(fm(f, 2.0, 1.2, 0.8, 0.3), 0.14 * i, 0.5) for i, f in enumerate(notes)]), 1.0, 0.3, 70), -5)
def stage_up():
    d = 2.4
    return finish(reverb(mix([(tone(sweep(40, 80, d, 2), d) * swell(N(d), 1.4), 0, 0.8),
                              (sum(saw(f, 1.6) for f in (110, 164.8, 220)) * 0.2, 0.6, 0.5),
                              (tone(sweep(100, 30, 0.6), 0.6) * env_exp(N(0.6), 0.3), d - 0.2, 1.0)]), 1.3, 0.3, 71), -3)
def title_unlock(): return finish(reverb(sum(fm(f, 2.0, 1.0, 0.9, 0.3) for f in (880, 1175)), 0.8, 0.3, 72), -9)
def mastery_up():
    return finish(mix([(fm(1319, 2.0, 1.0, 0.3, 0.1), 0, 0.6), (fm(1760, 2.0, 1.0, 0.3, 0.1), 0.08, 0.6)]), -10)

def domain_expand():
    d = 3.4
    drone = (tone(sweep(40, 90, d, 2.0), d) + 0.5 * tone(sweep(80, 180, d, 2.0), d)) * swell(N(d), 1.4)
    wash = reverse(hp(noise(1.6, 80), 600) * env_exp(N(1.6), 0.5)) * 0.6
    crash = mix([(hp(noise(0.8, 81), 400) * env_exp(N(0.8), 0.25), 0, 1.0),
                 (tone(sweep(110, 30, 0.9, 0.5), 0.9) * env_exp(N(0.9), 0.35), 0, 1.0)])
    return finish(reverb(mix([(drone, 0, 0.7), (wash, 0.5, 0.6), (crash, 1.5, 1.0)]), 1.4, 0.35, 82), -3)

def domain_collapse():
    d = 2.4
    suck = bp(noise(1.4, 83), 300, 7000) * np.linspace(0, 1, N(1.4)) ** 2
    suck = lp(suck, 6000)
    boom = tone(sweep(90, 24, 0.9, 0.5), 0.9) * env_exp(N(0.9), 0.4)
    return finish(reverb(mix([(suck, 0, 0.7), (boom, 1.3, 1.0), (tone(5400, 0.6) * env_exp(N(0.6), 0.25), 1.6, 0.1)]), 1.0, 0.3, 84), -3)

def combo_discover():
    notes = [523, 659, 784, 1047]
    return finish(reverb(mix([(reverse(lp(noise(0.5, 85), 4000) * env_exp(N(0.5), 0.15)), 0, 0.4)] +
                             [(fm(f, 3.0, 1.5, 0.9, 0.25), 0.18 + 0.1 * i, 0.5) for i, f in enumerate(notes)]), 0.9, 0.3, 86), -5)

def combo_trigger():
    return finish(mix([(hp(noise(0.06, 87), 3000) * env_exp(N(0.06), 0.012), 0, 0.9),
                       (fm(1568, 3.0, 1.2, 0.4, 0.1), 0.0, 0.6), (tone(sweep(200, 60, 0.25, 0.5), 0.25) * env_exp(N(0.25), 0.08), 0, 0.5)]), -7)

def azriel_phase():
    return finish(reverb(mix([(tone(sweep(55, 40, 1.8, 0.6), 1.8) * env_exp(N(1.8), 0.8), 0, 0.9),
                              (tone(2093, 1.2) * env_exp(N(1.2), 0.3), 0.05, 0.25),
                              (hp(noise(0.3, 90), 3000) * env_exp(N(0.3), 0.06), 0, 0.5)]), 1.2, 0.35, 91), -4)

def azriel_impossible():
    b = fm(330, 1.5, 3.0, 1.0, 0.4)
    glitch = bitcrush(reverse(b), 4, 8)[:N(0.9)] * (np.sin(TAU * 13 * T(N(0.9))) > -0.3)
    return finish(reverb(mix([(b, 0, 0.6), (glitch, 0.5, 0.5), (tone(sweep(220, 55, 1.4, 0.6), 1.4) * env_exp(N(1.4), 0.6), 0.4, 0.5)]), 1.0, 0.3, 92), -4)

def azriel_pulse():
    d = 1.0
    return finish(mix([(tone(sweep(120, 880, d, 2.2), d) * swell(N(d), 1.2) * 0.6, 0, 1.0),
                       (hp(noise(d, 93), 2500) * swell(N(d), 2.5), 0, 0.35)]), -6)

def azriel_victory():
    d = 4.2
    drone = (tone(sweep(55, 110, 2.2, 1.5), 2.2) + 0.6 * tone(sweep(110, 165, 2.2, 1.5), 2.2)) * swell(N(2.2), 1.3)
    release = sum(fm(f, 2.0, 1.0, 2.2, 0.8) for f in (261.6, 392, 523, 784)) * 0.25
    hit = tone(sweep(100, 28, 1.0, 0.5), 1.0) * env_exp(N(1.0), 0.45)
    return finish(reverb(mix([(drone, 0, 0.7), (hit, 1.9, 1.0), (release, 2.0, 0.6)]), 1.6, 0.4, 94), -3)

def catalogue():
    s = {}
    for t, nm in enumerate(["absence", "sovereign", "unwritten", "beyond"], 1): s[f"presence/step_{nm}"] = step(t)
    s["presence/land"] = land(); s["presence/idle"] = idle()
    s["ability/cut"] = cut(); s["ability/negate"] = negate(); s["ability/fail"] = fail()
    for k, f in AUTHORITY.items(): s[f"authority/{k}"] = f()
    for l in range(1, 5): s[f"transform/level_{l}"] = transform(l)
    s["transform/end"] = transform_end(); s["transform/contradiction"] = contradiction()
    s["echo/emerge"] = echo_emerge(); s["echo/recall"] = echo_recall(); s["echo/down"] = echo_down()
    s["claim/accepted"] = claim_accepted(); s["claim/resisted"] = claim_resisted(); s["claim/incomplete"] = claim_incomplete()
    s["claim/sealed"] = claim_sealed(); s["claim/irregular"] = claim_irregular(); s["claim/unrecognized"] = claim_unrecognized()
    s["domain/expand"] = domain_expand(); s["domain/collapse"] = domain_collapse()
    s["azriel/phase"] = azriel_phase(); s["azriel/impossible"] = azriel_impossible()
    s["azriel/pulse"] = azriel_pulse(); s["azriel/victory"] = azriel_victory()
    s["combo/discover"] = combo_discover(); s["combo/trigger"] = combo_trigger()
    s["ui/quest_complete"] = quest_complete(); s["ui/stage_up"] = stage_up(); s["ui/title_unlock"] = title_unlock(); s["ui/mastery_up"] = mastery_up()
    return s

SUBTITLES = {
    "presence.step.absence": "A footstep is erased", "presence.step.sovereign": "A silvered footstep", "presence.step.unwritten": "Space gives way",
    "presence.step.beyond": "Space splits", "presence.land": "Impact tears the ground", "presence.idle": "Reality flickers",
    "ability.cut": "Space is cut", "ability.negate": "A hit never happened", "ability.fail": "The ability falters",
    "authority.absence": "Presence withdraws", "authority.denial": "A refusal", "authority.omission": "Something is removed",
    "authority.reckoning": "A debt returns", "authority.the_unwritten": "The battlefield whites out", "authority.nonexistence": "Existence recedes",
    "authority.reclamation": "The defeated stir", "authority.dominion": "The legion is commanded", "authority.perception": "Everything is known",
    "authority.transcendence": "ORISON exceeds itself", "transform.level_1": "Initial manifestation", "transform.level_2": "Fractured ascension",
    "transform.level_3": "Absolute manifestation", "transform.level_4": "Beyond existence", "transform.end": "The manifestation ends",
    "transform.contradiction": "Contradiction", "echo.emerge": "An Echo emerges", "echo.recall": "An Echo is recalled", "echo.down": "An Echo is undone",
    "claim.accepted": "Record accepted", "claim.resisted": "Record resisted", "claim.incomplete": "Record incomplete",
    "claim.sealed": "Record sealed", "claim.irregular": "Irregular record", "claim.unrecognized": "Nothing to record",
    "azriel.phase": "Azriel shifts", "azriel.impossible": "The record cannot be made", "azriel.pulse": "Omission gathers", "azriel.victory": "Azriel is omitted",
    "domain.expand": "A domain opens", "domain.collapse": "The domain collapses", "combo.discover": "Combination discovered", "combo.trigger": "Combination",
    "ui.quest_complete": "Quest complete", "ui.stage_up": "Evolution", "ui.title_unlock": "Title unlocked", "ui.mastery_up": "Mastery increased"}

def event_name(path):
    """presence/step_absence -> presence.step.absence ; authority/the_unwritten -> authority.the_unwritten"""
    folder, name = path.split("/")
    if folder == "presence" and name.startswith("step_"): return "presence.step." + name[5:]
    if folder == "transform" and name.startswith("level_"): return "transform." + name
    return f"{folder}.{name}"

def build(out_root, ns="orison"):
    snd_dir = f"{out_root}/assets/{ns}/sounds"
    cat = catalogue()
    events = {}
    for path, data in cat.items():
        full = f"{snd_dir}/{path}.ogg"
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            wf.write(tmp.name, SR, (data * 32767).astype(np.int16))
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp.name, "-ac", "1", "-ar", str(SR), "-c:a", "libvorbis", "-q:a", "4", full], check=True)
        os.unlink(tmp.name)
        ev = event_name(path)
        cat_name = "ambient" if ev.startswith("presence.idle") else "player"
        events[ev] = {"category": cat_name, "sounds": [{"name": f"{ns}:{path}", "stream": False}], "subtitle": f"subtitles.{ns}.{ev}"}
    with open(f"{out_root}/assets/{ns}/sounds.json", "w") as f: json.dump(events, f, indent=1)
    os.makedirs(f"{out_root}/assets/{ns}/lang", exist_ok=True)
    with open(f"{out_root}/assets/{ns}/lang/en_us.json", "w") as f:
        json.dump({f"subtitles.{ns}.{k}": v for k, v in SUBTITLES.items()}, f, indent=1)
    return len(cat)
