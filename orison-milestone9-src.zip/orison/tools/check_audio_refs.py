#!/usr/bin/env python3
"""Cross-checks the sound events the Java code can play against sounds.json (catches typos before a server does)."""
import json, os, re, sys
root = sys.argv[1] if len(sys.argv) > 1 else "resourcepack"
events = set(json.load(open(f"{root}/assets/orison/sounds.json")))
wanted, errors = set(), []
for r, _, fs in os.walk("src/main/java"):
    for f in fs:
        for line in open(os.path.join(r, f)).read().splitlines():
            if "audio()" not in line: continue          # only strings handed to the audio service, not config keys
            for m in re.finditer(r'"((?:authority|ability|claim|ui|echo|transform|presence|domain|combo|azriel)\.[a-z_0-9.]+)"', line):
                ev = m.group(1)
                if ev.endswith(".") or ev.endswith("_"): continue   # dynamic prefix, expanded below
                wanted.add(ev)
for a in ["absence","denial","omission","reckoning","the_unwritten","nonexistence","reclamation","dominion","perception","transcendence"]: wanted.add(f"authority.{a}")
for c in ["accepted","resisted","incomplete","unrecognized","sealed","irregular"]: wanted.add(f"claim.{c}")
for t in ["absence","sovereign","unwritten","beyond"]: wanted.add(f"presence.step.{t}")
for l in range(1, 5): wanted.add(f"transform.level_{l}")
for ev in sorted(wanted):
    if ev not in events: errors.append(f"code references unknown sound event: {ev}")
unused = events - wanted
print(f"{len(wanted)} events referenced by code, {len(events)} defined, {len(unused)} defined but unused: {sorted(unused)}")
print("AUDIO REFS OK" if not errors else "AUDIO REFS BROKEN")
for e in errors: print(" -", e)
sys.exit(1 if errors else 0)
