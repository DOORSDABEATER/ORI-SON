# ORISON - The Thing That Never Existed
Milestone 9 (Azriel Protocol) + Milestone 10 documentation, on top of everything before. Paper 26.2, Java 25, Gradle.

Build: `./gradlew build` (JDK 25). Jar: `build/libs/orison-0.9.0.jar` -> `plugins/`.
See docs/PRESENCE.md for the presence design, limits and test plan.
First run creates `abilities.yml` with all 70 abilities (cost, cooldown, range, duration, damage, unlock-stage).
Default numbers are provisional test values, not final balance.

## Owner commands
`/orison cast <name|id|number>`, `/orison abilities [1-10]`, `/orison paradox`

## Admin commands (OP + orison.admin)
inspect, grant/revoke (confirmed + audited), unlock <ability|all>, stage <1-7> (test helper, audited), reload, debug.
awaken/echo/quest/vfx are reserved for later milestones.

## Status (honest)
Nothing below has been compiled or run yet.

| Area | State |
|---|---|
| Foundation: modules, config, SQLite + migrations (v1-v5) + backups, audit log, owner binding | Implemented, unverified |
| PARADOX (cached, persisted, clamped to max) | Implemented, unverified |
| 10 Authorities / 70 ability definitions, config-driven | Implemented, unverified |
| Ability engine: owner check, world block, unlock, cooldown, cost, LOS targeting, charge-on-success | Implemented, unverified |
| Status manager with guaranteed cleanup (expiry, death, logout, disable) | Implemented, unverified |
| Working ability behaviours: UNSEEN, STEP BETWEEN, INVALID (25 of 70) | Implemented, unverified |
| Movement-state engine, footsteps, 4 trail tiers, jump/land effects, afterimages (particles only, no entities) | Implemented; pure logic verified (22 unit tests passed locally), renderer unverified |
| Sovereign Presence: eyes, outline, fragments, idle, per-stage + transformation scaling | Implemented, unverified; eye glow is a particle approximation (see docs/PRESENCE.md) |
| Admin `vfx status/preview/transform` test controls | Implemented, unverified |
| Custom model VFX (non-particle): 14 models, textures, overlay glyphs, display-entity engine, pack validator | Pack generated + validated (JSON refs, binary alpha, textures inspected as images); in-game rendering NOT verified. See docs/VFX.md |
| Echo Legion: hunt records, AWAKEN claim + 6 outcomes, ranks/integrity, persistence, summon/recall, orders, formations, AI | Implemented; pure rules verified (39 local tests), Bukkit side unverified. See docs/ECHO.md |
| AWAKEN, AWAKEN: ONE, AWAKEN: ALL abilities | Implemented, unverified |
| Quests (10, 3 hidden), stage gating 1-7, titles, story flags, THE EXCEPTION unsealing, mastery levels, persistence | Pure rules verified (57 local tests), services unverified. See docs/PROGRESSION.md |
| Four transformations + CONTRADICTION as gameplay (status, modifiers, speed, presence, cleanup) | Implemented, unverified |
| Audio: 38 synthesized sounds (10 Authority signatures, presence, transformations, Echo, claim outcomes, progression), subtitles, per-category volumes | Sounds audited here (format, loudness, clipping, refs); never listened to; Java side unverified. See docs/AUDIO.md |
| 14 more abilities, 10 combos with discovery, 2 domains (KINGDOM OF NOTHING, THE STILL WORLD), 4 new sounds | Rules verified (72 local tests, 42 sounds audited); Bukkit side unverified. See docs/ADVANCED.md |
| Azriel Protocol: 5 phases (damage-floor enforced), phase gating of abilities, combos break phase II, impossible claim, final manifestation, omission pulses, boss bar, lore victory, THE EXCEPTION and the special Azriel Echo, 4 sounds | Rules verified (84 local tests, 46 sounds); Bukkit side and your real boss integration unverified. See docs/AZRIEL.md |
| Docs: ABILITIES (all 70), INSTALL, ADMIN_COMMANDS, COMPATIBILITY, TESTING_REPORT, KNOWN_LIMITATIONS | Written. See docs/ |
| Other 45 abilities | Defined only; cast reports "not implemented", costs nothing |
| Polished UI, remaining 45 abilities, a verified build | Not started |

Known limitations: STEP BETWEEN is a plain teleport (region plugins guarding only block/entity events won't stop it);
UNSEEN hides from players only, mobs still see the owner; CONTRADICTION overcharge not yet built.
