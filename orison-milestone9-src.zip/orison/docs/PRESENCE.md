# Movement & Presence / Sovereign Presence (Milestone 4)

## How it works
One repeating task (default every 2 ticks) runs for the owner only. Each update it reads the owner's real
position, flags and a 24-sample pose history, classifies a movement state, and emits particles. **No entities
are spawned**, so nothing can lag behind the owner, persist after logout, or pile up. Retained state is limited to
a fixed ring buffer, at most 4 short-lived afterimage "holds", and one shockwave task; `reset()` (teleport, world
change, death, respawn, join, quit) and `stop()` (reload, disable) clear all of it.

States: IDLE, WALKING, RUNNING (fast non-sprint movement; vanilla has no run), SPRINTING, SNEAKING, JUMPING,
FALLING, LANDING, ABILITY_MOVEMENT, TRANSFORMATION.

## Stage table (effective stage = max(real stage, transformation floor I=4, II=5, III=6, IV=7))
| Stage | Trail | Eyes | Fragments | Outline | Afterimage |
|---|---|---|---|---|---|
| 1 Dormant | none | - | - | - | - (rare faint flicker only) |
| 2 Recognition | Absence | 1 | - | - | - |
| 3 Manifestation | Absence | 1 | 2 | 1 | - |
| 4 Awakening | Sovereign | 2 | 3 | 2 | - |
| 5 The Unwritten | Unwritten | 2 | 4 | 3 | 1 (6 ticks late) |
| 6 Nonexistence | Unwritten | 3 | 5 | 4 (+disconnected copy) | 1 (5 ticks late) |
| 7 Absolute | Beyond Existence | 3 | 6 | 5 | 2 (3 ticks late) |

Transformations add fragments (+0/0/1/2/3 for none/I/II/III/IV... see PresenceProfile), raise intensity
(x1.1 / 1.25 / 1.4 / 1.6), change shard geometry (shard, triangle, diamond, octahedron) and play a monochrome
shockwave when the level rises.

## Colours
Black, white, silver and grey only. Portal-family particles are deliberately not used (they are purple).

## Limitations (read these)
- **Eye glow is a particle approximation.** Vanilla cannot make a player's eyes glow without a resource-pack skin
  layer or a model. Two small white points are drawn at the eyes; they can smear slightly during fast turns.
  A true glow is planned for the resource-pack milestone.
- **Silhouette distortion and afterimages are particle point-clouds**, not geometry. They read as a ghost, not a
  solid copy. Smoother fragments (ModelEngine/display entities with pooling) come with the VFX milestone.
- Particles are client-limited and may be culled/blurred at long range or on low particle settings.
- Effects pause while the owner is gliding, swimming, flying or riding, is UNSEEN, dead or in spectator.
- Per-owner presence preferences (stored in the database) are not built yet; settings are in config.yml.
- NO FOOTPRINTS (Absence 3) and MISSING FRAME (Absence 5) are not implemented; STEP BETWEEN is already wired in.

## Test plan (in game; none of this has been run yet)
Use `/orison admin vfx preview <1-7>` and `/orison admin vfx transform <0-4>`, check with `/orison admin vfx status`.
1. Walk, sprint, sneak, jump, land from a height, at stages 1-7: trail matches the table and never lags the owner.
2. Sneak: trail and outline stop; only eyes (stage 2+) and one fragment remain.
3. STEP BETWEEN: one cut line + origin afterimage, no stray trail from the teleport.
4. Teleport (`/tp`), change world, die and respawn, log out and in: no stale trail or afterimage appears.
5. `vfx transform 0..4` repeatedly: one shockwave per rise; nothing remains after `transform 0`.
6. UNSEEN: all presence effects stop for the duration.
7. Watch a second player's view: eyes/outline/afterimage visible to them, hidden from the owner by default.
8. `performance.mode: LOW` and `vfx.reduced-effects: true`: visibly fewer particles, no outline/afterimage.
9. Spark/Timings: confirm the presence task stays negligible with several players nearby.
