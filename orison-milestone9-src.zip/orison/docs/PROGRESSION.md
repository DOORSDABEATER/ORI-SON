# Progression, mastery and transformations (Milestone 6)

## Evolution stages (gated by quests, never by one command or a bare XP bar)
| Stage | Name | Reached by completing |
|---|---|---|
| 1 | DORMANT - THE UNRECOGNIZED | starting state |
| 2 | RECOGNITION - THE FIRST ANOMALY | *(hidden)* THE FIRST ANOMALY: defeat 15 hostile creatures |
| 3 | MANIFESTATION - THE UNNATURAL PRESENCE | use authorities x15, defeat x40 |
| 4 | AWAKENING - THE RECOGNIZED SOVEREIGN | STEP BETWEEN x10, UNSEEN x5, declare 3 hits INVALID |
| 5 | THE UNWRITTEN - BEYOND THE KNOWN | Awaken 3 Echoes, 25 defeats made by Echoes |
| 6 | NONEXISTENCE - THE IMPOSSIBLE AUTHORITY | raise an Echo to REPLICA, manifest x3, AWAKEN: ALL x3 |
| 7 | THE THING THAT NEVER EXISTED - ABSOLUTE RECOGNITION | *(hidden)* story flag `azriel_phase4` (set by the Azriel encounter, Milestone 9) |

Rules: a quest only counts progress while the owner is at its minimum stage (no pre-farming), the chain cannot skip a stage,
and stage 7 cannot be earned by grinding. Side quests grant titles: A LEGION OF RECORDS (10 Echoes), THE UNBROKEN (25 negated
hits), HUNTER OF THE UNWRITTEN (200 defeats). *Hidden* quests show as "hidden thread(s)" until progress or a story flag reveals them.

**THE EXCEPTION** (hidden): needs story flags `azriel_defeated` and `exception_acknowledged`, then unseals `mythic:azriel` so it
can finally be claimed as an Echo. Until then Azriel stays SEALED.

Commands: `/orison quests`, `/orison titles`, `/orison title <id>`. Admin (audit-logged): `/orison admin quest list|complete|reset|story`,
`/orison admin stage <1-7>`.

## Mastery
Every successful cast counts. Levels at 10 / 30 / 75 / 150 / 300 uses. Each level cuts PARADOX cost 3% (max 15%) and cooldown 4%
(max 20%). Never free. Announced on level-up; `/orison mastery` shows per-authority levels.

## Transformations (manifestations, not equipment)
| Level | Name | Ability that triggers it | Stage | Duration | Cost / cooldown | Modifiers while active |
|---|---|---|---|---|---|---|
| I | INITIAL MANIFESTATION | FIRST RECOGNITION | 4 | 40s | 30 / 120s | cost x0.95, cooldown x0.9, range x1.2 |
| II | FRACTURED ASCENSION | FRACTURED ASCENSION | 5 | 50s | 45 / 150s | x0.90, x0.80, range x1.4, Speed I |
| III | ABSOLUTE MANIFESTATION | ABSOLUTE MANIFESTATION | 6 | 60s | 60 / 200s | x0.85, x0.70, range x1.7, Speed II |
| IV | BEYOND EXISTENCE | BEYOND EXISTENCE | 7 | 90s | 80 / 300s | x0.75, x0.60, range x2.2, Speed II |

Each one raises Sovereign Presence (stronger trail, more and differently shaped shards, silhouette, eyes) and plays its shockwave.
CONTRADICTION (stage 5, 15s): reach x1.25, cooldowns x0.85, presence x1.25. All of it is a status that ends on expiry,
`/orison transform cancel`, death, logout and plugin disable. Defaults live in `abilities.yml`; if yours predates this version the
five abilities above are updated once (`meta.defaults-version: 2`).

## Status and limits
- Pure rules verified locally (57 tests total); persistence, services and commands are NOT compiled or run.
- Quest counts and mastery curves are provisional balance. Quests are defined in code (`QuestCatalog`); a quests.yml override is not built.
- Not built: Echo missions and Echo ability unlocks; per-ability progression requirements beyond stage; the story events themselves
  (Milestone 9); transformation-specific audio (Milestone 7); an ability-by-ability effect on abilities that are not implemented yet.
- The Speed effect is removed on cancel; if another source granted Speed at that moment it is removed too.
