# Admin commands (OP + `orison.admin`, checked on every call)

| Command | Purpose |
|---|---|
| `/orison admin inspect [player]` | Owner, stage, PARADOX, ability counts, live compatibility report |
| `/orison admin grant <player>` then `... confirm` | Bind ORISON to a player. Two-step, 30 s expiry, audit-logged. OP alone never transfers ownership |
| `/orison admin revoke` then `... confirm` | Remove the owner (same safeguards) |
| `/orison admin unlock <ability\|all>` | Unlock abilities regardless of stage (audit-logged; for testing) |
| `/orison admin stage <1-7>` | Set the evolution stage (audit-logged; for testing) |
| `/orison admin awaken` | Force-claim the nearest recent defeat (skips odds and defeat count; seals still apply) |
| `/orison admin echo list\|testrecord <type> [n]\|remove <n>` | Echo/hunt test tools |
| `/orison admin quest list\|complete <id>\|reset <id>\|story <flag>` | Quest and story-flag tools (audit-logged) |
| `/orison admin combo list\|unlock\|reset <id\|all>` | Combo discovery tools |
| `/orison admin azriel status\|spawn\|phase <1-5>\|reset` | Azriel Protocol tools |
| `/orison admin vfx status\|preview <1-7\|off>\|transform <0-4>\|pack\|demo <name>` | Visual testing |
| `/orison admin reload` | Reload config.yml and abilities.yml |
| `/orison admin debug [on\|off]` | Debug logging |

Owner commands: `/orison cast|abilities|paradox|echo|hunts|awaken|quests|combos|mastery|titles|title|transform`. Saying `AWAKEN` in chat casts AWAKEN.
Every sensitive admin action is written to the audit log (console and the `audit_log` table).
