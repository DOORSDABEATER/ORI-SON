# Advanced authorities: combos, domains, ultimates (Milestone 8)

## New working abilities (14; total now 25 of 70)
| Authority | Ability | What it does |
|---|---|---|
| I Absence | MISSING FRAME | Short horizontal dash plus a moment of immunity (nothing lands, nothing is consumed) |
| II Denial | NOT TODAY | For its window, refuses one lethal hit and restores 30% health |
| III Omission | OMISSION: FORM | Target loses its form: cannot act, slowed and weakened (restored on expiry/shutdown) |
| III Omission | NOTHING REMAINS | One removal strike, stronger against the wounded |
| IV Reckoning | DEBT COLLECTOR | Opens a ledger on a target: damage you take is recorded as its debt |
| IV Reckoning | RETURN TO SENDER | Next hit is sent back at the attacker; you take half |
| IV Reckoning | COLLAPSE THE DISTANCE | Move beside the target |
| IV Reckoning | EVERYTHING COMES BACK | The ledger is paid in full (capped by the ability's damage value) |
| V The Unwritten | KINGDOM OF NOTHING (domain) | See below |
| V The Unwritten | THE STILL WORLD (domain) | Hostile mobs in the sphere are frozen in place; released on leaving or collapse |
| VII Reclamation | SOVEREIGN COMMAND | Every active Echo is ordered onto one target and empowered |
| VIII Dominion | ONE AUTHORITY | Legion becomes resistant and tight (PROTECT) |
| IX Perception | HUNT MARK | Mark a target; marked defeats are easier to claim |
| IX Perception | FUTURE FRACTURE | Incoming damage halved while active |

Safety rules for all of them: damage goes through normal damage events (protection plugins can veto), ability targets exclude
players, Echoes, NPCs, tamed pets and armor stands (`abilities.affect-players: false` by default), nothing modifies blocks, and every lasting
effect is a status or tracked task cleaned up on expiry, death, logout and disable.

## The ten combinations
Cast the second ability within the window of the first. They are discovered by doing them; `/orison combos` lists them (undiscovered
ones show only a hint). Admin: `/orison admin combo list|unlock|reset`.

| Combo | Sequence (window) | Effect |
|---|---|---|
| UNSEEN GEOMETRY | STEP BETWEEN -> OMISSION: FORM (4s) | Arrive behind the target, formless 1.5x as long, plus a strike |
| PERFECT RETURN | INVALID -> RETURN TO SENDER (6s) | Reflection doubled, you take nothing |
| ERASURE | COLLAPSE THE DISTANCE -> NOTHING REMAINS (4s, same target) | Double strike |
| VANISHING FRAME | UNSEEN -> MISSING FRAME (6s) | Dash x1.5, immunity x2 |
| MARKED RECORD | HUNT MARK -> AWAKEN (20s) | Marked defeat: +25% claim chance, one fewer defeat needed, double claim window |
| KINGDOM LEGION | KINGDOM OF NOTHING -> AWAKEN: ALL (30s) | +4 Echo capacity, arrivals empowered |
| FULL ACCOUNT | DEBT COLLECTOR -> EVERYTHING COMES BACK (12s) | Debt returns x1.5 |
| REFUSED FUTURE | FUTURE FRACTURE -> NOT TODAY (8s) | Restores 60% and 2s immunity |
| ONE WILL | SOVEREIGN COMMAND -> ONE AUTHORITY (6s) | Echoes converge on the target, empowered |
| CONTRADICTION OVERDRIVE | CONTRADICTION -> BEYOND EXISTENCE (15s) | Manifestation lasts 1.5x, refunds 30 PARADOX, 15 damage to hostile creatures within 10 blocks (through normal damage events) |

## Domains
One at a time, 20-45 s (clamped), never alters blocks. Expansion: huge boundary ring, six rifts, a beam, whiteout/vignette, domain sounds.
Collapse: ring implodes, shockwave, flash; runs from a status so it also fires on death, logout and plugin disable.
- **KINGDOM OF NOTHING** (radius 18, 30 s, cost 60, cooldown 150): hostile mobs inside are slowed and weakened; while you stand inside, your
  cooldowns are x0.7, defeats grant +2 PARADOX, AWAKEN's claim chance +15% and claim window x2.
- **THE STILL WORLD** (radius 14, 20 s): hostile mobs inside cannot act.

## Verified vs not
- Verified locally: combo matching rules (order, window, same-target, pruning), domain modifiers and containment, duration clamping:
  72 pure-logic tests pass in total. Pack and 42 sounds validated.
- NOT verified: the Bukkit implementation (never compiled or run). The damage-interception order in the owner damage handler is the
  riskiest piece to test in game.
- Not built: the other 45 abilities, domain-specific ability interactions beyond those listed,
  region-plugin checks for potion effects applied inside a domain.
