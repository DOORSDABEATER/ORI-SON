# Ability reference (all 70)

Generated from the source. **Status** is honest: *implemented* means code exists (still unverified in game); *not implemented* means the ability is defined and costs nothing if cast. Numbers are provisional test values and live in `abilities.yml`.


## I. Absence - Authority over presence

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 1 | UNSEEN | 6 | 3s | 2 | implemented - Hides you from other players; ends if you deal damage |
| 2 | STEP BETWEEN | 9 | 8s | 2 | implemented - Blink along your line of sight to a safe spot |
| 3 | NO FOOTPRINTS | 12 | 13s | 2 | not implemented |
| 4 | UNTOUCHABLE MOMENT | 15 | 18s | 2 | not implemented |
| 5 | MISSING FRAME | 12 | 8s | 2 | implemented - Short dash with a moment of immunity |
| 6 | ABSENT HORIZON | 21 | 28s | 3 | not implemented |
| 7 | I WAS NEVER THERE | 40 | 90s | 3 | not implemented |

## II. Denial - Authority over rejection

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 8 | INVALID | 6 | 3s | 2 | implemented - Next hit on you never happened (grants PARADOX); geometric shield |
| 9 | NO ENTRY | 9 | 8s | 2 | not implemented |
| 10 | UNANSWERED | 12 | 13s | 2 | not implemented |
| 11 | WRONG TARGET | 15 | 18s | 2 | not implemented |
| 12 | NOT TODAY | 35 | 90s | 3 | implemented - Refuse one lethal hit within the window |
| 13 | SILENCE THE LAW | 21 | 28s | 3 | not implemented |
| 14 | ABSOLUTE REFUSAL | 40 | 110s | 3 | not implemented |

## III. Omission - Authority over removal

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 15 | WEIGHTLESS | 6 | 3s | 3 | not implemented |
| 16 | DIRECTIONLESS | 9 | 8s | 3 | not implemented |
| 17 | SOUNDLESS | 12 | 13s | 3 | not implemented |
| 18 | BROKEN MOMENTUM | 15 | 18s | 3 | not implemented |
| 19 | MISSING GROUND | 18 | 23s | 3 | not implemented |
| 20 | OMISSION: FORM | 20 | 18s | 4 | implemented - Target cannot act, slowed and weakened |
| 21 | NOTHING REMAINS | 40 | 60s | 4 | implemented - Single removal strike, stronger vs wounded |

## IV. Reckoning - Authority over consequences

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 22 | DEBT COLLECTOR | 15 | 30s | 3 | implemented - Ledger on a target records damage you take |
| 23 | RETURN TO SENDER | 18 | 25s | 3 | implemented - Next hit sent back; you take half |
| 24 | UNPAID CONSEQUENCE | 12 | 13s | 3 | not implemented |
| 25 | COLLAPSE THE DISTANCE | 16 | 14s | 3 | implemented - Move beside the target |
| 26 | JUDGEMENT WITHOUT CAUSE | 18 | 23s | 3 | not implemented |
| 27 | EVERYTHING COMES BACK | 25 | 40s | 4 | implemented - Ledger paid in full (capped) |
| 28 | FINAL ACCOUNT | 40 | 150s | 4 | not implemented |

## V. The Unwritten - Authority over the battlefield

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 29 | WHITEOUT | 6 | 3s | 4 | not implemented |
| 30 | THE STILL WORLD | 35 | 90s | 4 | implemented - DOMAIN: hostile mobs frozen |
| 31 | NO DISTANCE | 12 | 13s | 4 | not implemented |
| 32 | FALSE REALITY | 15 | 18s | 4 | not implemented |
| 33 | UNWRITTEN LAW | 18 | 23s | 4 | not implemented |
| 34 | THE WORLD FORGETS | 21 | 28s | 5 | not implemented |
| 35 | KINGDOM OF NOTHING | 60 | 150s | 5 | implemented - DOMAIN: hostiles slowed/weakened; cooldowns x0.7, PARADOX per defeat, easier claims |

## VI. Nonexistence - Authority over existence

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 36 | UNMAKE | 6 | 3s | 5 | not implemented |
| 37 | UNBEGIN | 9 | 8s | 5 | not implemented |
| 38 | UNWRITE | 12 | 13s | 5 | not implemented |
| 39 | THE ABSOLUTE ZERO | 15 | 18s | 5 | not implemented |
| 40 | EXISTENCE DENIED | 18 | 23s | 5 | not implemented |
| 41 | THE THING THAT NEVER WAS | 21 | 28s | 6 | not implemented |
| 42 | THE FINAL OMISSION | 40 | 190s | 6 | not implemented |

## VII. Reclamation - Authority over the defeated

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 43 | AWAKEN | 6 | 3s | 4 | implemented - Claim the nearest recent defeat as an Echo (say AWAKEN) |
| 44 | AWAKEN: ONE | 9 | 8s | 4 | implemented - Summon the strongest ready stored Echo |
| 45 | AWAKEN: LEGION | 12 | 13s | 4 | not implemented |
| 46 | AWAKEN: ALL | 15 | 18s | 4 | implemented - Summon every ready Echo up to capacity |
| 47 | PERFECT RECORD | 18 | 23s | 4 | not implemented |
| 48 | SOVEREIGN COMMAND | 20 | 35s | 5 | implemented - All Echoes focus one target, empowered |
| 49 | UNENDING LEGION | 40 | 210s | 5 | not implemented |

## VIII. Dominion - Authority over the Legion

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 50 | MY WILL | 6 | 3s | 4 | not implemented |
| 51 | FORMATION: VEIL | 9 | 8s | 4 | not implemented |
| 52 | FORMATION: HUNT | 12 | 13s | 4 | not implemented |
| 53 | DIVIDED PURPOSE | 15 | 18s | 4 | not implemented |
| 54 | SOVEREIGN'S PROTECTION | 18 | 23s | 4 | not implemented |
| 55 | CONVERGENCE | 21 | 28s | 5 | not implemented |
| 56 | ONE AUTHORITY | 30 | 60s | 5 | implemented - Legion resistant and tight (converges after SOVEREIGN COMMAND) |

## IX. Perception - Authority over knowledge

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 57 | TRUE SIGHT | 6 | 3s | 3 | not implemented |
| 58 | EXISTENCE SCAN | 9 | 8s | 3 | not implemented |
| 59 | HUNT MARK | 10 | 20s | 3 | implemented - Mark a target; marked defeats easier to AWAKEN |
| 60 | WEAKNESS RECOGNIZED | 15 | 18s | 3 | not implemented |
| 61 | RECORD ANALYSIS | 18 | 23s | 3 | not implemented |
| 62 | FUTURE FRACTURE | 14 | 30s | 4 | implemented - Incoming damage halved while active |
| 63 | NOTHING ESCAPES | 40 | 250s | 4 | not implemented |

## X. Transcendence - Authority over ORISON itself

| # | Ability | Cost | Cooldown | Unlock stage | Status |
|---|---|---|---|---|---|
| 64 | FIRST RECOGNITION | 30 | 120s | 4 | implemented - Transformation I |
| 65 | LIMITLESS MOMENT | 9 | 8s | 6 | not implemented |
| 66 | CONTRADICTION | 25 | 60s | 5 | implemented - Overcharge: reach x1.25, cooldowns x0.85, presence stronger |
| 67 | FRACTURED ASCENSION | 45 | 150s | 5 | implemented - Transformation II |
| 68 | THE UNBOUND | 18 | 23s | 6 | not implemented |
| 69 | ABSOLUTE MANIFESTATION | 60 | 200s | 6 | implemented - Transformation III |
| 70 | BEYOND EXISTENCE | 80 | 300s | 7 | implemented - Transformation IV (final manifestation) |

**25 of 70 implemented.**
