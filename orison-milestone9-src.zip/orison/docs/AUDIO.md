# Audio (Milestone 7)

38 procedurally synthesized sounds (tools/sounds.py -> mono 44.1 kHz Ogg Vorbis, deterministic), shipped in the same pack as the models.
Identity: cold, glassy, sub-bass, reversed swells, detuned drones; no melodic-fantasy timbres.

| Group | Events | Played when |
|---|---|---|
| Authority signatures (10, each its own recipe) | `authority.absence` ... `authority.transcendence` | any ability of that Authority is cast (STEP BETWEEN has its own blade sound) |
| Presence | `presence.step.absence/sovereign/unwritten/beyond`, `presence.land`, `presence.idle` | footsteps (by trail tier), landings, rare idle flickers |
| Ability | `ability.cut`, `ability.negate`, `ability.fail` | STEP BETWEEN, INVALID negating a hit, a refused/failed cast |
| Transformations (layered, 3-6 s) | `transform.level_1..4`, `transform.end`, `transform.contradiction` | manifestation starts/ends, CONTRADICTION |
| Echo Legion | `echo.emerge/recall/down` | summon, recall, an Echo being undone |
| AWAKEN outcomes (6) | `claim.accepted/resisted/incomplete/sealed/irregular/unrecognized` | every claim attempt, one cue per outcome |
| Progression | `ui.quest_complete/stage_up/title_unlock/mastery_up` | the matching event |

## Settings (config.yml `audio:`)
`enabled`, `volume` (master), `ability-volume`, `presence-volume` (default 0.5; footsteps can be set to 0), `echo-volume`, `ui-volume`.
Every event has a subtitle (`lang/en_us.json`) for players using subtitles. Sounds play only for clients that loaded the pack,
carry a range in blocks (distance-aware), and footsteps/lands/fail cues are rate-limited.

## Verified here
- `tools/audit_sounds.py` decodes every file: mono, 44.1 kHz, Vorbis, 0.12-5.9 s, no clipping (peaks -3 to -22 dBFS), not silent,
  no edge clicks, every event has a subtitle and no orphan files. Spectrograms of the ten Authority sounds were inspected and differ clearly.
- `tools/check_audio_refs.py` confirms every sound event the Java code can play exists in `sounds.json`.

## Not verified / limits
- I cannot listen. Levels, taste, and how the layers sit together in a real mix are for your ears; every recipe is a function in
  `tools/sounds.py` and easy to retune. Expect to adjust volumes and a few timbres.
- Not built: Plasmo Voice integration (optional), looping ambience, per-ability sounds for the 59 unimplemented abilities,
  domain and combo audio (Milestone 8), Azriel cinematic audio (Milestone 9).
- Sounds are synthesized, not recorded; they are a strong first pass, not a final sound-design pass.
