# The Azriel Protocol (Milestone 9)

## How it attaches to your Azriel
ORISON does not spawn or script Azriel. It wraps an existing boss: a MythicMobs mob whose internal name equals `azriel.mythic-id`
(default `azriel`), or the fallback body from `/orison admin azriel spawn`. The protocol engages when the **owner (or an Echo)** hits Azriel
and the owner is at stage >= `azriel.min-stage` (6). Below that, Azriel "does not recognise you" and your own Azriel behaves exactly as before.

Azriel's health bar is never rewritten. Each phase is enforced by clamping incoming damage to a floor, so no phase can be skipped by raw damage.

| Phase | Health band | What happens |
|---|---|---|
| I RECOGNITION FAILURE | 100-75% | Perception, Omission and Nonexistence authorities cannot read Azriel and always fail; other abilities are resisted 25% of the time. Resisted casts cost nothing. The interface reports IRREGULAR. |
| II AUTHORITY CONFLICT | 75-45% | Azriel absorbs 90% of damage. A **combo** breaks that for 8 s; each Echo near Azriel reduces the absorption (floor 30%). Leaning on one authority (4th use in 20 s) is *answered* and fails, so you must vary. |
| III IMPOSSIBLE RECORD | 45% | Azriel is invulnerable and still. Only AWAKEN works. The claim fails: IRREGULAR, "cannot be recorded through ordinary reclamation". If you do not act within 30 s, ORISON attempts it on its own. |
| IV THE THING THAT NEVER WAS | 45-20% | Story flag `azriel_phase4` completes ABSOLUTE RECOGNITION (stage 7), PARADOX is filled, the final manifestation (Beyond Existence) is granted for 60 s with a whiteout and sound. All authorities answer. |
| V FINAL OMISSION | 20-0% | Every 12 s Azriel telegraphs a ground ring (radius 12, 2 s warning) then omits it: 6 damage through normal damage events (immunity, NOT TODAY, FUTURE FRACTURE all apply). Azriel can finally be killed. |

A boss bar shows the phase and Azriel's health to everyone in the arena (radius 48). Re-engaging after a wipe resumes at the phase that matches
Azriel's health (and whether the final recognition already happened).

## The victory and THE EXCEPTION
Killing Azriel in phase V plays the lore sequence acknowledging that you were defeated here once, that NULL REQUIEM broke against it, that ORISON's
evolution is complete, and that the resolution is only the beginning of THE EXCEPTION. It sets `azriel_defeated`, writes Azriel's hunt record, and
leaves a 10-minute claimable record at the spot.

Azriel stays **SEALED** until the hidden quest THE EXCEPTION is complete (it needs `azriel_defeated` and `exception_acknowledged`). The first AWAKEN
attempt at Azriel's record sets `exception_acknowledged`, completes the quest, unseals `mythic:azriel`, and the claim succeeds: a special Echo
(`THE EXCEPTION`, integrity COMPLETE, INDEPENDENT personality) in the body set by `azriel.echo-entity`.

## Admin / testing
`/orison admin azriel status|spawn|phase <1-5>|reset` (all audit-logged). `phase` jumps an existing Azriel (within 64 blocks of the owner) to that
phase for testing, ignoring the stage gate.

## Verified vs not
- Verified locally: the phase rules (floors, no-skip clamping, resume, shield, resistance, adaptation window): 12 tests, all passing (84 total).
- NOT verified: the whole Bukkit implementation, including how it behaves with your real Azriel MythicMobs boss. Things most likely to need a tweak:
  whether MythicMobs skills heal Azriel or reposition it (the clamps only limit incoming damage), the arena radius, and the phase V pulse damage.
- The fight does not add new Azriel *attacks*. It scripts the owner's side and the damage rules around your existing boss.
- Not built: Phase-specific boss skills, a cinematic camera, Azriel-specific music beyond the four cues, and the Plasmo Voice layer.
