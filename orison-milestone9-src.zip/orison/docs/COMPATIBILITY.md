# Dependency and compatibility report

Audited on the information you gave (Paper 26.2 with MythicMobs, ModelEngine and the other listed plugins installed). I could not inspect your server.

| Item | Status |
|---|---|
| Minecraft / Paper 26.2 | Target. API dependency `io.papermc.paper:paper-api:26.2.build.+`. Not compiled against it yet |
| Java | 25 required (Paper 26.2) |
| Resource pack format | `min_format`/`max_format` `[88, 0]` for 26.2 (from published format info; not tested on a client) |
| MythicMobs | Soft. Reflection bridge reads a mob's internal name only; Azriel wrapper keys off it. Untested against your build |
| ModelEngine | Soft. Reflection bridge reads/applies a model id. Untested against your build |
| ProtocolLib / Plasmo Voice | Declared soft dependencies, not used yet |
| WorldGuard / region plugins | Not integrated directly. Damage goes through normal events (they can veto it); teleports and potion effects on mobs do not check regions |
| SQLite | Uses the JDBC driver bundled with Paper (no shading) |
| Resource pack contents | Validated here: JSON references, textures (binary alpha), 14 models, 46 sounds decoded and measured |

API names most likely to need adjusting on 26.2 if the compiler complains: `Attribute.MAX_HEALTH/ATTACK_DAMAGE/MOVEMENT_SPEED`, `Particle.DUST`,
`PotionEffectType.SLOWNESS/STRENGTH/RESISTANCE`, `ItemMeta#setItemModel`, `Registry.ENTITY_TYPE`, `Bukkit.getCurrentTick()`.
