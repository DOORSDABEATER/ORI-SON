# Known limitations and troubleshooting

## Limitations
- **Nothing here has been compiled or run.** Expect compile errors and runtime bugs on first contact.
- 45 of the 70 abilities are defined but not implemented (see ABILITIES.md). Casting one says so and costs nothing.
- Eye glow, silhouette distortion and afterimages are approximations (display-entity models and particles), not true player-model changes.
- Echoes keep their base mob's attacks; recognisable signature attacks and boss-ability adaptation are not built.
- AWAKEN: LEGION, PERFECT RECORD, UNENDING LEGION, the Legion GUI, Plasmo Voice, looping ambience and a quests.yml override are not built.
- Teleports and potion effects on mobs do not check region plugins; damage always goes through normal events.
- Model VFX and sounds only reach clients that loaded the pack. Screen overlay glyph sizing is a guess.
- Azriel's scripted fight limits damage and gates abilities; it does not change your boss's own skills or heal behaviour.

## Troubleshooting
| Symptom | Likely cause / fix |
|---|---|
| Plugin disables itself on start | Console says why (database or owner load). Check `plugins/ORISON/orison.db` permissions |
| "Nothing here recognises you" | You are not the bound owner. `/orison admin grant <you>` + `confirm` |
| Abilities say "has not been recognised yet" | Stage too low. `/orison admin stage 4` for testing, or play the quests (`/orison quests`) |
| No custom visuals/sounds | Pack not loaded. `/orison admin vfx pack`; check `resourcepack.url`/`sha1` |
| Magenta/black cubes | Pack failed to load or wrong `pack_format`; adjust `min_format`/`max_format` in tools/build_pack.py and rebuild |
| Footsteps too noisy | `audio.presence-volume: 0`, or `presence.trail: false` |
| Too many particles/displays | `performance.mode: LOW`, `vfx.reduced-effects: true`, lower `vfx.models.max-live` |
| AWAKEN does nothing | Needs stage 4, a defeat within `echo.claim-range`/`claim-window-seconds`, and the defeated mob must be a claimable type |
| Azriel not engaging | Owner below `azriel.min-stage`, wrong `azriel.mythic-id`, or the owner/an Echo did not do the damage |
