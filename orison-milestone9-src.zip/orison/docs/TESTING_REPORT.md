# Testing report (honest)

## Verified here, with evidence
| What | How | Result |
|---|---|---|
| Pure rules: movement classification, footsteps, presence profiles, Echo ranks/integrity/claims/formations, quests/stages/titles, mastery, transformations, combos, domains, Azriel phases | 84 unit tests compiled and run with Java 21 here (JUnit API shimmed locally; the same files are JUnit 5 tests for Gradle) | 84 passed, 0 failed |
| Resource pack | `tools/validate_pack.py`: JSON parses, every model/texture/item reference resolves, binary alpha, no orphans | PACK VALID |
| Textures | Rendered to a contact sheet and inspected as images | Coherent; not seen in game |
| Audio | `tools/audit_sounds.py`: decoded all 46 sounds: mono 44.1 kHz Vorbis, duration, peak/RMS, no clipping, no edge clicks, subtitles present | AUDIO OK |
| Audio references | `tools/check_audio_refs.py`: every sound event the code can play exists | OK |
| Config | config.yml and plugin.yml parse, no duplicate keys | OK |
| Source structure | Bracket-balance check on all 95 main Java files (7,683 lines) | OK (this is not compilation) |

## NOT verified (no evidence exists)
Compilation against Paper 26.2 (no JAR was produced), server start, command behaviour, persistence across restarts, every one of the 25 implemented abilities in game,
combos, domains, transformations, movement-state transitions on a real client, presence/VFX synchronisation, model rendering and orientation, audio by ear, Echo AI and
navigation, MythicMobs/ModelEngine bridges, WorldGuard behaviour, multiplayer, logout/death/world-change cleanup, performance under load, the Azriel fight with your real boss.

## First-run checklist (maps to the spec's test list)
1. Build; fix any compile errors (send them to me). 2. Console shows the compatibility report. 3. `/orison admin grant` flow with confirm; restart; owner persists.
4. `/orison admin stage 4`; cast UNSEEN, STEP BETWEEN, INVALID; check cooldowns and PARADOX. 5. `vfx pack`, `vfx demo` for each effect. 6. Walk, sprint, sneak, jump,
land, teleport, change world, die, log out: no stale trail or afterimage. 7. `vfx preview 1..7` and `vfx transform 0..4`: nothing remains after `transform 0`.
8. `admin echo testrecord zombie 1`, say AWAKEN; recall; restart; record persists. 9. Combos and both domains; confirm collapse cleans up on logout.
10. `admin azriel spawn`, `admin stage 6`, hit it; step through phases with `admin azriel phase`. 11. Spark/Timings with several players near the owner.
