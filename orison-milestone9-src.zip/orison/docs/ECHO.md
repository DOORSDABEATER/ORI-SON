# Echo Legion (Milestone 5)

## Flow
1. **Hunt.** Defeating a mob (as the owner, or via your Echoes) records a *hunt record* (one per identity: `mythic:<id>` if
   MythicMobs identifies it, else `vanilla:<type>`) and opens a short claim window (45s, 20 blocks).
2. **AWAKEN.** Say `AWAKEN` in chat (or `/orison awaken`, or cast ability 43). It goes through the normal ability checks
   (stage 4, cooldown, Paradox charged only on ACCEPTED).
3. **Outcome**, always explained in chat:
   - `UNRECOGNIZED` nothing claimable nearby. `IRREGULAR` the form cannot be rebuilt (or inconsistent stats).
   - `SEALED` story/stage locked (`echo.sealed`, `echo.restricted-stage`). Azriel is sealed by default.
   - `INCOMPLETE` not enough recorded defeats (tougher mobs need more: health/60, capped at 6).
   - `RESISTED` the roll failed; each retry improves the odds. `ACCEPTED` an Echo is created (or reinforced if it exists).
4. **Echo record.** Rank (TRACE, FRAGMENT, REPLICA, RECONSTITUTED, SOVEREIGN, ABSOLUTE) needs both XP and integrity;
   integrity bands UNSTABLE, PARTIAL, RECOGNIZABLE, HIGH FIDELITY, NEAR PERFECT, COMPLETE (100 only via a perfect record).
   Stats = original x (0.35 + 0.1 x rank + 0.25 x integrity), never above 1.1.

## What an Echo is
A plain vanilla mob of the original's body type, named with the original's name, optionally wearing its ModelEngine
model. It is never a MythicMob, so original encounter scripts and boss mechanics cannot run on it. No drops, no XP,
fire-immune, never damages players or other Echoes, cannot be harmed by other players. If killed it is *undone* and
reforms after `echo.downed-seconds`; it is never lost. Summoned entities are not persistent and are removed on
logout, owner death, world change, world unload, and plugin disable; leftovers are purged on load.

## Commands (owner): `/orison echo ...`
`list [page]`, `inspect <n>`, `summon <n>`, `recall <n|all>`, `rename <n> <name>`, `favourite <n>`,
`order <n|all|gN> <follow|stay|attack|defend|protect|focus|return>`, `formation <veil|hunt|wall|execution|scatter|sovereign>`,
`group <n> <0-9>`, `hunts`. Numbers come from `list`. Admin: `/orison admin echo testrecord|list|remove`, `/orison admin awaken`.

## Honest status / limitations
- Compiles and runs: NOT verified. The pure rules (ranks, bands, claim decisions, formations) have 39 passing local tests.
- MythicMobs and ModelEngine bridges use reflection and are untested against your versions; on failure they switch
  themselves off and Echoes use vanilla bodies.
- **Not done:** Echoes keep their base mob's attacks. Recognisable signature attacks and adapted boss abilities need
  per-identity profiles (planned). Echo mission/ability unlocks and the SUPPORT role's healing are not built.
- AWAKEN: LEGION, PERFECT RECORD, SOVEREIGN COMMAND, UNENDING LEGION and all of Dominion are not implemented.
- The Legion interface is chat-based for now; the polished GUI belongs to the UI milestone.
- Active Echoes are recalled on restart (their records persist); they are not auto-resummoned.
