# Installation

1. **Requirements:** Paper 26.2, Java 25 on the server, and for building: JDK 25 plus Gradle 8.x (`gradle build`; no wrapper is bundled).
2. **Build:** unzip the source, run `gradle build`, take `build/libs/orison-<version>.jar` into `plugins/`.
   Send me any compile error text; this code has never been compiled.
3. **Resource pack:** host `orison-vfx-pack.zip` at a public URL, run `sha1sum` on it, set `resourcepack.url` and `resourcepack.sha1` in
   `plugins/ORISON/config.yml` (or use server.properties / manual install + `resourcepack.assume-installed`). Regenerate with
   `python3 tools/build_pack.py` (needs Pillow, numpy, scipy, ffmpeg).
4. **Owner:** set `owner.initial-uuid`, or `/orison admin grant <player>` then `... confirm` within 30 s.
5. **First check:** start the server and read the console: the compatibility report lists Paper/Java and each optional plugin. Then in game:
   `/orison admin vfx pack`, `/orison admin stage 4`, `/orison cast unseen`.
6. **Optional integrations** (MythicMobs, ModelEngine, ProtocolLib, Plasmo Voice, WorldGuard) are soft dependencies; the core runs without them.
   ProtocolLib and Plasmo Voice are not used yet. The MythicMobs/ModelEngine bridges are reflection-based and untested against your versions.
